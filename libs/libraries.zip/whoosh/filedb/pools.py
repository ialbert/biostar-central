
# Copyright 2010 Matt Chaput. All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
#    1. Redistributions of source code must retain the above copyright notice,
#       this list of conditions and the following disclaimer.
#
#    2. Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY MATT CHAPUT ``AS IS'' AND ANY EXPRESS OR
# IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
# EVENT SHALL MATT CHAPUT OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
# LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
# OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
# LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
# NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# The views and conclusions contained in the software and documentation are
# those of the authors and should not be interpreted as representing official
# policies, either expressed or implied, of Matt Chaput.

from __future__ import with_statement
import os, tempfile
from array import array
from collections import defaultdict
from heapq import heapify, heappop, heapreplace
from marshal import load, dump
#import sqlite3 as sqlite

from whoosh.compat import long_type, iteritems, xrange, text_type, PY3
from whoosh.filedb.filetables import LengthWriter, LengthReader
from whoosh.util import length_to_byte, byte_to_length, utf8encode


try:
    from sys import getsizeof  #@UnusedImport
except ImportError:
    # If this is Python 2.5, rig up a guesstimated version of getsizeof
    def getsizeof(obj):
        if obj is None:
            return 8
        t = type(obj)
        if t is int and not PY3:
            return 12
        elif t is float:
            return 16
        elif t is long_type:
            return 16
        elif t is str:
            return 21 + len(obj)
        elif t is text_type:
            return 26 + 2 * len(obj)


try:
    from heapq import merge
    def imerge(iterables):
        return merge(*iterables)
except ImportError:
    def imerge(iterables):
        """Merge-sorts items from a list of iterators.
        """

        _heappop, _heapreplace, _StopIteration = (heappop, heapreplace,
                                                  StopIteration)

        h = []
        h_append = h.append
        for itnum, it in enumerate(map(iter, iterables)):
            try:
                next = it.next
                h_append([next(), itnum, next])
            except _StopIteration:
                pass
        heapify(h)

        while 1:
            try:
                while 1:
                    v, itnum, next = s = h[0]
                    yield v
                    s[0] = next()
                    _heapreplace(h, s)
            except _StopIteration:
                _heappop(h)
            except IndexError:
                return


def read_run(filename, count, atatime=100):
    with open(filename, "rb") as f:
        while count:
            buff = []
            take = min(atatime, count)
            for _ in xrange(take):
                buff.append(load(f))
            count -= take
            for item in buff:
                yield item


DEBUG_DIR = False


class PoolBase(object):
    def __init__(self, schema, dir=None, basename=''):
        self.schema = schema
        self._using_tempdir = False
        self.dir = dir
        self._using_tempdir = dir is None
        self.basename = basename

        self.length_arrays = {}
        self._fieldlength_totals = defaultdict(int)
        self._fieldlength_mins = {}
        self._fieldlength_maxes = {}

    def _make_dir(self):
        if self.dir is None:
            self.dir = tempfile.mkdtemp(".whoosh")

            if DEBUG_DIR:
                dfile = open(self._filename("DEBUG.txt"), "wb")
                import traceback
                traceback.print_stack(file=dfile)
                dfile.close()

    def _filename(self, name):
        return os.path.abspath(os.path.join(self.dir, self.basename + name))

    def _clean_temp_dir(self):
        if self._using_tempdir and self.dir and os.path.exists(self.dir):
            if DEBUG_DIR:
                os.remove(self._filename("DEBUG.txt"))

            try:
                os.rmdir(self.dir)
            except OSError:
                # directory didn't exist or was not empty -- don't
                # accidentially delete data
                pass

    def cleanup(self):
        self._clean_temp_dir()

    def cancel(self):
        pass

    def fieldlength_totals(self):
        return dict(self._fieldlength_totals)

    def fieldlength_mins(self):
        return self._fieldlength_mins

    def fieldlength_maxes(self):
        return self._fieldlength_maxes

    def add_posting(self, fieldname, text, docnum, weight, valuestring):
        raise NotImplementedError

    def add_field_length(self, docnum, fieldname, length):
        self._fieldlength_totals[fieldname] += length

        bytelength = length_to_byte(length)
        normalized = byte_to_length(bytelength)

        if normalized < self._fieldlength_mins.get(fieldname, 999999999):
            self._fieldlength_mins[fieldname] = normalized

        if normalized > self._fieldlength_maxes.get(fieldname, 0):
            self._fieldlength_maxes[fieldname] = normalized

        if fieldname not in self.length_arrays:
            self.length_arrays[fieldname] = array("B")
        arry = self.length_arrays[fieldname]

        if len(arry) <= docnum:
            for _ in xrange(docnum - len(arry) + 1):
                arry.append(0)
        arry[docnum] = bytelength

    def _fill_lengths(self, doccount):
        for fieldname in self.length_arrays.keys():
            arry = self.length_arrays[fieldname]
            if len(arry) < doccount:
                for _ in xrange(doccount - len(arry)):
                    arry.append(0)

    def add_content(self, docnum, fieldname, field, value, fboost):
        add_posting = self.add_posting
        termcount = 0
        # TODO: Method for adding progressive field values, ie
        # setting start_pos/start_char?
        for w, freq, weight, valuestring in field.index(value):
            #assert w != ""
            add_posting(fieldname, w, docnum, weight * fboost, valuestring)
            termcount += freq

        if field.scorable and termcount:
            self.add_field_length(docnum, fieldname, termcount)

        return termcount

    def _write_lengths(self, lengthfile, doccount):
        self._fill_lengths(doccount)
        lw = LengthWriter(lengthfile, doccount, lengths=self.length_arrays)
        lw.close()


class TempfilePool(PoolBase):
    def __init__(self, schema, limitmb=32, dir=None, basename='', **kw):
        super(TempfilePool, self).__init__(schema, dir=dir, basename=basename)

        self.limit = limitmb * 1024 * 1024

        self.size = 0
        self.count = 0
        self.postings = []
        self.runs = []

    def add_posting(self, fieldname, text, docnum, weight, valuestring):
        if self.size >= self.limit:
            self.dump_run()

        tup = (fieldname, text, docnum, weight, valuestring)
        # 48 bytes for tuple overhead (28 bytes + 4 bytes * 5 items) plus the
        # sizes of the objects inside the tuple, plus 4 bytes overhead for
        # putting the tuple in the postings list
        #self.size += 48 + sum(getsizeof(o) for o in tup) + 4
        valsize = len(valuestring) if valuestring else 0
        self.size += (48 + len(fieldname) + 22 + len(text)
                      + 26 + 16 + 16 + valsize + 22 + 4)
        self.postings.append(tup)
        self.count += 1

    def dump_run(self):
        if self.size > 0:
            self._make_dir()
            fd, filename = tempfile.mkstemp(".run", dir=self.dir)
            runfile = os.fdopen(fd, "w+b")
            self.postings.sort()
            for p in self.postings:
                dump(p, runfile)
            runfile.close()

            self.runs.append((filename, self.count))
            self.postings = []
            self.size = 0
            self.count = 0

    def run_filenames(self):
        return [filename for filename, _ in self.runs]

    def cancel(self):
        self.cleanup()

    def cleanup(self):
        for filename in self.run_filenames():
            if os.path.exists(filename):
                try:
                    os.remove(filename)
                except IOError:
                    pass

        self._clean_temp_dir()

    def finish(self, termswriter, doccount, lengthfile):
        self._write_lengths(lengthfile, doccount)
        lengths = LengthReader(None, doccount, self.length_arrays)

        if self.postings or self.runs:
            if self.postings and len(self.runs) == 0:
                self.postings.sort()
                postiter = iter(self.postings)
            elif not self.postings and not self.runs:
                postiter = iter([])
            else:
                self.dump_run()
                postiter = imerge([read_run(runname, count)
                                   for runname, count in self.runs])

            termswriter.add_iter(postiter, lengths.get)
        self.cleanup()


# Alternative experimental and testing pools

class SqlitePool(PoolBase):
    def __init__(self, schema, dir=None, basename='', limitmb=32, **kwargs):
        super(SqlitePool, self).__init__(schema, dir=dir, basename=basename)
        self._make_dir()
        self.postbuf = defaultdict(list)
        self.bufsize = 0
        self.limit = limitmb * 1024 * 1024
        self.fieldnames = set()
        self._flushed = False

    def _field_filename(self, name):
        return self._filename("%s.sqlite" % name)

    def _con(self, name):
        import sqlite3 as sqlite

        filename = self._field_filename(name)
        con = sqlite.connect(filename)
        con.execute("PRAGMA synchronous=OFF")
        if name not in self.fieldnames:
            self.fieldnames.add(name)
            con.execute("create table postings "
                        "(token text, docnum int, weight float, value blob)")
            #con.execute("create index postix on postings (token, docnum)")
        return con

    def flush(self):
        for fieldname, lst in iteritems(self.postbuf):
            con = self._con(fieldname)
            con.executemany("insert into postings values (?, ?, ?, ?)", lst)
            con.commit()
            con.close()
        self.postbuf = defaultdict(list)
        self.bufsize = 0
        self._flushed = True

    def add_posting(self, fieldname, text, docnum, weight, valuestring):
        self.postbuf[fieldname].append((text, docnum, weight, valuestring))
        self.bufsize += len(text) + 8 + len(valuestring)
        if self.bufsize > self.limit:
            self.flush()

    def readback(self):
        from whoosh.util import now

        for name in sorted(self.fieldnames):
            con = self._con(name)
            cmd = "select * from postings order by token, docnum"
            for text, docnum, weight, valuestring in con.execute(cmd):
                yield (name, text, docnum, weight, valuestring)
            con.close()
            os.remove(self._field_filename(name))

        if self._using_tempdir and self.dir:
            try:
                os.rmdir(self.dir)
            except OSError:
                # directory didn't exist or was not empty -- don't
                # accidentially delete data
                pass

    def readback_buffer(self):
        for fieldname in sorted(self.postbuf.keys()):
            lst = self.postbuf[fieldname]
            lst.sort()
            for text, docnum, weight, valuestring in lst:
                yield (fieldname, text, docnum, weight, valuestring)
            del self.postbuf[fieldname]

    def finish(self, termswriter, doccount, lengthfile):
        self._write_lengths(lengthfile, doccount)
        lengths = LengthReader(None, doccount, self.length_arrays)

        if not self._flushed:
            gen = self.readback_buffer()
        else:
            if self.postbuf:
                self.flush()
            gen = self.readback()

        termswriter.add_iter(gen, lengths.get)


class NullPool(PoolBase):
    def __init__(self, *args, **kwargs):
        self._fieldlength_totals = {}
        self._fieldlength_mins = {}
        self._fieldlength_maxes = {}

    def add_content(self, *args):
        pass

    def add_posting(self, *args):
        pass

    def add_field_length(self, *args, **kwargs):
        pass

    def finish(self, *args):
        pass


class MemPool(PoolBase):
    def __init__(self, schema, **kwargs):
        super(MemPool, self).__init__(schema)
        self.schema = schema
        self.postbuf = []

    def add_posting(self, *item):
        self.postbuf.append(item)

    def finish(self, termswriter, doccount, lengthfile):
        self._write_lengths(lengthfile, doccount)
        lengths = LengthReader(None, doccount, self.length_arrays)
        self.postbuf.sort()
        termswriter.add_iter(self.postbuf, lengths.get)


class DictPool(PoolBase):
    def __init__(self, schema, **kwargs):
        super(DictPool, self).__init__(schema)
        self.schema = schema
        self.postbuf = {}

    def add_posting(self, fieldname, text, docnum, weight, valuestring):
        term = (fieldname, text)
        if term in self.postbuf:
            buf = self.postbuf[term]
        else:
            self.postbuf[term] = buf = (array("I"), array("f"), [])

        buf[0].append(docnum)
        buf[1].append(weight)
        buf[2].append(valuestring)

    def finish(self, termswriter, doccount, lengthfile):
        from itertools import izip

        pbuf = self.postbuf
        self._write_lengths(lengthfile, doccount)
        lengths = LengthReader(None, doccount, self.length_arrays)

        def gen():
            for term in sorted(pbuf):
                fieldname, text = term
                for docnum, weight, valuestring in izip(*pbuf[term]):
                    yield (fieldname, text, docnum, weight, valuestring)

        termswriter.add_iter(gen(), lengths.get)


# On-disk unique set of strings

class DiskSet(object):
    def __init__(self, iterable=None):
        import sqlite3 as sqlite

        _, self.filename = tempfile.mkstemp(".wordset", "whoosh")
        self.err = sqlite.IntegrityError
        self.con = sqlite.connect(self.filename)
        self.con.execute("create table items (item text primary key)")

        if iterable:
            add = self.add
            for item in iterable:
                add(item)

    def add(self, value):
        try:
            self.con.execute("insert into items values (?)", (value,))
        except self.err:
            pass

    def __iter__(self):
        for row in self.con.execute("select item from items order by item"):
            yield row[0]

    def close(self):
        if self.con:
            self.con.close()
        self.con = None

    def destroy(self):
        self.close()
        os.remove(self.filename)

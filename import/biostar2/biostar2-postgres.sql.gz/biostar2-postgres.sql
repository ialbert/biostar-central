--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: account_emailaddress; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE account_emailaddress (
    id integer NOT NULL,
    user_id integer NOT NULL,
    email character varying(75) NOT NULL,
    verified boolean NOT NULL,
    "primary" boolean NOT NULL
);


--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE account_emailaddress_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE account_emailaddress_id_seq OWNED BY account_emailaddress.id;


--
-- Name: account_emailconfirmation; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE account_emailconfirmation (
    id integer NOT NULL,
    email_address_id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    sent timestamp with time zone,
    key character varying(64) NOT NULL
);


--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE account_emailconfirmation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE account_emailconfirmation_id_seq OWNED BY account_emailconfirmation.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE auth_group_id_seq OWNED BY auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE auth_group_permissions_id_seq OWNED BY auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE auth_permission (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE auth_permission_id_seq OWNED BY auth_permission.id;


--
-- Name: badges_award; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE badges_award (
    id integer NOT NULL,
    badge_id integer NOT NULL,
    user_id integer NOT NULL,
    date timestamp with time zone NOT NULL,
    context character varying(1000) NOT NULL
);


--
-- Name: badges_award_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE badges_award_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: badges_award_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE badges_award_id_seq OWNED BY badges_award.id;


--
-- Name: badges_badge; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE badges_badge (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    type integer NOT NULL,
    "unique" boolean NOT NULL,
    count integer NOT NULL,
    "desc" character varying(200) NOT NULL,
    icon character varying(250) NOT NULL
);


--
-- Name: badges_badge_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE badges_badge_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: badges_badge_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE badges_badge_id_seq OWNED BY badges_badge.id;


--
-- Name: celery_taskmeta; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE celery_taskmeta (
    id integer NOT NULL,
    task_id character varying(255) NOT NULL,
    status character varying(50) NOT NULL,
    result text,
    date_done timestamp with time zone NOT NULL,
    traceback text,
    hidden boolean NOT NULL,
    meta text
);


--
-- Name: celery_taskmeta_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE celery_taskmeta_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: celery_taskmeta_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE celery_taskmeta_id_seq OWNED BY celery_taskmeta.id;


--
-- Name: celery_tasksetmeta; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE celery_tasksetmeta (
    id integer NOT NULL,
    taskset_id character varying(255) NOT NULL,
    result text NOT NULL,
    date_done timestamp with time zone NOT NULL,
    hidden boolean NOT NULL
);


--
-- Name: celery_tasksetmeta_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE celery_tasksetmeta_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: celery_tasksetmeta_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE celery_tasksetmeta_id_seq OWNED BY celery_tasksetmeta.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    user_id integer NOT NULL,
    content_type_id integer,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE django_admin_log_id_seq OWNED BY django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE django_content_type (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE django_content_type_id_seq OWNED BY django_content_type.id;


--
-- Name: django_flatpage; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE django_flatpage (
    id integer NOT NULL,
    url character varying(100) NOT NULL,
    title character varying(200) NOT NULL,
    content text NOT NULL,
    enable_comments boolean NOT NULL,
    template_name character varying(70) NOT NULL,
    registration_required boolean NOT NULL
);


--
-- Name: django_flatpage_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE django_flatpage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: django_flatpage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE django_flatpage_id_seq OWNED BY django_flatpage.id;


--
-- Name: django_flatpage_sites; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE django_flatpage_sites (
    id integer NOT NULL,
    flatpage_id integer NOT NULL,
    site_id integer NOT NULL
);


--
-- Name: django_flatpage_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE django_flatpage_sites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: django_flatpage_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE django_flatpage_sites_id_seq OWNED BY django_flatpage_sites.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


--
-- Name: django_site; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE django_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE django_site_id_seq OWNED BY django_site.id;


--
-- Name: djcelery_crontabschedule; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE djcelery_crontabschedule (
    id integer NOT NULL,
    minute character varying(64) NOT NULL,
    hour character varying(64) NOT NULL,
    day_of_week character varying(64) NOT NULL,
    day_of_month character varying(64) NOT NULL,
    month_of_year character varying(64) NOT NULL
);


--
-- Name: djcelery_crontabschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE djcelery_crontabschedule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: djcelery_crontabschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE djcelery_crontabschedule_id_seq OWNED BY djcelery_crontabschedule.id;


--
-- Name: djcelery_intervalschedule; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE djcelery_intervalschedule (
    id integer NOT NULL,
    every integer NOT NULL,
    period character varying(24) NOT NULL
);


--
-- Name: djcelery_intervalschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE djcelery_intervalschedule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: djcelery_intervalschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE djcelery_intervalschedule_id_seq OWNED BY djcelery_intervalschedule.id;


--
-- Name: djcelery_periodictask; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE djcelery_periodictask (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    task character varying(200) NOT NULL,
    interval_id integer,
    crontab_id integer,
    args text NOT NULL,
    kwargs text NOT NULL,
    queue character varying(200),
    exchange character varying(200),
    routing_key character varying(200),
    expires timestamp with time zone,
    enabled boolean NOT NULL,
    last_run_at timestamp with time zone,
    total_run_count integer NOT NULL,
    date_changed timestamp with time zone NOT NULL,
    description text NOT NULL,
    CONSTRAINT djcelery_periodictask_total_run_count_check CHECK ((total_run_count >= 0))
);


--
-- Name: djcelery_periodictask_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE djcelery_periodictask_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: djcelery_periodictask_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE djcelery_periodictask_id_seq OWNED BY djcelery_periodictask.id;


--
-- Name: djcelery_periodictasks; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE djcelery_periodictasks (
    ident smallint NOT NULL,
    last_update timestamp with time zone NOT NULL
);


--
-- Name: djcelery_taskstate; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE djcelery_taskstate (
    id integer NOT NULL,
    state character varying(64) NOT NULL,
    task_id character varying(36) NOT NULL,
    name character varying(200),
    tstamp timestamp with time zone NOT NULL,
    args text,
    kwargs text,
    eta timestamp with time zone,
    expires timestamp with time zone,
    result text,
    traceback text,
    runtime double precision,
    retries integer NOT NULL,
    worker_id integer,
    hidden boolean NOT NULL
);


--
-- Name: djcelery_taskstate_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE djcelery_taskstate_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: djcelery_taskstate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE djcelery_taskstate_id_seq OWNED BY djcelery_taskstate.id;


--
-- Name: djcelery_workerstate; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE djcelery_workerstate (
    id integer NOT NULL,
    hostname character varying(255) NOT NULL,
    last_heartbeat timestamp with time zone
);


--
-- Name: djcelery_workerstate_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE djcelery_workerstate_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: djcelery_workerstate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE djcelery_workerstate_id_seq OWNED BY djcelery_workerstate.id;


--
-- Name: djkombu_message; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE djkombu_message (
    id integer NOT NULL,
    visible boolean NOT NULL,
    sent_at timestamp with time zone,
    payload text NOT NULL,
    queue_id integer NOT NULL
);


--
-- Name: djkombu_message_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE djkombu_message_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: djkombu_message_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE djkombu_message_id_seq OWNED BY djkombu_message.id;


--
-- Name: djkombu_queue; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE djkombu_queue (
    id integer NOT NULL,
    name character varying(200) NOT NULL
);


--
-- Name: djkombu_queue_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE djkombu_queue_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: djkombu_queue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE djkombu_queue_id_seq OWNED BY djkombu_queue.id;


--
-- Name: messages_message; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE messages_message (
    id integer NOT NULL,
    user_id integer NOT NULL,
    body_id integer NOT NULL,
    type integer NOT NULL,
    unread boolean NOT NULL,
    sent_at timestamp with time zone
);


--
-- Name: messages_message_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE messages_message_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: messages_message_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE messages_message_id_seq OWNED BY messages_message.id;


--
-- Name: messages_messagebody; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE messages_messagebody (
    id integer NOT NULL,
    text text NOT NULL,
    author_id integer NOT NULL,
    subject character varying(120) NOT NULL,
    parent_msg_id integer,
    sent_at timestamp with time zone NOT NULL
);


--
-- Name: messages_messagebody_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE messages_messagebody_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: messages_messagebody_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE messages_messagebody_id_seq OWNED BY messages_messagebody.id;


--
-- Name: planet_blog; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE planet_blog (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    "desc" text NOT NULL,
    feed character varying(200) NOT NULL,
    link character varying(200) NOT NULL,
    active boolean NOT NULL,
    list_order integer NOT NULL
);


--
-- Name: planet_blog_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE planet_blog_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: planet_blog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE planet_blog_id_seq OWNED BY planet_blog.id;


--
-- Name: planet_blogpost; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE planet_blogpost (
    id integer NOT NULL,
    blog_id integer NOT NULL,
    uid character varying(200) NOT NULL,
    title character varying(200) NOT NULL,
    content text NOT NULL,
    html text NOT NULL,
    creation_date timestamp with time zone NOT NULL,
    insert_date timestamp with time zone,
    published boolean NOT NULL,
    link character varying(200) NOT NULL
);


--
-- Name: planet_blogpost_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE planet_blogpost_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: planet_blogpost_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE planet_blogpost_id_seq OWNED BY planet_blogpost.id;


--
-- Name: posts_emailentry; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE posts_emailentry (
    id integer NOT NULL,
    post_id integer,
    text text NOT NULL,
    creation_date timestamp with time zone NOT NULL,
    sent_at timestamp with time zone,
    status integer NOT NULL
);


--
-- Name: posts_emailentry_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE posts_emailentry_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: posts_emailentry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE posts_emailentry_id_seq OWNED BY posts_emailentry.id;


--
-- Name: posts_emailsub; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE posts_emailsub (
    id integer NOT NULL,
    email character varying(75) NOT NULL,
    status integer NOT NULL
);


--
-- Name: posts_emailsub_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE posts_emailsub_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: posts_emailsub_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE posts_emailsub_id_seq OWNED BY posts_emailsub.id;


--
-- Name: posts_post; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE posts_post (
    id integer NOT NULL,
    title character varying(200) NOT NULL,
    author_id integer NOT NULL,
    lastedit_user_id integer NOT NULL,
    rank double precision NOT NULL,
    status integer NOT NULL,
    type integer NOT NULL,
    vote_count integer NOT NULL,
    view_count integer NOT NULL,
    reply_count integer NOT NULL,
    comment_count integer NOT NULL,
    book_count integer NOT NULL,
    changed boolean NOT NULL,
    subs_count integer NOT NULL,
    thread_score integer NOT NULL,
    creation_date timestamp with time zone NOT NULL,
    lastedit_date timestamp with time zone NOT NULL,
    sticky boolean NOT NULL,
    has_accepted boolean NOT NULL,
    root_id integer,
    parent_id integer,
    content text NOT NULL,
    tag_val character varying(100) NOT NULL,
    site_id integer,
    html text NOT NULL
);


--
-- Name: posts_post_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE posts_post_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: posts_post_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE posts_post_id_seq OWNED BY posts_post.id;


--
-- Name: posts_post_tag_set; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE posts_post_tag_set (
    id integer NOT NULL,
    post_id integer NOT NULL,
    tag_id integer NOT NULL
);


--
-- Name: posts_post_tag_set_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE posts_post_tag_set_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: posts_post_tag_set_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE posts_post_tag_set_id_seq OWNED BY posts_post_tag_set.id;


--
-- Name: posts_postview; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE posts_postview (
    id integer NOT NULL,
    ip inet,
    post_id integer NOT NULL,
    date timestamp with time zone NOT NULL
);


--
-- Name: posts_postview_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE posts_postview_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: posts_postview_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE posts_postview_id_seq OWNED BY posts_postview.id;


--
-- Name: posts_replytoken; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE posts_replytoken (
    id integer NOT NULL,
    date timestamp with time zone NOT NULL,
    user_id integer NOT NULL,
    post_id integer NOT NULL,
    token character varying(256) NOT NULL
);


--
-- Name: posts_replytoken_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE posts_replytoken_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: posts_replytoken_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE posts_replytoken_id_seq OWNED BY posts_replytoken.id;


--
-- Name: posts_subscription; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE posts_subscription (
    id integer NOT NULL,
    user_id integer NOT NULL,
    post_id integer NOT NULL,
    type integer NOT NULL,
    date timestamp with time zone NOT NULL
);


--
-- Name: posts_subscription_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE posts_subscription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: posts_subscription_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE posts_subscription_id_seq OWNED BY posts_subscription.id;


--
-- Name: posts_tag; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE posts_tag (
    id integer NOT NULL,
    name text NOT NULL,
    count integer NOT NULL
);


--
-- Name: posts_tag_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE posts_tag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: posts_tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE posts_tag_id_seq OWNED BY posts_tag.id;


--
-- Name: posts_vote; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE posts_vote (
    id integer NOT NULL,
    author_id integer NOT NULL,
    post_id integer NOT NULL,
    type integer NOT NULL,
    date timestamp with time zone NOT NULL
);


--
-- Name: posts_vote_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE posts_vote_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: posts_vote_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE posts_vote_id_seq OWNED BY posts_vote.id;


--
-- Name: socialaccount_socialaccount; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE socialaccount_socialaccount (
    id integer NOT NULL,
    user_id integer NOT NULL,
    last_login timestamp with time zone NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    provider character varying(30) NOT NULL,
    uid character varying(255) NOT NULL,
    extra_data text NOT NULL
);


--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE socialaccount_socialaccount_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE socialaccount_socialaccount_id_seq OWNED BY socialaccount_socialaccount.id;


--
-- Name: socialaccount_socialapp; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE socialaccount_socialapp (
    id integer NOT NULL,
    provider character varying(30) NOT NULL,
    name character varying(40) NOT NULL,
    key character varying(100) NOT NULL,
    secret character varying(100) NOT NULL,
    client_id character varying(100) NOT NULL
);


--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE socialaccount_socialapp_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE socialaccount_socialapp_id_seq OWNED BY socialaccount_socialapp.id;


--
-- Name: socialaccount_socialapp_sites; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE socialaccount_socialapp_sites (
    id integer NOT NULL,
    socialapp_id integer NOT NULL,
    site_id integer NOT NULL
);


--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE socialaccount_socialapp_sites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE socialaccount_socialapp_sites_id_seq OWNED BY socialaccount_socialapp_sites.id;


--
-- Name: socialaccount_socialtoken; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE socialaccount_socialtoken (
    id integer NOT NULL,
    app_id integer NOT NULL,
    account_id integer NOT NULL,
    token text NOT NULL,
    token_secret text NOT NULL,
    expires_at timestamp with time zone
);


--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE socialaccount_socialtoken_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE socialaccount_socialtoken_id_seq OWNED BY socialaccount_socialtoken.id;


--
-- Name: south_migrationhistory; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE south_migrationhistory (
    id integer NOT NULL,
    app_name character varying(255) NOT NULL,
    migration character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


--
-- Name: south_migrationhistory_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE south_migrationhistory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: south_migrationhistory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE south_migrationhistory_id_seq OWNED BY south_migrationhistory.id;


--
-- Name: users_emaillist; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE users_emaillist (
    id integer NOT NULL,
    date timestamp with time zone NOT NULL,
    email character varying(255) NOT NULL,
    type integer NOT NULL,
    active boolean NOT NULL
);


--
-- Name: users_emaillist_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE users_emaillist_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_emaillist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE users_emaillist_id_seq OWNED BY users_emaillist.id;


--
-- Name: users_profile; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE users_profile (
    id integer NOT NULL,
    user_id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    last_login timestamp with time zone NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    location character varying(255) NOT NULL,
    website character varying(255) NOT NULL,
    scholar character varying(255) NOT NULL,
    my_tags text NOT NULL,
    info text,
    message_prefs integer NOT NULL,
    flag integer NOT NULL,
    twitter_id character varying(255) NOT NULL,
    watched_tags character varying(100) NOT NULL,
    opt_in boolean NOT NULL,
    digest_prefs integer NOT NULL
);


--
-- Name: users_profile_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE users_profile_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_profile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE users_profile_id_seq OWNED BY users_profile.id;


--
-- Name: users_profile_tags; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE users_profile_tags (
    id integer NOT NULL,
    profile_id integer NOT NULL,
    tag_id integer NOT NULL
);


--
-- Name: users_profile_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE users_profile_tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_profile_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE users_profile_tags_id_seq OWNED BY users_profile_tags.id;


--
-- Name: users_tag; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE users_tag (
    id integer NOT NULL,
    name text NOT NULL
);


--
-- Name: users_tag_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE users_tag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE users_tag_id_seq OWNED BY users_tag.id;


--
-- Name: users_user; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE users_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone NOT NULL,
    email character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    is_active boolean NOT NULL,
    is_admin boolean NOT NULL,
    is_staff boolean NOT NULL,
    type integer NOT NULL,
    status integer NOT NULL,
    new_messages integer NOT NULL,
    badges integer NOT NULL,
    score integer NOT NULL,
    flair character varying(15) NOT NULL,
    site_id integer,
    activity integer NOT NULL
);


--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE users_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE users_user_id_seq OWNED BY users_user.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY account_emailaddress ALTER COLUMN id SET DEFAULT nextval('account_emailaddress_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY account_emailconfirmation ALTER COLUMN id SET DEFAULT nextval('account_emailconfirmation_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY auth_group ALTER COLUMN id SET DEFAULT nextval('auth_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('auth_group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY auth_permission ALTER COLUMN id SET DEFAULT nextval('auth_permission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY badges_award ALTER COLUMN id SET DEFAULT nextval('badges_award_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY badges_badge ALTER COLUMN id SET DEFAULT nextval('badges_badge_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY celery_taskmeta ALTER COLUMN id SET DEFAULT nextval('celery_taskmeta_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY celery_tasksetmeta ALTER COLUMN id SET DEFAULT nextval('celery_tasksetmeta_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY django_admin_log ALTER COLUMN id SET DEFAULT nextval('django_admin_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY django_content_type ALTER COLUMN id SET DEFAULT nextval('django_content_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY django_flatpage ALTER COLUMN id SET DEFAULT nextval('django_flatpage_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY django_flatpage_sites ALTER COLUMN id SET DEFAULT nextval('django_flatpage_sites_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY django_site ALTER COLUMN id SET DEFAULT nextval('django_site_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY djcelery_crontabschedule ALTER COLUMN id SET DEFAULT nextval('djcelery_crontabschedule_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY djcelery_intervalschedule ALTER COLUMN id SET DEFAULT nextval('djcelery_intervalschedule_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY djcelery_periodictask ALTER COLUMN id SET DEFAULT nextval('djcelery_periodictask_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY djcelery_taskstate ALTER COLUMN id SET DEFAULT nextval('djcelery_taskstate_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY djcelery_workerstate ALTER COLUMN id SET DEFAULT nextval('djcelery_workerstate_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY djkombu_message ALTER COLUMN id SET DEFAULT nextval('djkombu_message_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY djkombu_queue ALTER COLUMN id SET DEFAULT nextval('djkombu_queue_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY messages_message ALTER COLUMN id SET DEFAULT nextval('messages_message_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY messages_messagebody ALTER COLUMN id SET DEFAULT nextval('messages_messagebody_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY planet_blog ALTER COLUMN id SET DEFAULT nextval('planet_blog_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY planet_blogpost ALTER COLUMN id SET DEFAULT nextval('planet_blogpost_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY posts_emailentry ALTER COLUMN id SET DEFAULT nextval('posts_emailentry_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY posts_emailsub ALTER COLUMN id SET DEFAULT nextval('posts_emailsub_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY posts_post ALTER COLUMN id SET DEFAULT nextval('posts_post_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY posts_post_tag_set ALTER COLUMN id SET DEFAULT nextval('posts_post_tag_set_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY posts_postview ALTER COLUMN id SET DEFAULT nextval('posts_postview_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY posts_replytoken ALTER COLUMN id SET DEFAULT nextval('posts_replytoken_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY posts_subscription ALTER COLUMN id SET DEFAULT nextval('posts_subscription_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY posts_tag ALTER COLUMN id SET DEFAULT nextval('posts_tag_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY posts_vote ALTER COLUMN id SET DEFAULT nextval('posts_vote_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY socialaccount_socialaccount ALTER COLUMN id SET DEFAULT nextval('socialaccount_socialaccount_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY socialaccount_socialapp ALTER COLUMN id SET DEFAULT nextval('socialaccount_socialapp_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY socialaccount_socialapp_sites ALTER COLUMN id SET DEFAULT nextval('socialaccount_socialapp_sites_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY socialaccount_socialtoken ALTER COLUMN id SET DEFAULT nextval('socialaccount_socialtoken_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY south_migrationhistory ALTER COLUMN id SET DEFAULT nextval('south_migrationhistory_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY users_emaillist ALTER COLUMN id SET DEFAULT nextval('users_emaillist_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY users_profile ALTER COLUMN id SET DEFAULT nextval('users_profile_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY users_profile_tags ALTER COLUMN id SET DEFAULT nextval('users_profile_tags_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY users_tag ALTER COLUMN id SET DEFAULT nextval('users_tag_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY users_user ALTER COLUMN id SET DEFAULT nextval('users_user_id_seq'::regclass);


--
-- Data for Name: account_emailaddress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY account_emailaddress (id, user_id, email, verified, "primary") FROM stdin;
\.


--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('account_emailaddress_id_seq', 1, false);


--
-- Data for Name: account_emailconfirmation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY account_emailconfirmation (id, email_address_id, created, sent, key) FROM stdin;
\.


--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('account_emailconfirmation_id_seq', 1, false);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY auth_group (id, name) FROM stdin;
\.


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('auth_group_id_seq', 1, false);


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('auth_group_permissions_id_seq', 1, false);


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add permission	1	add_permission
2	Can change permission	1	change_permission
3	Can delete permission	1	delete_permission
4	Can add group	2	add_group
5	Can change group	2	change_group
6	Can delete group	2	delete_group
7	Can add content type	3	add_contenttype
8	Can change content type	3	change_contenttype
9	Can delete content type	3	delete_contenttype
10	Can add site	4	add_site
11	Can change site	4	change_site
12	Can delete site	4	delete_site
13	Can add message body	5	add_messagebody
14	Can change message body	5	change_messagebody
15	Can delete message body	5	delete_messagebody
16	Can add message	6	add_message
17	Can change message	6	change_message
18	Can delete message	6	delete_message
19	Can add log entry	7	add_logentry
20	Can change log entry	7	change_logentry
21	Can delete log entry	7	delete_logentry
22	Can add flat page	8	add_flatpage
23	Can change flat page	8	change_flatpage
24	Can delete flat page	8	delete_flatpage
25	Can add session	9	add_session
26	Can change session	9	change_session
27	Can delete session	9	delete_session
28	Can add email address	10	add_emailaddress
29	Can change email address	10	change_emailaddress
30	Can delete email address	10	delete_emailaddress
31	Can add email confirmation	11	add_emailconfirmation
32	Can change email confirmation	11	change_emailconfirmation
33	Can delete email confirmation	11	delete_emailconfirmation
34	Can add migration history	12	add_migrationhistory
35	Can change migration history	12	change_migrationhistory
36	Can delete migration history	12	delete_migrationhistory
37	Can add user	13	add_user
38	Can change user	13	change_user
39	Can delete user	13	delete_user
40	Can add email list	14	add_emaillist
41	Can change email list	14	change_emaillist
42	Can delete email list	14	delete_emaillist
43	Can add tag	15	add_tag
44	Can change tag	15	change_tag
45	Can delete tag	15	delete_tag
46	Can add profile	16	add_profile
47	Can change profile	16	change_profile
48	Can delete profile	16	delete_profile
49	Can add tag	17	add_tag
50	Can change tag	17	change_tag
51	Can delete tag	17	delete_tag
52	Can add post	18	add_post
53	Can change post	18	change_post
54	Can delete post	18	delete_post
55	Can add reply token	19	add_replytoken
56	Can change reply token	19	change_replytoken
57	Can delete reply token	19	delete_replytoken
58	Can add email sub	20	add_emailsub
59	Can change email sub	20	change_emailsub
60	Can delete email sub	20	delete_emailsub
61	Can add email entry	21	add_emailentry
62	Can change email entry	21	change_emailentry
63	Can delete email entry	21	delete_emailentry
64	Can add post view	22	add_postview
65	Can change post view	22	change_postview
66	Can delete post view	22	delete_postview
67	Can add vote	23	add_vote
68	Can change vote	23	change_vote
69	Can delete vote	23	delete_vote
70	Can add subscription	24	add_subscription
71	Can change subscription	24	change_subscription
72	Can delete subscription	24	delete_subscription
73	Can add badge	25	add_badge
74	Can change badge	25	change_badge
75	Can delete badge	25	delete_badge
76	Can add award	26	add_award
77	Can change award	26	change_award
78	Can delete award	26	delete_award
79	Can add blog	27	add_blog
80	Can change blog	27	change_blog
81	Can delete blog	27	delete_blog
82	Can add blog post	28	add_blogpost
83	Can change blog post	28	change_blogpost
84	Can delete blog post	28	delete_blogpost
85	Can add social app	29	add_socialapp
86	Can change social app	29	change_socialapp
87	Can delete social app	29	delete_socialapp
88	Can add social account	30	add_socialaccount
89	Can change social account	30	change_socialaccount
90	Can delete social account	30	delete_socialaccount
91	Can add social token	31	add_socialtoken
92	Can change social token	31	change_socialtoken
93	Can delete social token	31	delete_socialtoken
94	Can add task state	32	add_taskmeta
95	Can change task state	32	change_taskmeta
96	Can delete task state	32	delete_taskmeta
97	Can add saved group result	33	add_tasksetmeta
98	Can change saved group result	33	change_tasksetmeta
99	Can delete saved group result	33	delete_tasksetmeta
100	Can add interval	34	add_intervalschedule
101	Can change interval	34	change_intervalschedule
102	Can delete interval	34	delete_intervalschedule
103	Can add crontab	35	add_crontabschedule
104	Can change crontab	35	change_crontabschedule
105	Can delete crontab	35	delete_crontabschedule
106	Can add periodic tasks	36	add_periodictasks
107	Can change periodic tasks	36	change_periodictasks
108	Can delete periodic tasks	36	delete_periodictasks
109	Can add periodic task	37	add_periodictask
110	Can change periodic task	37	change_periodictask
111	Can delete periodic task	37	delete_periodictask
112	Can add worker	38	add_workerstate
113	Can change worker	38	change_workerstate
114	Can delete worker	38	delete_workerstate
115	Can add task	39	add_taskstate
116	Can change task	39	change_taskstate
117	Can delete task	39	delete_taskstate
118	Can add queue	40	add_queue
119	Can change queue	40	change_queue
120	Can delete queue	40	delete_queue
121	Can add message	41	add_message
122	Can change message	41	change_message
123	Can delete message	41	delete_message
\.


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('auth_permission_id_seq', 123, true);


--
-- Data for Name: badges_award; Type: TABLE DATA; Schema: public; Owner: -
--

COPY badges_award (id, badge_id, user_id, date, context) FROM stdin;
\.


--
-- Name: badges_award_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('badges_award_id_seq', 1, false);


--
-- Data for Name: badges_badge; Type: TABLE DATA; Schema: public; Owner: -
--

COPY badges_badge (id, name, type, "unique", count, "desc", icon) FROM stdin;
1	Autobiographer	0	f	0	has more than 80 characters in the information field of the user's profile	fa fa-bullhorn
2	Student	0	f	0	asked a question with at least 3 up-votes	fa fa-certificate
3	Teacher	0	f	0	created an answer with at least 3 up-votes	fa fa-smile-o
4	Commentator	0	f	0	created a comment with at least 3 up-votes	fa fa-comment
5	Supporter	1	f	0	voted at least 25 times	fa fa-thumbs-up
6	Scholar	0	f	0	created an answer that has been accepted	fa fa-check-circle-o
7	Voter	0	f	0	voted more than 100 times	fa fa-thumbs-o-up
8	Centurion	1	f	0	created 100 posts	fa fa-bolt
9	Cylon	2	f	0	received 1,000 up votes	fa fa-rocket
10	Rising Star	2	f	0	created 50 posts within first three months of joining	fa fa-star
11	Guru	1	f	0	received more than 100 upvotes	fa fa-beer
12	Popular Question	2	f	0	created a question with more than 1,000 views	fa fa-eye
13	Epic Question	2	f	0	created a question with more than 10,000 views	fa fa-bullseye
14	Oracle	2	f	0	created more than 1,000 posts (questions + answers + comments)	fa fa-sun-o
15	Pundit	1	f	0	created a comment with more than 10 votes	fa fa-comments-o
16	Good Answer	0	f	0	created an answer that was upvoted at least 5 times	fa fa-pencil-square-o
17	Good Question	0	f	0	asked a question that was upvoted at least 5 times	fa fa-question
18	Prophet	0	f	0	created a post with more than 20 followers	fa fa-pagelines
19	Librarian	0	f	0	created a post with more than 10 bookmarks	fa fa-bookmark-o
20	Great Question	1	f	0	created a question with more than 5,000 views	fa fa-fire
21	Gold Standard	2	f	0	created a post with more than 25 bookmarks	fa fa-bookmark
22	Appreciated	1	f	0	created a post with more than 5 votes	fa fa-heart
\.


--
-- Name: badges_badge_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('badges_badge_id_seq', 22, true);


--
-- Data for Name: celery_taskmeta; Type: TABLE DATA; Schema: public; Owner: -
--

COPY celery_taskmeta (id, task_id, status, result, date_done, traceback, hidden, meta) FROM stdin;
\.


--
-- Name: celery_taskmeta_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('celery_taskmeta_id_seq', 1, false);


--
-- Data for Name: celery_tasksetmeta; Type: TABLE DATA; Schema: public; Owner: -
--

COPY celery_tasksetmeta (id, taskset_id, result, date_done, hidden) FROM stdin;
\.


--
-- Name: celery_tasksetmeta_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('celery_tasksetmeta_id_seq', 1, false);


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY django_admin_log (id, action_time, user_id, content_type_id, object_id, object_repr, action_flag, change_message) FROM stdin;
\.


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('django_admin_log_id_seq', 1, false);


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY django_content_type (id, name, app_label, model) FROM stdin;
1	permission	auth	permission
2	group	auth	group
3	content type	contenttypes	contenttype
4	site	sites	site
5	message body	messages	messagebody
6	message	messages	message
7	log entry	admin	logentry
8	flat page	flatpages	flatpage
9	session	sessions	session
10	email address	account	emailaddress
11	email confirmation	account	emailconfirmation
12	migration history	south	migrationhistory
13	user	users	user
14	email list	users	emaillist
15	tag	users	tag
16	profile	users	profile
17	tag	posts	tag
18	post	posts	post
19	reply token	posts	replytoken
20	email sub	posts	emailsub
21	email entry	posts	emailentry
22	post view	posts	postview
23	vote	posts	vote
24	subscription	posts	subscription
25	badge	badges	badge
26	award	badges	award
27	blog	planet	blog
28	blog post	planet	blogpost
29	social app	socialaccount	socialapp
30	social account	socialaccount	socialaccount
31	social token	socialaccount	socialtoken
32	task state	djcelery	taskmeta
33	saved group result	djcelery	tasksetmeta
34	interval	djcelery	intervalschedule
35	crontab	djcelery	crontabschedule
36	periodic tasks	djcelery	periodictasks
37	periodic task	djcelery	periodictask
38	worker	djcelery	workerstate
39	task	djcelery	taskstate
40	queue	django	queue
41	message	django	message
\.


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('django_content_type_id_seq', 41, true);


--
-- Data for Name: django_flatpage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY django_flatpage (id, url, title, content, enable_comments, template_name, registration_required) FROM stdin;
1	/info/faq/	Faq	<h2>Frequently Asked Questions</h2>\r\r\r<h3>Contact</h3>\r<p>Contact email: <a href="mailto:admin@biostars.org">admin@biostars.org</a></p>\r\r<h3>Moderation guidelines</h3>\r<p>Users posting content that does not belong to the site will be notified and required to edit their content. Users may\r    post commercially motivated posts to the Forum section as long as the topic aligns with the main focus of this site.\r    Users posting obvious spam will be immediately suspended.</p>\r\r\r<h3>User reputation</h3>\r<p>The number next to a user&#39;s name is the sum of upvotes and accepted answers that user has collected.</p>\r\r\r<h3>Becoming a moderator</h3>\r<p>Active users above a certain reputation threshold are periodically promoted to moderators. You may also explicitly\r    ask\r    for moderation rights or suggest good candidates on the newsgroup. Inactive users that do not visit the site for\r    extended periods of time may lose their moderation rights.</p>\r\r<h3>Support for Biostar</h3>\r<p>\r    Biostar has been developed as an open source software and\r    has been released with the <b>MIT licence</b>\r    thanks to the support from the following institutions:\r\r<ul>\r    <li><a href="http://www.psu.edu/">The Pennsylvania State University</a></li>\r    <li><a href="http://www.nih.gov/">National Institutes of Health (NIH)</a>, specifially grant&nbsp;<a\r            href="http://ged.msu.edu/downloads/2010-ngs-course-nih-r25.pdf">NIH 5R25HG006243-02, Analyzing Next\r        Generation\r        Sequencing Data</a>&nbsp; principal investigator: &nbsp;<a href="http://ged.msu.edu/">Titus Brown (Michigan\r        State University)</a>,&nbsp;</li>\r</ul>\r</p>	f		f
2	/info/about/	About	<h3>About Biostar</h3>\r\n\r\n<p>This site&#39;s focus is&nbsp;<strong>bioinformatics</strong>,&nbsp;<strong>computational genomics</strong>&nbsp;and&nbsp;<strong>biological\r\n    data analysis</strong>. We welcome posts that are:</p>\r\n\r\n<ul>\r\n    <li>detailed and specific, written clearly and simply</li>\r\n</ul>\r\n\r\n<p>No question is too trivial or too &quot;newbie&quot;.</p>\r\n<p>But we recommend that you make use of the search services to see if your question has already been asked (perhaps\r\n    even answered!) before you ask. But if you end up asking a question that has been asked before, that is fine too.\r\n    Other users will hopefully edit in links to related or similar questions to help future visitors find their way.</p>\r\n\r\n<h3>Contact</h3>\r\n\r\n<p>To contact the site managers please email&nbsp;<a href="mailto:admin@biostars.org">admin@biostars.org</a>.</p>\r\n\r\n<h3>Licensing</h3>\r\n\r\n<p>\r\n    <div class="pull-right" style="margin-left:10px"><a rel="license" href="http://creativecommons.org/licenses/by/4.0/">\r\n        <img alt="Creative Commons License"\r\n             style="border-width:0"\r\n             src="http://i.creativecommons.org/l/by/4.0/88x31.png"/></a>\r\n    </div>\r\n    All content on Biostar is licensed via the\r\n    <a rel="license" href="http://creativecommons.org/licenses/by/4.0/">Creative Commons\r\n        Attribution 4.0 International\r\n        License</a>. This means that you should attribute the work\r\n    either to the author and/or to the site, depending on the scope and presentation of the information.\r\n    In addition our community supports the <a href="http://en.wikipedia.org/wiki/Fair_use">fair use policy</a>\r\n    when it comes to content created by users of this site.\r\n</p>\r\n\r\n\r\n<h3>Citing Biostar</h3>\r\n\r\n<p>Parnell LD, Lindenbaum P, Shameer K, Dall&#39;Olio GM, Swan DC, et al. 2011&nbsp;<strong>BioStar: An Online Question\r\n    &amp; Answer Resource for the Bioinformatics Community.</strong>&nbsp;<em>PLoS Comput Biol 7(10)</em>:&nbsp;<a\r\nhref="http://www.ploscompbiol.org/article/info%3Adoi%2F10.1371%2Fjournal.pcbi.1002216">e1002216.\r\n    doi:10.1371/journal.pcbi.1002216</a></p>\r\n\r\n\r\n\r\n<h3>Source code</h3>\r\n\r\nBiostar source code at <a href="https://github.com/ialbert/biostar-central">biostar-central repository</a>.\r\nReport bugs or feature requests in the <a href="https://github.com/ialbert/biostar-central/issues"> issue tracker</a>.\r\nCopyright by the <a href="https://github.com/ialbert/biostar-central/contributors">BioStar team</a>.	f		f
3	/info/help/	Help	<h2>Help</h2>\r\r\n\r\r\n<p>&nbsp;</p>\r\r\n\r\r\n<p>How to get help around here!</p>\r\r\n	f		f
4	/info/policy/	Policy	<h2>Policy</h2>\n\n<h3>User agreement</h3>\n\n<p>Be well, do good work and keep in touch.</p>\n\n<h3>Privay policy</h3>\n\n<p>We do not give out or sell your information (including name and email address) to anyone.&nbsp;</p>\n\n<h3>Cookies</h3>\n\n<p>The site will set session cookies whenever you visit the site.\n    If you do not intend to ever log in, you may deny this\n    cookie, but you cannot log in without it.&nbsp;\n    <span style="line-height:1.6">Cookies may be also set when you log in, to be able to\n        display new posts and messages that you may have received.\n        Cookies may also be set by Google or other companies that help us aggregate\n        visitor statistics, traffic and other information.</span>\n</p>\n\n<h3>Contact</h3>\n\nContact email: <a href="mailto:admin@biostars.org">admin@biostars.org</a>\n	f		f
5	/info/api/	Api	<h2>Biostar API</h2>\n\n<p>\n    This is the documentation for Biostar API. If you have additional questions, or believe you have\n    encountered a bug, don't hesitate to post a question on Biostar.\n</p>\n\n<h3>General</h3>\n\n<p>\n    All API responses are <a href="http://en.wikipedia.org/wiki/JSON">JSON</a>.<br />\n    <br />\n    Some API responses are cached. Polling for changes should be done sparingly in any case, and\n    polling at a rate faster than once a minute (for semantically identical requests) is considered\n    abusive.<br />\n    <br />\n    A number of methods in the Biostar API accept dates as parameters and return dates as properties,\n    the format of these dates is documented above. As a general rule, full dates use\n    <a href="http://en.wikipedia.org/wiki/ISO_8601">ISO 8601</a> and timestamps are\n    in <a href="http://en.wikipedia.org/wiki/Unix_time">unix epoch time</a>.\n</p>\n\n<h3>Methods</h3>\n\n<h4>Traffic</h4>\n<pre>GET /api/traffic/</pre>\n<p>\n    Number of post views over the last 60 min filtered by unique IPs.<br />\n    <br />\n    <b>Fields in response</b><br />\n    <ul>\n        <li><em>date</em>: the current date, ISO 8601 format.</li>\n        <li><em>post_views_last_60_min</em>: number of post views over the last 60 min filtered\n        by unique IPs.</li>\n        <li><em>timestamp</em>: the current date, unix epoch time format.</li>\n    </ul>\n    <b>Example</b><br />\n    <a href="/api/traffic/">/api/traffic/</a><br />\n    <pre>\n{\n    "date": "2014-05-29T14:59:55.788069",\n    "post_views_last_60_min": 850,\n    "timestamp": 1401375595\n}\n    </pre>\n</p>\n\n<h4>User</h4>\n<pre>GET /api/user/{id}/</pre>\n<p>\n    General info about a user.<br />\n    <br />\n    <b>Parameters</b><br />\n    <ul>\n        <li>\n            <em>id</em>: the identifier of the user, a number.\n        </li>\n    </ul>\n    <b>Fields in response</b><br />\n    <ul>\n        <li><em>date_joined</em>: the date the user joined the website, ISO 8601 format.</li>\n        <li><em>id</em>: the identifier of the user, a number.</li>\n        <li><em>joined_days_ago</em>: the date the user joined the website, as the number of days\n        ago.</li>\n        <li><em>last_login</em>: the date of the last login of the user, ISO 8601 format.</li>\n        <li><em>name</em>: the name of the user.</li>\n        <li><em>vote_count</em>: the number of votes given by the user.</li>\n    </ul>\n    <b>Example</b><br />\n    <a href="/api/user/23/">/api/user/23/</a><br />\n    <pre>\n{\n    "date_joined": "2010-01-18T21:43:55.253000+00:00",\n    "id": 23,\n    "joined_days_ago": 1614,\n    "last_login": "2011-11-08T19:37:21.753000+00:00",\n    "name": "Giovanni M Dall'Olio",\n    "vote_count": 37\n}\n    </pre>\n</p>\n\n<h4>Post</h4>\n<pre>GET /api/post/{id}/</pre>\n<p>\n    General info about a post.<br />\n    <br />\n    <b>Parameters</b><br />\n    <ul>\n        <li>\n            <em>id</em>: the identifier of the post, a number.\n        </li>\n    </ul>\n    <b>Fields in response</b><br />\n    <ul>\n        <li><em>answer_count</em>: number of answers.</li>\n        <li><em>author</em>: author name.</li>\n        <li><em>author_id</em>: author's identifier, a number.</li>\n        <li><em>book_count</em>: number of bookmarks.</li>\n        <li><em>comment_count</em>: number of comments.</li>\n        <li><em>creation_date</em>: creation date, ISO 8601 format.</li>\n        <li><em>has_accepted</em>: true if the question has an accepted answer, boolean.</li>\n        <li><em>id</em>: identifier of the post, a number.</li>\n        <li><em>lastedit_date</em>: date of last edit, ISO 8601 format.</li>\n        <li><em>lastedit_user_id</em>: user who last edited this post.</li>\n        <li><em>parent_id</em>: identifier of the parent post.</li>\n        <li><em>rank</em>: rank, a number.</li>\n        <li><em>reply_count</em>: number of replies.</li>\n        <li><em>root_id</em>: identifier of the root post.</li>\n        <li><em>status</em>: status message.</li>\n        <li><em>status_id</em>: status' identifier, a number.</li>\n        <li><em>subs_count</em>: number of subscribers following this post.</li>\n        <li><em>tag_val</em>: tags.</li>\n        <li><em>thread_score</em>: thread's score.</li>\n        <li><em>title</em>: title.</li>\n        <li><em>type</em>: type of post.</li>\n        <li><em>type_id</em>: type's identifier for this post.</li>\n        <li><em>url</em>: url.</li>\n        <li><em>view_count</em>: number of views.</li>\n        <li><em>vote_count</em>: number of votes.</li>\n        <li><em>xhtml</em>: content.</li>\n    </ul>\n    <b>Example</b><br />\n    <a href="/api/post/25/">/api/post/25/</a><br />\n    <pre>\n{\n    "answer_count": 2,\n    "author": "Gue Su",\n    "author_id": 18,\n    "book_count": 0,\n    "comment_count": 0,\n    "creation_date": "2009-12-01T20:57:35.300000+00:00",\n    "has_accepted": false,\n    "id": 25,\n    "lastedit_date": "2009-12-01T20:57:35.300000+00:00",\n    "lastedit_user_id": 18,\n    "parent_id": 24,\n    "rank": 0.0,\n    "reply_count": 0,\n    "root_id": 24,\n    "status": "Open",\n    "status_id": 1,\n    "subs_count": 0,\n    "tag_val": "",\n    "thread_score": 0,\n    "title": "A: How To Set Shrimp Parameters For Best Sensitivity With 35Bp Colorspace Data?",\n    "type": "Answer",\n    "type_id": 1,\n    "url": "http://localhost:8080/p/24/#25",\n    "view_count": 0,\n    "vote_count": 2,\n    "xhtml": "<p>I just read the SHRiMP manual again, but I think that their explanation about -M option may not be enough to answer your question. I usually use the \\"seed\\" mode by using -s, -n, and -w and the option -M is a new feature of the version 1.3.1, which I have never tried before.</p>\\n\\n<p>I recommend for you to use the \\"seed\\" mode--the default would be good, but please adjust the -s option if you want more sensitivity. Always fast speed compensates sensitivity and the -M option seems to exist for this purpose.</p>\\n\\n<p>Hope my message to be helpful for your project.</p>\\n"\n}\n    </pre>\n</p>\n\n<h4>Vote</h4>\n<pre>GET /api/vote/{id}/</pre>\n<p>\n    General info about a vote.<br />\n    <br />\n    <b>Parameters</b><br />\n    <ul>\n        <li>\n            <em>id</em>: the identifier of the vote, a number.\n        </li>\n    </ul>\n    <b>Fields in response</b><br />\n    <ul>\n        <li><em>author</em>: author name.</li>\n        <li><em>author_id</em>: author's identifier, a number.</li>\n        <li><em>date</em>: date of the vote, ISO 8601 format.</li>\n        <li><em>id</em>: identifier of the vote, a number.</li>\n        <li><em>post_id</em>: identifier of the voted post.</li>\n        <li><em>type</em>: type of vote.</li>\n        <li><em>type_id</em>: type's identifier for this vote.</li>\n    </ul>\n    <b>Example</b><br />\n    <a href="/api/vote/21/">/api/vote/21/</a><br />\n    <pre>\n{\n    "author": "Zhaorong",\n    "author_id": 14,\n    "date": "2014-04-29T15:02:17.740000+00:00",\n    "id": 21,\n    "post_id": 26,\n    "type": "Upvote",\n    "type_id": 0\n}\n    </pre>\n</p>\n\n<h4>Statistics on the <i>N</i>th day</h4>\n<pre>GET /api/stats/day/{day}/</pre>\n<p>\n    Statistics as of the <i>N</i>th day after day-0 (the day of the first ever post).<br />\n    <br />\n    <b>Parameters</b><br />\n    <ul>\n        <li>\n            <em>day</em>: number of days after day-0, a number.\n        </li>\n    </ul>\n    <b>Fields in response</b><br />\n    <ul>\n        <li><em>answers</em>: total number of answers as of the given day.</li>\n        <li><em>comments</em>: total number of comments as of the given day.</li>\n        <li><em>date</em>: date, ISO 8601 format.</li>\n        <li><em>new_posts</em>: number of new posts in the given day.</li>\n        <li><em>new_users</em>: number of new users in the given day.</li>\n        <li><em>new_votes</em>: number of new votes in the given day.</li>\n        <li><em>questions</em>: total number of questions as of the given day.</li>\n        <li><em>timestamp</em>: date, unix epoch time format.</li>\n        <li><em>toplevel</em>: total number of toplevel post as of the given day.</li>\n        <li><em>users</em>: total number of users as of the given day.</li>\n        <li><em>votes</em>: total number of votes as of the given day.</li>\n    </ul>\n    <b>Example</b><br />\n    <a href="/api/stats/day/5/">/api/stats/day/5/</a><br />\n    <pre>\n{\n    "answers": 6,\n    "comments": 0,\n    "date": "2009-10-05T00:00:00",\n    "new_posts": [\n        10,\n        11,\n        12\n    ],\n    "new_users": [\n        10,\n        11\n    ],\n    "new_votes": [],\n    "questions": 6,\n    "timestamp": 1254700800,\n    "toplevel": 6,\n    "users": 10,\n    "votes": 0\n}\n    </pre>\n</p>\n\n<h4>Statistics on a date</h4>\n<pre>GET /api/stats/date/{year}/{month}/{day}/</pre>\n<p>\n    Statistics as of the given date.<br />\n    <br />\n    <b>Parameters</b><br />\n    <ul>\n        <li><em>year</em>: a number, 4 digits.</li>\n        <li><em>month</em>: a number, 2 digits.</li>\n        <li><em>day</em>: a number, 2 digits.</li>\n    </ul>\n    <b>Fields in response</b><br />\n    <ul>\n        <li><em>answers</em>: total number of answers as of the given date.</li>\n        <li><em>comments</em>: total number of comments as of the given date.</li>\n        <li><em>date</em>: date, ISO 8601 format.</li>\n        <li><em>new_posts</em>: number of new posts in the given date.</li>\n        <li><em>new_users</em>: number of new users in the given date.</li>\n        <li><em>new_votes</em>: number of new votes in the given date.</li>\n        <li><em>questions</em>: total number of questions as of the given date.</li>\n        <li><em>timestamp</em>: date, unix epoch time format.</li>\n        <li><em>toplevel</em>: total number of toplevel post as of the given date.</li>\n        <li><em>users</em>: total number of users as of the given date.</li>\n        <li><em>votes</em>: total number of votes as of the given date.</li>\n    </ul>\n    <b>Example</b><br />\n    <a href="/api/stats/date/2009/10/06/">/api/stats/date/2009/10/06/</a><br />\n    <pre>\n{\n    "answers": 9,\n    "comments": 0,\n    "date": "2009-10-06T00:00:00",\n    "new_posts": [\n        13,\n        14,\n        15,\n        16\n    ],\n    "new_users": [\n        12,\n        13\n    ],\n    "new_votes": [],\n    "questions": 7,\n    "timestamp": 1254787200,\n    "toplevel": 7,\n    "users": 12,\n    "votes": 0\n}\n    </pre>\n</p>	f		f
\.


--
-- Name: django_flatpage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('django_flatpage_id_seq', 5, true);


--
-- Data for Name: django_flatpage_sites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY django_flatpage_sites (id, flatpage_id, site_id) FROM stdin;
1	1	1
2	2	1
3	3	1
4	4	1
5	5	1
\.


--
-- Name: django_flatpage_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('django_flatpage_sites_id_seq', 5, true);


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY django_session (session_key, session_data, expire_date) FROM stdin;
6d40zny0yig8cb1wl6x8rq33kazpkwv5	NjMzNjFmMzEyNGZkZDRmZGYzZTY3MzA5YWZhZjhhMGRjMzMxOTQzYTp7InNlc3Npb24iOnsicGxhbmV0IjowLCJvcGVuIjowLCJsYXRlc3QiOjB9LCJhbm9uLXVzZXIiOnRydWV9	2015-02-05 10:28:15.013805-05
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: -
--

COPY django_site (id, domain, name) FROM stdin;
1	localhost:8080	Biostar
\.


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('django_site_id_seq', 1, true);


--
-- Data for Name: djcelery_crontabschedule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY djcelery_crontabschedule (id, minute, hour, day_of_week, day_of_month, month_of_year) FROM stdin;
\.


--
-- Name: djcelery_crontabschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('djcelery_crontabschedule_id_seq', 1, false);


--
-- Data for Name: djcelery_intervalschedule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY djcelery_intervalschedule (id, every, period) FROM stdin;
\.


--
-- Name: djcelery_intervalschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('djcelery_intervalschedule_id_seq', 1, false);


--
-- Data for Name: djcelery_periodictask; Type: TABLE DATA; Schema: public; Owner: -
--

COPY djcelery_periodictask (id, name, task, interval_id, crontab_id, args, kwargs, queue, exchange, routing_key, expires, enabled, last_run_at, total_run_count, date_changed, description) FROM stdin;
\.


--
-- Name: djcelery_periodictask_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('djcelery_periodictask_id_seq', 1, false);


--
-- Data for Name: djcelery_periodictasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY djcelery_periodictasks (ident, last_update) FROM stdin;
\.


--
-- Data for Name: djcelery_taskstate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY djcelery_taskstate (id, state, task_id, name, tstamp, args, kwargs, eta, expires, result, traceback, runtime, retries, worker_id, hidden) FROM stdin;
\.


--
-- Name: djcelery_taskstate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('djcelery_taskstate_id_seq', 1, false);


--
-- Data for Name: djcelery_workerstate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY djcelery_workerstate (id, hostname, last_heartbeat) FROM stdin;
\.


--
-- Name: djcelery_workerstate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('djcelery_workerstate_id_seq', 1, false);


--
-- Data for Name: djkombu_message; Type: TABLE DATA; Schema: public; Owner: -
--

COPY djkombu_message (id, visible, sent_at, payload, queue_id) FROM stdin;
\.


--
-- Name: djkombu_message_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('djkombu_message_id_seq', 1, false);


--
-- Data for Name: djkombu_queue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY djkombu_queue (id, name) FROM stdin;
\.


--
-- Name: djkombu_queue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('djkombu_queue_id_seq', 1, false);


--
-- Data for Name: messages_message; Type: TABLE DATA; Schema: public; Owner: -
--

COPY messages_message (id, user_id, body_id, type, unread, sent_at) FROM stdin;
1	1	1	0	t	2014-04-29 11:02:11.531-04
2	2	2	0	t	2014-04-29 11:02:12.464-04
3	3	3	0	t	2014-04-29 11:02:12.506-04
4	4	4	0	t	2014-04-29 11:02:12.516-04
5	5	5	0	t	2014-04-29 11:02:12.528-04
6	6	6	0	t	2014-04-29 11:02:12.539-04
7	7	7	0	t	2014-04-29 11:02:12.549-04
8	8	8	0	t	2014-04-29 11:02:12.562-04
9	9	9	0	t	2014-04-29 11:02:12.572-04
10	10	10	0	t	2014-04-29 11:02:12.598-04
11	11	11	0	t	2014-04-29 11:02:12.608-04
12	12	12	0	t	2014-04-29 11:02:12.619-04
13	13	13	0	t	2014-04-29 11:02:12.63-04
14	14	14	0	t	2014-04-29 11:02:12.64-04
15	15	15	0	t	2014-04-29 11:02:12.652-04
16	16	16	0	t	2014-04-29 11:02:12.661-04
17	17	17	0	t	2014-04-29 11:02:12.672-04
18	18	18	0	t	2014-04-29 11:02:12.683-04
19	19	19	0	t	2014-04-29 11:02:12.693-04
20	20	20	0	t	2014-04-29 11:02:12.704-04
21	21	21	0	t	2014-04-29 11:02:12.714-04
22	22	22	0	t	2014-04-29 11:02:12.724-04
23	23	23	0	t	2014-04-29 11:02:12.735-04
24	24	24	0	t	2014-04-29 11:02:12.746-04
25	25	25	0	t	2014-04-29 11:02:12.756-04
26	26	26	0	t	2014-04-29 11:02:12.766-04
27	27	27	0	t	2014-04-29 11:02:12.777-04
28	28	28	0	t	2014-04-29 11:02:12.788-04
29	29	29	0	t	2014-04-29 11:02:12.799-04
30	30	30	0	t	2014-04-29 11:02:12.81-04
31	31	31	0	t	2014-04-29 11:02:12.823-04
32	32	32	0	t	2014-04-29 11:02:12.836-04
33	33	33	0	t	2014-04-29 11:02:12.848-04
34	34	34	0	t	2014-04-29 11:02:12.859-04
35	35	35	0	t	2014-04-29 11:02:12.869-04
36	36	36	0	t	2014-04-29 11:02:12.88-04
37	37	37	0	t	2014-04-29 11:02:12.894-04
38	38	38	0	t	2014-04-29 11:02:12.905-04
39	39	39	0	t	2014-04-29 11:02:12.918-04
40	40	40	0	t	2014-04-29 11:02:12.928-04
41	41	41	0	t	2014-04-29 11:02:12.939-04
42	42	42	0	t	2014-04-29 11:02:12.953-04
43	43	43	0	t	2014-04-29 11:02:12.963-04
44	44	44	0	t	2014-04-29 11:02:12.974-04
45	45	45	0	t	2014-04-29 11:02:12.985-04
46	46	46	0	t	2014-04-29 11:02:12.995-04
47	47	47	0	t	2014-04-29 11:02:13.006-04
48	48	48	0	t	2014-04-29 11:02:13.017-04
49	49	49	0	t	2014-04-29 11:02:13.028-04
50	50	50	0	t	2014-04-29 11:02:13.039-04
51	51	51	0	t	2014-04-29 11:02:13.055-04
52	52	52	0	t	2014-04-29 11:02:13.065-04
53	53	53	0	t	2014-04-29 11:02:13.077-04
54	54	54	0	t	2014-04-29 11:02:13.09-04
55	55	55	0	t	2014-04-29 11:02:13.101-04
56	56	56	0	t	2014-04-29 11:02:13.114-04
57	57	57	0	t	2014-04-29 11:02:13.127-04
58	58	58	0	t	2014-04-29 11:02:13.139-04
59	59	59	0	t	2014-04-29 11:02:13.15-04
60	60	60	0	t	2014-04-29 11:02:13.165-04
61	61	61	0	t	2014-04-29 11:02:13.176-04
62	62	62	0	t	2014-04-29 11:02:13.189-04
63	63	63	0	t	2014-04-29 11:02:13.201-04
64	64	64	0	t	2014-04-29 11:02:13.212-04
65	65	65	0	t	2014-04-29 11:02:13.239-04
66	66	66	0	t	2014-04-29 11:02:13.259-04
67	67	67	0	t	2014-04-29 11:02:13.273-04
68	68	68	0	t	2014-04-29 11:02:13.288-04
69	69	69	0	t	2014-04-29 11:02:13.301-04
70	70	70	0	t	2014-04-29 11:02:13.315-04
71	71	71	0	t	2014-04-29 11:02:13.339-04
72	72	72	0	t	2014-04-29 11:02:13.354-04
73	73	73	0	t	2014-04-29 11:02:13.37-04
74	74	74	0	t	2014-04-29 11:02:13.385-04
75	75	75	0	t	2014-04-29 11:02:13.397-04
76	76	76	0	t	2014-04-29 11:02:13.409-04
77	77	77	0	t	2014-04-29 11:02:13.42-04
78	78	78	0	t	2014-04-29 11:02:13.44-04
79	79	79	0	t	2014-04-29 11:02:13.451-04
80	80	80	0	t	2014-04-29 11:02:13.463-04
81	81	81	0	t	2014-04-29 11:02:13.473-04
82	82	82	0	t	2014-04-29 11:02:13.489-04
83	83	83	0	t	2014-04-29 11:02:13.5-04
84	84	84	0	t	2014-04-29 11:02:13.511-04
85	85	85	0	t	2014-04-29 11:02:13.522-04
86	86	86	0	t	2014-04-29 11:02:13.535-04
87	87	87	0	t	2014-04-29 11:02:13.546-04
88	88	88	0	t	2014-04-29 11:02:13.565-04
89	89	89	0	t	2014-04-29 11:02:13.58-04
90	90	90	0	t	2014-04-29 11:02:13.593-04
91	91	91	0	t	2014-04-29 11:02:13.619-04
92	92	92	0	t	2014-04-29 11:02:13.637-04
93	93	93	0	t	2014-04-29 11:02:13.655-04
94	94	94	0	t	2014-04-29 11:02:13.674-04
95	95	95	0	t	2014-04-29 11:02:13.688-04
96	96	96	0	t	2014-04-29 11:02:13.7-04
97	97	97	0	t	2014-04-29 11:02:13.725-04
98	98	98	0	t	2014-04-29 11:02:13.737-04
99	99	99	0	t	2014-04-29 11:02:13.761-04
100	100	100	0	t	2014-04-29 11:02:13.774-04
101	3	107	0	t	2009-09-30 20:55:02.457-04
102	3	108	0	t	2009-09-30 21:32:29.097-04
103	5	108	0	t	2009-09-30 21:32:29.097-04
104	3	109	0	t	2009-09-30 21:35:28.02-04
105	5	109	0	t	2009-09-30 21:35:28.02-04
106	6	109	0	t	2009-09-30 21:35:28.02-04
107	10	111	0	t	2009-10-05 18:03:01.06-04
108	12	114	0	t	2009-10-06 22:10:32.73-04
109	12	115	0	t	2009-10-06 22:41:24.877-04
110	2	115	0	t	2009-10-06 22:41:24.877-04
111	12	116	0	t	2009-10-07 00:04:41.747-04
112	2	116	0	t	2009-10-07 00:04:41.747-04
113	5	116	0	t	2009-10-07 00:04:41.747-04
114	2	117	0	t	2009-10-07 18:41:44.823-04
115	2	118	0	t	2009-10-09 05:28:20.413-04
116	10	118	0	t	2009-10-09 05:28:20.413-04
117	2	119	0	t	2009-10-16 14:25:38.237-04
118	16	123	0	t	2009-10-23 21:46:45.407-04
119	14	125	0	t	2009-12-01 15:57:35.3-05
120	14	126	0	t	2009-12-01 19:00:53.443-05
121	18	126	0	t	2009-12-01 19:00:53.443-05
122	16	127	0	t	2009-12-08 22:45:54.547-05
123	2	127	0	t	2009-12-08 22:45:54.547-05
124	20	129	0	t	2010-01-13 22:17:50.023-05
125	2	130	0	t	2010-01-15 09:48:14.66-05
126	4	132	0	t	2010-01-22 16:13:42.79-05
127	23	135	0	t	2010-01-26 21:23:45.583-05
128	23	136	0	t	2010-01-26 21:32:29.45-05
129	23	137	0	t	2010-01-26 21:38:24.477-05
130	23	138	0	t	2010-01-27 00:42:14.167-05
131	2	138	0	t	2010-01-27 00:42:14.167-05
132	16	139	0	t	2010-01-27 11:08:52.87-05
133	2	139	0	t	2010-01-27 11:08:52.87-05
134	19	139	0	t	2010-01-27 11:08:52.87-05
135	3	140	0	t	2010-01-28 16:31:50.47-05
136	5	140	0	t	2010-01-28 16:31:50.47-05
137	6	140	0	t	2010-01-28 16:31:50.47-05
138	7	140	0	t	2010-01-28 16:31:50.47-05
139	2	142	0	t	2010-01-28 17:22:04.203-05
140	10	142	0	t	2010-01-28 17:22:04.203-05
141	14	142	0	t	2010-01-28 17:22:04.203-05
142	2	143	0	t	2010-01-28 18:58:20.5-05
143	25	143	0	t	2010-01-28 18:58:20.5-05
144	23	144	0	t	2010-01-28 23:41:29.17-05
145	23	145	0	t	2010-01-29 06:50:26.02-05
146	2	145	0	t	2010-01-29 06:50:26.02-05
147	23	147	0	t	2010-01-29 15:06:06.18-05
148	23	149	0	t	2010-02-12 21:01:49.187-05
149	23	150	0	t	2010-02-12 22:57:06.68-05
150	2	150	0	t	2010-02-12 22:57:06.68-05
151	14	152	0	t	2010-02-16 03:31:37.06-05
152	4	154	0	t	2010-02-19 08:31:24.643-05
153	2	154	0	t	2010-02-19 08:31:24.643-05
154	27	155	0	t	2010-02-19 14:33:45.533-05
155	23	157	0	t	2010-02-21 20:11:20.45-05
156	23	159	0	t	2010-02-25 18:32:53.74-05
157	2	159	0	t	2010-02-25 18:32:53.74-05
158	3	160	0	t	2010-02-25 18:51:28.29-05
159	5	160	0	t	2010-02-25 18:51:28.29-05
160	6	160	0	t	2010-02-25 18:51:28.29-05
161	7	160	0	t	2010-02-25 18:51:28.29-05
162	23	160	0	t	2010-02-25 18:51:28.29-05
163	23	161	0	t	2010-02-25 18:54:49.08-05
164	23	162	0	t	2010-02-25 19:24:46.38-05
165	31	162	0	t	2010-02-25 19:24:46.38-05
166	23	163	0	t	2010-02-25 22:33:37.903-05
167	2	163	0	t	2010-02-25 22:33:37.903-05
168	23	164	0	t	2010-02-25 22:41:22.31-05
169	2	164	0	t	2010-02-25 22:41:22.31-05
170	25	164	0	t	2010-02-25 22:41:22.31-05
171	23	165	0	t	2010-02-25 22:50:25.157-05
172	2	165	0	t	2010-02-25 22:50:25.157-05
173	2	166	0	t	2010-02-25 22:52:10.69-05
174	10	166	0	t	2010-02-25 22:52:10.69-05
175	14	166	0	t	2010-02-25 22:52:10.69-05
176	23	166	0	t	2010-02-25 22:52:10.69-05
177	23	167	0	t	2010-02-26 10:51:33.997-05
178	2	167	0	t	2010-02-26 10:51:33.997-05
179	33	167	0	t	2010-02-26 10:51:33.997-05
180	23	168	0	t	2010-02-26 11:07:14.7-05
181	31	168	0	t	2010-02-26 11:07:14.7-05
182	2	168	0	t	2010-02-26 11:07:14.7-05
183	23	170	0	t	2010-02-26 14:15:16.893-05
184	31	170	0	t	2010-02-26 14:15:16.893-05
185	2	170	0	t	2010-02-26 14:15:16.893-05
186	38	170	0	t	2010-02-26 14:15:16.893-05
187	30	171	0	t	2010-02-26 14:47:41.697-05
188	30	172	0	t	2010-02-26 14:54:03.447-05
189	42	172	0	t	2010-02-26 14:54:03.447-05
190	30	173	0	t	2010-02-26 14:56:22.753-05
191	42	173	0	t	2010-02-26 14:56:22.753-05
192	23	173	0	t	2010-02-26 14:56:22.753-05
193	30	174	0	t	2010-02-26 15:26:41.15-05
194	23	174	0	t	2010-02-26 15:26:41.15-05
195	2	174	0	t	2010-02-26 15:26:41.15-05
196	2	175	0	t	2010-02-26 15:44:01.49-05
197	10	175	0	t	2010-02-26 15:44:01.49-05
198	14	175	0	t	2010-02-26 15:44:01.49-05
199	23	175	0	t	2010-02-26 15:44:01.49-05
200	33	175	0	t	2010-02-26 15:44:01.49-05
201	44	178	0	t	2010-02-26 17:15:18.997-05
202	23	180	0	t	2010-02-26 17:58:09.55-05
203	2	181	0	t	2010-02-26 18:03:52.94-05
204	23	182	0	t	2010-02-26 18:04:53.577-05
205	2	182	0	t	2010-02-26 18:04:53.577-05
206	23	183	0	t	2010-02-26 18:16:41.967-05
207	2	183	0	t	2010-02-26 18:16:41.967-05
208	26	183	0	t	2010-02-26 18:16:41.967-05
209	23	184	0	t	2010-02-26 21:16:31.97-05
210	2	184	0	t	2010-02-26 21:16:31.97-05
211	47	184	0	t	2010-02-26 21:16:31.97-05
212	23	185	0	t	2010-02-26 21:27:32.303-05
213	31	185	0	t	2010-02-26 21:27:32.303-05
214	2	185	0	t	2010-02-26 21:27:32.303-05
215	38	185	0	t	2010-02-26 21:27:32.303-05
216	40	185	0	t	2010-02-26 21:27:32.303-05
217	23	186	0	t	2010-02-26 21:44:04.547-05
218	31	186	0	t	2010-02-26 21:44:04.547-05
219	2	186	0	t	2010-02-26 21:44:04.547-05
220	38	186	0	t	2010-02-26 21:44:04.547-05
221	40	186	0	t	2010-02-26 21:44:04.547-05
222	24	186	0	t	2010-02-26 21:44:04.547-05
223	30	187	0	t	2010-02-27 22:00:56.14-05
224	42	187	0	t	2010-02-27 22:00:56.14-05
225	23	187	0	t	2010-02-27 22:00:56.14-05
226	2	187	0	t	2010-02-27 22:00:56.14-05
227	23	189	0	t	2010-03-01 15:06:55.973-05
228	23	191	0	t	2010-03-01 15:41:28.687-05
229	2	191	0	t	2010-03-01 15:41:28.687-05
230	2	193	0	t	2010-03-01 15:51:52.19-05
231	5	193	0	t	2010-03-01 15:51:52.19-05
232	10	194	0	t	2010-03-01 17:07:15.283-05
233	23	195	0	t	2010-03-01 17:32:26.107-05
234	2	195	0	t	2010-03-01 17:32:26.107-05
235	47	195	0	t	2010-03-01 17:32:26.107-05
236	53	195	0	t	2010-03-01 17:32:26.107-05
237	10	196	0	t	2010-03-01 17:52:22.51-05
238	23	196	0	t	2010-03-01 17:52:22.51-05
239	16	197	0	t	2010-03-01 18:05:13.92-05
240	2	197	0	t	2010-03-01 18:05:13.92-05
241	19	197	0	t	2010-03-01 18:05:13.92-05
242	23	197	0	t	2010-03-01 18:05:13.92-05
243	16	198	0	t	2010-03-01 20:51:25.98-05
244	2	198	0	t	2010-03-01 20:51:25.98-05
245	19	198	0	t	2010-03-01 20:51:25.98-05
246	23	198	0	t	2010-03-01 20:51:25.98-05
247	59	198	0	t	2010-03-01 20:51:25.98-05
248	10	200	0	t	2010-03-01 21:06:18.193-05
249	10	200	0	t	2010-03-01 21:06:18.193-05
250	2	201	0	t	2014-05-09 10:39:20.047-04
251	101	202	0	t	2014-05-09 10:39:23.89-04
\.


--
-- Name: messages_message_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('messages_message_id_seq', 251, true);


--
-- Data for Name: messages_messagebody; Type: TABLE DATA; Schema: public; Owner: -
--

COPY messages_messagebody (id, text, author_id, subject, parent_msg_id, sent_at) FROM stdin;
154	<a href="/u/27/">Allen Yu</a> wrote on\n\n<a href="/p/31/#54">A: How Do I Map, Align, And Plot My Solid Results?</a> : \nYou can try BWA as well:\nhttp://maq.sourceforge.net/bwa-man.shtml\n\n	27	A: How Do I Map, Align, And Plot My Solid Results?	\N	2010-02-19 08:31:24.643-05
138	<a href="/u/25/">Fabio</a> wrote on\n\n<a href="/p/34/#38">A: Which Are The Best Programming Languages To Study For A Bioinformatician?</a> : \nAny programming language is good as long you know what you&#39;re doing.\n\n	25	A: Which Are The Best Programming Languages To Study For A Bioinformatician?	\N	2010-01-27 00:42:14.167-05
1	Hello <b>Biostar Community</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:11.531-04
2	Hello <b>Istvan Albert</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.464-04
3	Hello <b>Fabio</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.506-04
4	Hello <b>Jason</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.516-04
5	Hello <b>Zhenhai Zhang</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.528-04
6	Hello <b>Tom Koerber</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.539-04
155	<a href="/u/28/">Curious George</a> wrote on\n\n<a href="/p/53/#55">A: How To Do Quality Trimming Of Solid Reads In Colour Space?</a> : \nThe Solid Accuracy Enhancer Tool might be useful for this.\n\n	28	A: How To Do Quality Trimming Of Solid Reads In Colour Space?	\N	2010-02-19 14:33:45.533-05
7	Hello <b>Suk211</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.549-04
8	Hello <b>Lemon</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.562-04
9	Hello <b>Wubin Qu</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.572-04
10	Hello <b>Question Bot</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.598-04
11	Hello <b>Reka Albert</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.608-04
12	Hello <b>Yang Yang</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.619-04
13	Hello <b>Gue Su Chang</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.63-04
14	Hello <b>Zhaorong</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.64-04
15	Hello <b>Nickey</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.652-04
16	Hello <b>Renee</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.661-04
17	Hello <b>Yu</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.672-04
111	<a href="/u/2/">Istvan Albert</a> wrote on\n\n<a href="/p/10/#11">A: How To Generate Multi-Nucleotide Occupancy Counts For Each Coordinate Of My Read</a> : \nThe code snippet below will populate the store dictionary keyed by the nucleotide patterns and values as lists that contain the occupancy for each index. (Updated answer now includes arbitrary lenght nucleotide counts)::\n\nfrom itertools import count\n\ndef pattern_update(sequence, width=2, store={}):\n\n	2	A: How To Generate Multi-Nucleotide Occupancy Counts For Each Coordinate Of My Read	\N	2009-10-05 18:03:01.06-04
18	Hello <b>Gue Su</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.683-04
19	Hello <b>Mohammed Islaih</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.693-04
20	Hello <b>Alex Reynolds</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.704-04
21	Hello <b>User 4824</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.714-04
22	Hello <b>User 8226</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.724-04
23	Hello <b>Giovanni M Dall&#39;Olio</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.735-04
24	Hello <b>Etal</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.746-04
25	Hello <b>Fabio</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.756-04
26	Hello <b>Nicojo</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.766-04
27	Hello <b>Allen Yu</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.777-04
28	Hello <b>Curious George</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.788-04
112	<a href="/u/2/">Istvan Albert</a> wrote on\n\n<a href="/p/5/#12">A: Recommend Easy To Use Microarray Clustering Software</a> : \nOne of my favorites is the MEV micro-array data analysis tool.\nIt is simple to use and it has a very large number of features. \n\nWorks well for any type of data. You can also load into it data from a file that is in a simple text format:\n\n\nGENE1, value1, value2\nGENE2, value1, value2\n\n\nFeel free to p\n	2	A: Recommend Easy To Use Microarray Clustering Software	\N	2009-10-05 18:09:57.673-04
29	Hello <b>User 5034</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.799-04
30	Hello <b>Pierre Lindenbaum</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.81-04
31	Hello <b>Marcos De Carvalho</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.823-04
32	Hello <b>Gustavo Costa</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.836-04
33	Hello <b>User 6996</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.848-04
34	Hello <b>Paul J. Davis</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.859-04
35	Hello <b>David Nusinow</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.869-04
36	Hello <b>Brentp</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.88-04
37	Hello <b>Razor</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.894-04
38	Hello <b>Simon Cockell</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.905-04
39	Hello <b>Konrad</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.918-04
113	<a href="/u/12/">Yang Yang</a> wrote on\n\n<a href="/p/13/">Chip Dna Deep Sequence</a> : \nHi, everyone,\nI am posting this question for my friend.\nHe is analyzing his CHIP DNA solid deep sequence data, and find out that near 80% reads can not be mapped to the human genome. We are wondering if this high percentage unmapped reads is normal in CHIP DNA deep sequence or there may be something\n	12	Chip Dna Deep Sequence	\N	2009-10-06 20:58:10.227-04
40	Hello <b>Biorelated</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.928-04
41	Hello <b>Yann Abraham</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.939-04
42	Hello <b>Fernando Muñiz</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.953-04
43	Hello <b>User 1402</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.963-04
44	Hello <b>Andrew</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.974-04
45	Hello <b>Alex</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.985-04
46	Hello <b>Owen</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:12.995-04
47	Hello <b>Chris</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.006-04
48	Hello <b>Kelly O.</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.017-04
49	Hello <b>User 3704</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.028-04
50	Hello <b>Greg</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.039-04
114	<a href="/u/2/">Istvan Albert</a> wrote on\n\n<a href="/p/13/#14">A: Chip Dna Deep Sequence</a> : \nI recall that our first samples that we ran on the Solid sequencer have had bad performance. Not quite an 80% loss but around 40%-60% reads were unmappable (yeast). Some other lab members will hopefully chime in with more details. \n\n	2	A: Chip Dna Deep Sequence	\N	2009-10-06 22:10:32.73-04
51	Hello <b>Pedrobeltrao</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.055-04
52	Hello <b>Liam Thompson</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.065-04
53	Hello <b>Michael Barton</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.077-04
54	Hello <b>Schrodinger&#39;S Cat</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.09-04
55	Hello <b>Michael Dondrup</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.101-04
56	Hello <b>Brad Chapman</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.114-04
57	Hello <b>Paulati</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.127-04
58	Hello <b>Dave Bridges</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.139-04
59	Hello <b>Daniel Swan</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.15-04
60	Hello <b>Lukfor</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.165-04
61	Hello <b>Chris Fields</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.176-04
115	<a href="/u/5/">Zhenhai Zhang</a> wrote on\n\n<a href="/p/13/#15">A: Chip Dna Deep Sequence</a> : \nHi there,\n\nWe have done numbers of SOLiD sequencing run on yeast samples. Normally there are only 30-40 percent of total tags can be uniquely mapped back to yeast genome. \n\nWhat I would recommend is do it on solexa. You get much higher quality tags.\n\ncheers,\n\n	5	A: Chip Dna Deep Sequence	\N	2009-10-06 22:41:24.877-04
62	Hello <b>Darked89</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.189-04
63	Hello <b>Lmartinho</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.201-04
64	Hello <b>Manuel Corpas</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.212-04
65	Hello <b>Abhishek Tiwari</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.239-04
66	Hello <b>Neilfws</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.259-04
67	Hello <b>Piotr Byzia</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.273-04
68	Hello <b>Jeroen Van Goey</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.288-04
69	Hello <b>Vince</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.301-04
70	Hello <b>Tom Walsh</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.315-04
71	Hello <b>Egon Willighagen</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.339-04
72	Hello <b>Mndoci</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.354-04
116	<a href="/u/13/">Gue Su Chang</a> wrote on\n\n<a href="/p/13/#16">A: Chip Dna Deep Sequence</a> : \nYour 20% mapping yield looks like low for normal ChIP experiment, even for human. Several factors can reduce this mapping yield. I am wondering which kind of ChIP was used in your case. That is, which kind of proteins was ChIPed?\n\n	13	A: Chip Dna Deep Sequence	\N	2009-10-07 00:04:41.747-04
73	Hello <b>Jeremy Leipzig</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.37-04
74	Hello <b>Mmarchin</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.385-04
75	Hello <b>Paolo</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.397-04
76	Hello <b>Andrew</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.409-04
77	Hello <b>Eleanor Howe</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.42-04
78	Hello <b>Jboveda</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.44-04
79	Hello <b>Tim</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.451-04
80	Hello <b>Daniel Jurczak</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.463-04
81	Hello <b>User 1073</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.473-04
82	Hello <b>Geoffjentry</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.489-04
83	Hello <b>User 3505</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.5-04
117	<a href="/u/10/">Question Bot</a> wrote on\n\n<a href="/p/1/#17">A: Site Use Guidelines</a> : \nIf you are shy about asking the question on your own behalf submit it to to the Question Bot and it will be posted anonymously. Send email to the Question Bot link at the bottom.\n\n	10	A: Site Use Guidelines	\N	2009-10-07 18:41:44.823-04
118	<a href="/u/14/">Zhaorong</a> wrote on\n\n<a href="/p/1/#18">A: Site Use Guidelines</a> : \nHi,\n\nI don&#39;t think a new user can vote on a question or an answer.\nThe site says I need 15 reputation...\n\n	14	A: Site Use Guidelines	\N	2009-10-09 05:28:20.413-04
84	Hello <b>Anshu</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.511-04
85	Hello <b>Bryan Maloney</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.522-04
86	Hello <b>Andrew Su</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.535-04
87	Hello <b>Khader Shameer</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.546-04
88	Hello <b>Pierre</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.565-04
89	Hello <b>Yuri</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.58-04
90	Hello <b>Allpowerde</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.593-04
91	Hello <b>Mikael Huss</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.619-04
92	Hello <b>Perry</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.637-04
93	Hello <b>User 5106</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.655-04
94	Hello <b>Nir London</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.674-04
119	<a href="/u/5/">Zhenhai Zhang</a> wrote on\n\n<a href="/p/5/#19">A: Recommend Easy To Use Microarray Clustering Software</a> : \nI would recommend a combination of cluster and treeview.\n\npretty powerful!\n\n	5	A: Recommend Easy To Use Microarray Clustering Software	\N	2009-10-16 14:25:38.237-04
120	<a href="/u/15/">Nickey</a> wrote on\n\n<a href="/p/20/">(Deleted) Do You Have To Be A Guy To Dress Up As Boy George</a> : \nany ideas im a girl\n\n	15	Do You Have To Be A Guy To Dress Up As Boy George	\N	2009-10-18 05:22:53.98-04
95	Hello <b>Bioinfo</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.688-04
96	Hello <b>Jc</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.7-04
97	Hello <b>Michael Hoffman</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.725-04
98	Hello <b>Nancy Parmalee</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.737-04
99	Hello <b>Avilella</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.761-04
100	Hello <b>Ryan</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-04-29 11:02:13.774-04
101	<a href="/u/2/">Istvan Albert</a> wrote on\n\n<a href="/p/1/">Site Use Guidelines</a> : \nHere are a few guidelines:\n\n\nThe site&#39;s goal is to answer bioinformatics and systems biology related questions\nAnswer questions to gain reputation. \nDon&#39;t forget to vote for answers that you like! Registered users may vote on answers.\nIf you are the one asking the original question you may also sele\n	2	Site Use Guidelines	\N	2009-09-30 16:12:07.053-04
102	<a href="/u/2/">Istvan Albert</a> wrote on\n\n<a href="/p/2/">How Do I Convert From Bed Format To Gff Format?</a> : \nI have a file in GFF format and I need to convert it to BED format. What do I do?\n\n	2	How Do I Convert From Bed Format To Gff Format?	\N	2009-09-30 16:55:00.133-04
103	<a href="/u/2/">Istvan Albert</a> wrote on\n\n<a href="/p/2/#3">A: How Do I Convert From Bed Format To Gff Format?</a> : \nBoth formats are tab delimited text files used to represent DNA features in genomes. The order of columns between the two are different, there are also columns that correspond to attributes missing from one or the other format. Nonetheless the most important difference between the two is the coordin\n	2	A: How Do I Convert From Bed Format To Gff Format?	\N	2009-09-30 16:56:18.353-04
104	<a href="/u/3/">Fabio</a> wrote on\n\n<a href="/p/4/">Finding Common Motifs In Sequences</a> : \nI have a few hundred yeast sequences (20-80bp long) and I want to find common motifs (conserved bases at certain indices) in them. I am using a Mac\n\n	3	Finding Common Motifs In Sequences	\N	2009-09-30 18:09:06.677-04
105	<a href="/u/2/">Istvan Albert</a> wrote on\n\n<a href="/p/5/">Recommend Easy To Use Microarray Clustering Software</a> : \nFeel free to post your favorite clustering tool.\n\n	2	Recommend Easy To Use Microarray Clustering Software	\N	2009-09-30 18:44:22.647-04
106	<a href="/u/5/">Zhenhai Zhang</a> wrote on\n\n<a href="/p/6/">(Deleted) Test By Zhenhai</a> : \nHi, I just created my user id a few minutes ago. \n\nPost this question to see how it works.\n\n	5	Test By Zhenhai	\N	2009-09-30 20:49:39.563-04
107	<a href="/u/5/">Zhenhai Zhang</a> wrote on\n\n<a href="/p/4/#7">A: Finding Common Motifs In Sequences</a> : \ntry this out?\n\nhttp://fraenkel.mit.edu/webmotifs/form.html\n\n	5	A: Finding Common Motifs In Sequences	\N	2009-09-30 20:55:02.457-04
108	<a href="/u/6/">Tom Koerber</a> wrote on\n\n<a href="/p/4/#8">A: Finding Common Motifs In Sequences</a> : \nYou can also use MEME:  http://meme.sdsc.edu/.\n\n	6	A: Finding Common Motifs In Sequences	\N	2009-09-30 21:32:29.097-04
109	<a href="/u/7/">Suk211</a> wrote on\n\n<a href="/p/4/#9">A: Finding Common Motifs In Sequences</a> : \n\nACGGGCCCGACGATGCGTCGTA\n\nACGTACGTCGAACCGTCGTCGT\n\nACGTGCGTCGAAACGTCAGTCG\n\nACGGGTTCGATCGTCGTCGTCG\n\n\nmay be in Python I will break down the first sequence of required motif length into a sliding window and will search for those list of motifs in the rest of sequences using regular expression in python \n	7	A: Finding Common Motifs In Sequences	\N	2009-09-30 21:35:28.02-04
110	<a href="/u/10/">Question Bot</a> wrote on\n\n<a href="/p/10/">How To Generate Multi-Nucleotide Occupancy Counts For Each Coordinate Of My Reads?</a> : \nI need to generate nucleotide occupancy counts for each position of a given sequence then summed over each of the input sequences. An example desired output (for di-nucleotide AT):\n\n\n\n	10	How To Generate Multi-Nucleotide Occupancy Counts For Each Coordinate Of My Reads?	\N	2009-10-05 17:51:37.043-04
121	<a href="/u/15/">Nickey</a> wrote on\n\n<a href="/p/21/">(Deleted) Do You Have To Be A Guy To Dress Up As Boy George</a> : \nany ideas im a girl\n\n	15	Do You Have To Be A Guy To Dress Up As Boy George	\N	2009-10-18 05:23:34.373-04
122	<a href="/u/16/">Renee</a> wrote on\n\n<a href="/p/22/">Gene Id Conversion Tool</a> : \nHey,\n\nI was using DAVID (http://david.abcc.ncifcrf.gov/conversion.jsp) to do the gene ID conversion, e.g.conversion between Agilent ID, Genebank accession id and Entrez gene ID, but I found the DAVID database is not updated. Does anyone know a better updataed conversion tool to do this job? Thanks! \n	16	Gene Id Conversion Tool	\N	2009-10-23 19:42:24.427-04
123	<a href="/u/2/">Istvan Albert</a> wrote on\n\n<a href="/p/22/#23">A: Gene Id Conversion Tool</a> : \nI don&#39;t know of a direct solution myself, but this is a topic that may be of interest for the biological data analysis class that I am teaching. \n\nIf you specify the organism/genomic builds that you are interested in we may be able to generate a full translation list as an in class example or a home\n	2	A: Gene Id Conversion Tool	\N	2009-10-23 21:46:45.407-04
124	<a href="/u/14/">Zhaorong</a> wrote on\n\n<a href="/p/24/">How To Set Shrimp Parameters For Best Sensitivity With 35Bp Colorspace Data?</a> : \nHi,\n\nI have 35bp Solid colorspace sequencing data, and the actual sequences to be mapped are 20-25bp after removing the linker sequence.\n\nI hope to find all the hits allowing no more than n mismatches (say n=3), not only the best hit.\n\nI know there is a -M option to specify -M sensitivity,35bp. I wo\n	14	How To Set Shrimp Parameters For Best Sensitivity With 35Bp Colorspace Data?	\N	2009-12-01 08:13:53.637-05
125	<a href="/u/18/">Gue Su</a> wrote on\n\n<a href="/p/24/#25">A: How To Set Shrimp Parameters For Best Sensitivity With 35Bp Colorspace Data?</a> : \nI just read the SHRiMP manual again, but I think that their explanation about -M option may not be enough to answer your question. I usually use the &quot;seed&quot; mode by using -s, -n, and -w and the option -M is a new feature of the version 1.3.1, which I have never tried before.\n\nI recommend for you to u\n	18	A: How To Set Shrimp Parameters For Best Sensitivity With 35Bp Colorspace Data?	\N	2009-12-01 15:57:35.3-05
126	<a href="/u/2/">Istvan Albert</a> wrote on\n\n<a href="/p/24/#26">A: How To Set Shrimp Parameters For Best Sensitivity With 35Bp Colorspace Data?</a> : \n\n  Since my reads are only 20-25bp long,\n  should I changed the default 4 spaced\n  seeds to 3?\n\n\nwhile the shrimp manual says:\n\n\nWe recommend using the default 4 seeds of weight 12 in most cases.\n\n\nyou could try running on a smaller sample and see what happens. \n\n	2	A: How To Set Shrimp Parameters For Best Sensitivity With 35Bp Colorspace Data?	\N	2009-12-01 19:00:53.443-05
127	<a href="/u/19/">Mohammed Islaih</a> wrote on\n\n<a href="/p/22/#27">A: Gene Id Conversion Tool</a> : \nThe following link has a list of ID conversion tools:\n\nhttp://hum-molgen.org/NewsGen/08-2009/000020.html\n\n	19	A: Gene Id Conversion Tool	\N	2009-12-08 22:45:54.547-05
128	<a href="/u/20/">Alex Reynolds</a> wrote on\n\n<a href="/p/28/">Tips On Compiling And Using Meme 4.3 With A Sun Grid Engine Computation Cluster</a> : \nHas anyone compiled and used MEME 4.x for use in a parallel computation environment, based upon operation with a Sun Grid Engine (SGE) cluster?\n\nI can compile the suite and its tests pass. However, when I attempt to use the -p n option, to specify n computation nodes, I get several error messages:\n\n\n	20	Tips On Compiling And Using Meme 4.3 With A Sun Grid Engine Computation Cluster	\N	2010-01-13 13:59:22.603-05
129	<a href="/u/2/">Istvan Albert</a> wrote on\n\n<a href="/p/28/#29">A: Tips On Compiling And Using Meme 4.3 With A Sun Grid Engine Computation Cluster</a> : \nThis may not be overly useful but it very much sounds like a configuration problem.\n\nUsually there is  configure flag that needs to be set to point to the libraries, something like:\n\n--with-mpidir=MPIDIR\n--with-mpicc=MPICC\n\n\nIt also appears that the MEME suite does not support Open MPI (as per insta\n	2	A: Tips On Compiling And Using Meme 4.3 With A Sun Grid Engine Computation Cluster	\N	2010-01-13 22:17:50.023-05
130	<a href="/u/20/">Alex Reynolds</a> wrote on\n\n<a href="/p/2/#30">A: How Do I Convert From Bed Format To Gff Format?</a> : \nHere&#39;s a Perl script I wrote if you wanted to do something local. \n\nThere&#39;s some code in there for translating yeast chromosome names that can be removed, if not needed. I also used a Site feature in the GFF file as the region ID, which might also need tweaking, depending on what features you&#39;re int\n	20	A: How Do I Convert From Bed Format To Gff Format?	\N	2010-01-15 09:48:14.66-05
131	<a href="/u/4/">Jason</a> wrote on\n\n<a href="/p/31/">How Do I Map, Align, And Plot My Solid Results?</a> : \nHi, I recently performed an RNA immunoprecipitation followed by SOLiD sequencing (50 bp fragmented reads). I haven&#39;t received my first SOLiD sequencing results yet, but I was told I should have them soon. I&#39;ve tried doing my own research on how to map, align, and plot my results but I don&#39;t have a c\n	4	How Do I Map, Align, And Plot My Solid Results?	\N	2010-01-22 04:14:17.38-05
132	<a href="/u/2/">Istvan Albert</a> wrote on\n\n<a href="/p/31/#32">A: How Do I Map, Align, And Plot My Solid Results?</a> : \nPersonally I would advise that if you know someone who can partially perform the task you should have them do it, and ask them to explain and show it to you how they&#39;ve done it.\n\nThe task at hand is complex. The solution always depends immensely on the particulars of the problem, moreover you will b\n	2	A: How Do I Map, Align, And Plot My Solid Results?	\N	2010-01-22 16:13:42.79-05
133	<a href="/u/23/">Giovanni M Dall&#39;Olio</a> wrote on\n\n<a href="/p/33/">Which Operating System Do You Prefer For Bioinformatics?</a> : \nSo, you will probably hate me for asking this question here, as there are lot of forum and blog posts on internet about it and it is also a very subjective question.\n\nHowever, it may be a starting point for a good discussion, if we don&#39;t flame... Which operating system do you usually use for your wo\n	23	Which Operating System Do You Prefer For Bioinformatics?	\N	2010-01-26 16:14:38.623-05
134	<a href="/u/23/">Giovanni M Dall&#39;Olio</a> wrote on\n\n<a href="/p/34/">Which Are The Best Programming Languages To Study For A Bioinformatician?</a> : \nThis is also a very classic question: Which is your favorite programming language in bioinformatics? Which languages would you recommend to a student wishing to enter the world of bioinformatics?\n\nThis topic has already been discussed on the Internet, but I think it would be nice to discuss it here.\n	23	Which Are The Best Programming Languages To Study For A Bioinformatician?	\N	2010-01-26 16:45:06.737-05
135	<a href="/u/2/">Istvan Albert</a> wrote on\n\n<a href="/p/33/#35">A: Which Operating System Do You Prefer For Bioinformatics?</a> : \nOften people are limited to their choices by factors outside of their control. One lab that I work with requires the use of Mac computers another is using Windows mostly. Large scale computations seem to be best suited for Linux systems.\n\nLuckily there is a migration towards unified capabilities acr\n	2	A: Which Operating System Do You Prefer For Bioinformatics?	\N	2010-01-26 21:23:45.583-05
136	<a href="/u/2/">Istvan Albert</a> wrote on\n\n<a href="/p/34/#36">A: Which Are The Best Programming Languages To Study For A Bioinformatician?</a> : \nIt is important to be considerate and not characterize one particular approach negatively. My favorite quote is:\n\nProgramming is pure thought.\n\nHopefully everyone is able to pick an approach that matches their individual way of thinking. While I myself do not program in Perl, I consider it to be one\n	2	A: Which Are The Best Programming Languages To Study For A Bioinformatician?	\N	2010-01-26 21:32:29.45-05
137	<a href="/u/2/">Istvan Albert</a> wrote on\n\n<a href="/p/33/#37">A: Which Operating System Do You Prefer For Bioinformatics?</a> : \nTips for installing software om Max OS X:\n\n\ninstall the Apple developer tools called Xcode http://developer.apple.com/tools/xcode/\ninstall MacPorts from http://www.macports.org/\n\n\nYou can now easily install everything from command line using the port command. List all available software\n\nport list\n\n\n	2	A: Which Operating System Do You Prefer For Bioinformatics?	\N	2010-01-26 21:38:24.477-05
139	<a href="/u/23/">Giovanni M Dall&#39;Olio</a> wrote on\n\n<a href="/p/22/#39">A: Gene Id Conversion Tool</a> : \nYou can also do it with the following services:\n\n\nuniprot - Click on &#39;Id Mapping&#39; from the home page.\nbiomart - choose a database and a version, then put the ids you want to convert under Filters-&amp;gt;Id List limit (select the proper input id in the menu), and then the output ids under &#39;Attributes&#39;. \n	23	A: Gene Id Conversion Tool	\N	2010-01-27 11:08:52.87-05
140	<a href="/u/23/">Giovanni M Dall&#39;Olio</a> wrote on\n\n<a href="/p/4/#40">A: Finding Common Motifs In Sequences</a> : \nMeme has been the first program to be published for doing that.\nAs an alternative you can find one of the EMBOSS tools; if you are scared by a terminal and want to do it from a web-based interface, you can use the EMBOSS tools from galaxy\n\n	23	A: Finding Common Motifs In Sequences	\N	2010-01-28 16:31:50.47-05
141	<a href="/u/23/">Giovanni M Dall&#39;Olio</a> wrote on\n\n<a href="/p/41/">How Much Do You Trust Geneontology?</a> : \nGeneOntology is a nice project to provide a standard terminology for genes and gene functions, to help avoid the use of synonyms and wrong spelling when describing a gene.\n\nI have been using the GeneOntology for a while, but honestly I think that it contains many errors and that many terms have not \n	23	How Much Do You Trust Geneontology?	\N	2010-01-28 17:17:37.437-05
142	<a href="/u/23/">Giovanni M Dall&#39;Olio</a> wrote on\n\n<a href="/p/1/#42">A: Site Use Guidelines</a> : \nThe StackExchange websites have been designed for making questions related to programming and technical issues.\n\nFor example, for this reason, if you try to write a question which starts with &#39;What is your favorite experience...&#39; you get a disclaimer saying that &#39;your question seems to be probably s\n	23	A: Site Use Guidelines	\N	2010-01-28 17:22:04.203-05
143	<a href="/u/23/">Giovanni M Dall&#39;Olio</a> wrote on\n\n<a href="/p/34/#43">A: Which Are The Best Programming Languages To Study For A Bioinformatician?</a> : \nThe choice of a programming language is purely subjective, but when a student asks you which programming language he should start with, you have to make an answer, or at least provide some informations.\n\nI think that a bioinformatician who studies R and at least two or three libraries (lattice/ggplo\n	23	A: Which Are The Best Programming Languages To Study For A Bioinformatician?	\N	2010-01-28 18:58:20.5-05
144	<a href="/u/2/">Istvan Albert</a> wrote on\n\n<a href="/p/41/#44">A: How Much Do You Trust Geneontology?</a> : \nThe GO terms and classifications are primarily an based on opinions and a human interpretation of a small group of people of what the current state of the knowledge is.Thus  are more subjective than say experimental measurements would be. \n\nIn fact it is surprising that it works at all; and it does \n	2	A: How Much Do You Trust Geneontology?	\N	2010-01-28 23:41:29.17-05
145	<a href="/u/4/">Jason</a> wrote on\n\n<a href="/p/41/#45">A: How Much Do You Trust Geneontology?</a> : \nIn my experience it&#39;s case by case. In other words just because you are getting significant p-values, does not mean the results are biologically significant. I once submitted clusters of microarray data and received a bunch of hits that were significant by p-value, but really didn&#39;t have a theme. Th\n	4	A: How Much Do You Trust Geneontology?	\N	2010-01-29 06:50:26.02-05
146	<a href="/u/23/">Giovanni M Dall&#39;Olio</a> wrote on\n\n<a href="/p/46/">What Is Your Experience With The String (Interactions) Database?</a> : \nSTRING is a database of predicted protein-protein interactions at EMBL. It cluster the results from many sources of protein-protein interactions databases, like Mint, etc.., and it also use the informations from KEGG-pathways and reactome, to provide the best annotations for the interactions of a pr\n	23	What Is Your Experience With The String (Interactions) Database?	\N	2010-01-29 12:42:23.043-05
147	<a href="/u/2/">Istvan Albert</a> wrote on\n\n<a href="/p/46/#47">A: What Is Your Experience With The String (Interactions) Database?</a> : \nI have not used STRING in particular but I have worked with protein interactions before (DIP dataset). I recall that even experimentally produced protein-protein interactions may have very large false positive ratios  (as for false negatives, who knows?) Some papers claim that up to 50% of the inter\n	2	A: What Is Your Experience With The String (Interactions) Database?	\N	2010-01-29 15:06:06.18-05
148	<a href="/u/23/">Giovanni M Dall&#39;Olio</a> wrote on\n\n<a href="/p/48/">Where Can I Get The Secondary Structure Of A Protein?</a> : \nAs in the title... I have a protein and I would like to know its secundary structure.\nI couldn&#39;t find it in uniprot, althought I tought they had annotations for it there.\nIn the end I have used a predictor (jpred) but there it should be a database somewhere.\n\n	23	Where Can I Get The Secondary Structure Of A Protein?	\N	2010-02-12 18:33:06.82-05
149	<a href="/u/2/">Istvan Albert</a> wrote on\n\n<a href="/p/48/#49">A: Where Can I Get The Secondary Structure Of A Protein?</a> : \nProtein structure prediction is a complex issue that is likely to require multiple approaches. There are many methods/tools listed at the \n\n\nExpert Protein Analysis System website\n\n\n	2	A: Where Can I Get The Secondary Structure Of A Protein?	\N	2010-02-12 21:01:49.187-05
150	<a href="/u/26/">Nicojo</a> wrote on\n\n<a href="/p/48/#50">A: Where Can I Get The Secondary Structure Of A Protein?</a> : \nI think you found the best answer yourself: use a predictor! There are several out there...\n\nYou suggest that there should be a Secondary Structure Database. I&#39;m not sure that makes much sense, let me explain my point of view (which may not be that of everyone): most often, the data that is found in\n	26	A: Where Can I Get The Secondary Structure Of A Protein?	\N	2010-02-12 22:57:06.68-05
151	<a href="/u/14/">Zhaorong</a> wrote on\n\n<a href="/p/51/">Turn Off Blast Search On Reverse Complement Strand In Blastn</a> : \nI have a quick question:\nHow can I turn off search on reverse complement strand of my query nucleotide sequence in blastn?\n\nFor example, I don&#39;t want &#39;GUAAAGCCAAAUCUUCGGUUA&#39; to be a hit when I use &#39;UAACCGAAGAUUUGGCUUUAC&#39; as the query.\n\nMaybe I missed it when I read the man page, but I really appreci\n	14	Turn Off Blast Search On Reverse Complement Strand In Blastn	\N	2010-02-16 02:13:06.543-05
152	<a href="/u/2/">Istvan Albert</a> wrote on\n\n<a href="/p/51/#52">A: Turn Off Blast Search On Reverse Complement Strand In Blastn</a> : \nThe -S flag can select the strands:\n\n-S  Query strands to search against database \n    (for blast[nx], and tblastx) 3 is both, 1 is top, 2 is bottom [Integer]\n\n\n	2	A: Turn Off Blast Search On Reverse Complement Strand In Blastn	\N	2010-02-16 03:31:37.06-05
153	<a href="/u/27/">Allen Yu</a> wrote on\n\n<a href="/p/53/">How To Do Quality Trimming Of Solid Reads In Colour Space?</a> : \nThe reads returned from the Solid sequencing provider are littered with dots and some bases have a negative quality value. Does anyone know if there is a good method to extract high quality regions from the reads without distorting the reading of bases in colour space?\n\n	27	How To Do Quality Trimming Of Solid Reads In Colour Space?	\N	2010-02-19 08:29:18.733-05
156	<a href="/u/23/">Giovanni M Dall&#39;Olio</a> wrote on\n\n<a href="/p/56/">How To Get The Sequence Of A Genomic Region From Ucsc?</a> : \nLet&#39;s say I want to download the fasta sequence of the region chr1:100000..200000 from the UCSC browser.\nHow do you do that? I can&#39;t find a button to &#39;export to fasta&#39; in the UCSC genome browser. I think that the solution is to click on one of the tracks displayed, but I am not sure of which.\nIf I g\n	23	How To Get The Sequence Of A Genomic Region From Ucsc?	\N	2010-02-21 17:13:39.32-05
157	<a href="/u/2/">Istvan Albert</a> wrote on\n\n<a href="/p/56/#57">A: How To Get The Sequence Of A Genomic Region From Ucsc?</a> : \nThe Genome Browser is for visualization.\n\nTo get data in many formats use the UCSC Table Browser then select the output format of your choice.\n\nYou may also need to select the right group and track to get the data you want.\n\n	2	A: How To Get The Sequence Of A Genomic Region From Ucsc?	\N	2010-02-21 20:11:20.45-05
158	<a href="/u/23/">Giovanni M Dall&#39;Olio</a> wrote on\n\n<a href="/p/58/">What Is The Best Way To Share Scripts Between Members Of A Lab?</a> : \nOne of the most awful problems in my group is avoiding to rewrite scripts that have been already written by others. Since we have different projects and we work with different data, everybody ends up writing its own scripts in his favorite programming language, and it is very frequent to waste an af\n	23	What Is The Best Way To Share Scripts Between Members Of A Lab?	\N	2010-02-25 16:39:15.467-05
159	<a href="/u/30/">Pierre Lindenbaum</a> wrote on\n\n<a href="/p/56/#59">A: How To Get The Sequence Of A Genomic Region From Ucsc?</a> : \nUse the DAS server:\n\nhttp://genome.ucsc.edu/cgi-bin/das/hg19/dna?segment=chr1:100000,200000\n\n	30	A: How To Get The Sequence Of A Genomic Region From Ucsc?	\N	2010-02-25 18:32:53.74-05
160	<a href="/u/31/">Marcos De Carvalho</a> wrote on\n\n<a href="/p/4/#60">A: Finding Common Motifs In Sequences</a> : \nSome time ago I used SOMBRERO (http://bioinf.nuigalway.ie/sombrero/download.html) with a good degree of success on finding motifs in a very diverse set of sequences. They have a Mac version for download as well as parallel versions for Irix and Linux.\n\n	31	A: Finding Common Motifs In Sequences	\N	2010-02-25 18:51:28.29-05
161	<a href="/u/31/">Marcos De Carvalho</a> wrote on\n\n<a href="/p/58/#61">A: What Is The Best Way To Share Scripts Between Members Of A Lab?</a> : \nI would recommend you to setup a wiki for your group. If you do not have a server readily you can always use one of the many wiki services available for free like Wikispaces (www.wikispaces.com).\n\n	31	A: What Is The Best Way To Share Scripts Between Members Of A Lab?	\N	2010-02-25 18:54:49.08-05
162	<a href="/u/2/">Istvan Albert</a> wrote on\n\n<a href="/p/58/#62">A: What Is The Best Way To Share Scripts Between Members Of A Lab?</a> : \nIntegrating with the source code management tool is essential, that way when code gets changed everyone can easily get the updated version. Wikis are also a good idea.\n\n	2	A: What Is The Best Way To Share Scripts Between Members Of A Lab?	\N	2010-02-25 19:24:46.38-05
163	<a href="/u/35/">David Nusinow</a> wrote on\n\n<a href="/p/46/#63">A: What Is Your Experience With The String (Interactions) Database?</a> : \nI&#39;ve been using STRING extensively, but not for protein-protein interactions work. STRING, as you note, is a bit of a mutt in terms of the different data sources it mines. Some that you&#39;re missing include a broad literature-based search, as well as gene expression data sets. So if you&#39;re interested \n	35	A: What Is Your Experience With The String (Interactions) Database?	\N	2010-02-25 22:33:37.903-05
164	<a href="/u/35/">David Nusinow</a> wrote on\n\n<a href="/p/34/#64">A: Which Are The Best Programming Languages To Study For A Bioinformatician?</a> : \nPerl can be quite lovely if you choose to write it well. If you find yourself in need of writing some perl, I&#39;d highly recommend getting the Perl Best Practices book and going through it to learn how to make your perl code not suck. Essential tools for helping with that are perlcritic and perltidy, \n	35	A: Which Are The Best Programming Languages To Study For A Bioinformatician?	\N	2010-02-25 22:41:22.31-05
165	<a href="/u/33/">User 6996</a> wrote on\n\n<a href="/p/33/#65">A: Which Operating System Do You Prefer For Bioinformatics?</a> : \nMy tip: install Cygwin if you are using Windows \n\n	33	A: Which Operating System Do You Prefer For Bioinformatics?	\N	2010-02-25 22:50:25.157-05
166	<a href="/u/33/">User 6996</a> wrote on\n\n<a href="/p/1/#66">A: Site Use Guidelines</a> : \nWho is running this site?\n\n	33	A: Site Use Guidelines	\N	2010-02-25 22:52:10.69-05
167	<a href="/u/38/">Simon Cockell</a> wrote on\n\n<a href="/p/33/#67">A: Which Operating System Do You Prefer For Bioinformatics?</a> : \nAll of the 3 major platforms have their advantages, and I use all 3 practically every day. Mac OS X is my primary desktop OS, for a number of reasons, but mostly because I just seem more productive using it than any of the alternatives. All of my coding work is done over SSH on Linux (almost exclusi\n	38	A: Which Operating System Do You Prefer For Bioinformatics?	\N	2010-02-26 10:51:33.997-05
168	<a href="/u/38/">Simon Cockell</a> wrote on\n\n<a href="/p/58/#68">A: What Is The Best Way To Share Scripts Between Members Of A Lab?</a> : \nIf you want to see the code, but also store associated information, such as expected outputs etc, then a wiki probably is the best choice (we prefer DokuWiki here), although this would involve a lot of manual effort to document each script. \n\nUse of a site such as GitHub would give you version contr\n	38	A: What Is The Best Way To Share Scripts Between Members Of A Lab?	\N	2010-02-26 11:07:14.7-05
169	<a href="/u/30/">Pierre Lindenbaum</a> wrote on\n\n<a href="/p/69/">Using Hdf5 To Store  Bio-Data</a> : \nHi all,\nhas anobody ever used the HDF5 API to store some biological data (genotypes...). I know about this kind of reference (BioHDF...)  but I&#39;m looking for some source code I could browse to understand how I can access data faster.\n\nPierre\n\nPS: hum, I&#39;m a new user. I&#39;m not allowed to add the follo\n	30	Using Hdf5 To Store  Bio-Data	\N	2010-02-26 13:50:17.577-05
170	<a href="/u/40/">Biorelated</a> wrote on\n\n<a href="/p/58/#70">A: What Is The Best Way To Share Scripts Between Members Of A Lab?</a> : \nYou might also want to setup a simple snippets database. Navysnip application by Jason Strutz is easy to install and run if you have ruby and rubyonrails installed.\n\ngit clone git://github.com/navyrain/navysnip.git\n  cd navysnip\n  sudo rake gems:install\n  rake db:migrate\n  ruby script/server\nThen vi\n	40	A: What Is The Best Way To Share Scripts Between Members Of A Lab?	\N	2010-02-26 14:15:16.893-05
171	<a href="/u/42/">Fernando Muñiz</a> wrote on\n\n<a href="/p/69/#71">A: Using Hdf5 To Store  Bio-Data</a> : \nHello Pierre!\n\nI have been talking with the BioHDF guys and from what they tell me, their work will be centered around a number of command-line APIs, written in C, that will address some areas of usage which for now do not seem to overlap. \n\nI have seen this example on their site:\nhttp://www.hdfgrou\n	42	A: Using Hdf5 To Store  Bio-Data	\N	2010-02-26 14:47:41.697-05
172	<a href="/u/23/">Giovanni M Dall&#39;Olio</a> wrote on\n\n<a href="/p/69/#72">A: Using Hdf5 To Store  Bio-Data</a> : \nUnfortunately I don&#39;t have any example to shows you yet.\nI don&#39;t know how to program in C/C++ so I have been looking at two hdf5 wrappers in python, PyTables and H5PY.\n\nPyTables has a database-like approach in which HDF5 is used as a sort of hierarchical database, in which a column can be a table it\n	23	A: Using Hdf5 To Store  Bio-Data	\N	2010-02-26 14:54:03.447-05
173	<a href="/u/2/">Istvan Albert</a> wrote on\n\n<a href="/p/69/#73">A: Using Hdf5 To Store  Bio-Data</a> : \nIn the GeneTrack software we have used HDF to store values for each genomic base. Its main advantage over other storage systems was that it was able to return consecutive values with minimal overhead. \n\nFor example it is extremely fast (ms) in retrieving say 100,000 consecutive values starting with \n	2	A: Using Hdf5 To Store  Bio-Data	\N	2010-02-26 14:56:22.753-05
174	<a href="/u/42/">Fernando Muñiz</a> wrote on\n\n<a href="/p/69/#74">A: Using Hdf5 To Store  Bio-Data</a> : \nWhat I do have is a netCDF-3 based Java application that I could show you.\nNetCDF-3 is basically the same idea as HDF, but quite more limited as it cannot do compound datatypes among other limitations.\n\nBut here&#39;s a small test code example to toy with:\n\npackage netCDF;\n\nimport java.io.File;\nimport u\n	42	A: Using Hdf5 To Store  Bio-Data	\N	2010-02-26 15:26:41.15-05
175	<a href="/u/26/">Nicojo</a> wrote on\n\n<a href="/p/1/#75">A: Site Use Guidelines</a> : \nThis is an excellent initiative: congratulations and thank you for setting it up!\n\nI guess this site will be all the more useful as there are more contributers... So I guess that good questions for the administrator(s) of this site are: \n\n\nDo you have a plan for advertising this site/attracting new \n	26	A: Site Use Guidelines	\N	2010-02-26 15:44:01.49-05
176	<a href="/u/30/">Pierre Lindenbaum</a> wrote on\n\n<a href="/p/76/">Looking For A &#39;Hello World&quot; Plugin For Taverna.</a> : \nHi all,\nI&#39;d like to create a very simple plugin for Taverna 2.0, something very simple like like implementing a &#39;convertDnaToRna&#39;. There is already some source code that can be found on the net e.g. Egon Willighagen&#39;s code at http://github.com/egonw/cdk-taverna but it requires to know Maven and.... \n	30	Looking For A 'Hello World" Plugin For Taverna.	\N	2010-02-26 16:37:25.81-05
177	<a href="/u/44/">Andrew</a> wrote on\n\n<a href="/p/77/">How Do I Convert An Illumina Export File To Bed?</a> : \nI have some illumina data generated from the latest version of the illumina pipeline (1.6.0) I need to convert my data into BED to view in ucsc genome browser.\n\nThis seems like it should be a fairly common task, however, I am unable to find any scripts to convert my data.\n\n	44	How Do I Convert An Illumina Export File To Bed?	\N	2010-02-26 16:49:18.627-05
178	<a href="/u/10/">Question Bot</a> wrote on\n\n<a href="/p/77/#78">A: How Do I Convert An Illumina Export File To Bed?</a> : \nI found a script on another site, Uses perl but I have not checked for correctness:\n\n#!/usr/bin/perl\n\nuse strict;\nuse warnings;\nuse IO::File;\n\nmy $filename = shift @ARGV;\ndie &quot;Usage\\n\\tperl sorted2bed.pl s_X_sorted.txt &amp;gt; s_X_sorted.bed\\n&quot; unless $filename;\nchomp $filename;\n\nmy $fh = new IO::File;\n	10	A: How Do I Convert An Illumina Export File To Bed?	\N	2010-02-26 17:15:18.997-05
179	<a href="/u/23/">Giovanni M Dall&#39;Olio</a> wrote on\n\n<a href="/p/79/">How To Organize A Pipeline Of Small Scripts Together?</a> : \nIn bioinformatics it is very common to end up with a lot of small scripts, each one with a different scope - plotting a chart, converting a file into another format, execute small operations - so it is very important to have a good way to clue them together, to define which should be executed before\n	23	How To Organize A Pipeline Of Small Scripts Together?	\N	2010-02-26 17:49:35.15-05
180	<a href="/u/2/">Istvan Albert</a> wrote on\n\n<a href="/p/79/#80">A: How To Organize A Pipeline Of Small Scripts Together?</a> : \nI don&#39;t have personal experience with this package but it is something that I plan to explore in the near future:\n\nRuffus  a lightweight python module to run computational pipelines. \n\n	2	A: How To Organize A Pipeline Of Small Scripts Together?	\N	2010-02-26 17:58:09.55-05
181	<a href="/u/23/">Giovanni M Dall&#39;Olio</a> wrote on\n\n<a href="/p/79/#81">A: How To Organize A Pipeline Of Small Scripts Together?</a> : \nMy favorite way of defining pipelines is by writing Makefiles, about which you can find a very good introduction in Software Carpentry for Bioinformatics: http://swc.scipy.org/lec/build.html .\n\nAlthough they have been originally developed for compiling programs, Makefiles allow to define which opera\n	23	A: How To Organize A Pipeline Of Small Scripts Together?	\N	2010-02-26 18:03:52.94-05
182	<a href="/u/47/">Chris</a> wrote on\n\n<a href="/p/79/#82">A: How To Organize A Pipeline Of Small Scripts Together?</a> : \nSince I work a lot with Python, I usually write a wrapper method that embeds the external script/program, i.e. calls it, parses its output and returns the desired information. The &#39;glueing&#39; of several such methods then takes place within my Python code that calls all these wrappers. I guess that&#39;s a\n	47	A: How To Organize A Pipeline Of Small Scripts Together?	\N	2010-02-26 18:04:53.577-05
183	<a href="/u/7/">Suk211</a> wrote on\n\n<a href="/p/48/#83">A: Where Can I Get The Secondary Structure Of A Protein?</a> : \nIf you have the PDB file then you can use the standard tool called DSSP , it is supposed to be the gold standard for obtaining secondary structure. In case you just have sequence then I personally prefer PSIPRED , it takes evolutionary information into account to predict the secondary structure . Ac\n	7	A: Where Can I Get The Secondary Structure Of A Protein?	\N	2010-02-26 18:16:41.967-05
184	<a href="/u/53/">Michael Barton</a> wrote on\n\n<a href="/p/79/#84">A: How To Organize A Pipeline Of Small Scripts Together?</a> : \nMy answer would be: don&#39;t bother. I&#39;ve often found that much of the scripts I write are never used again after the initial use. Therefore spending time using a complex framework that considers dependency between scripts is a waste because the results might be negative and you never visit the analysi\n	53	A: How To Organize A Pipeline Of Small Scripts Together?	\N	2010-02-26 21:16:31.97-05
185	<a href="/u/24/">Etal</a> wrote on\n\n<a href="/p/58/#85">A: What Is The Best Way To Share Scripts Between Members Of A Lab?</a> : \nMy lab uses a network-attached storage unit which every Linux workstation mounts by NFS at startup. It was reasonably cheap -- a couple hundred dollars per TB. We also keep copies of public databases on there. We put data sets on there as we&#39;re working on them, and also put the more important script\n	24	A: What Is The Best Way To Share Scripts Between Members Of A Lab?	\N	2010-02-26 21:27:32.303-05
186	<a href="/u/7/">Suk211</a> wrote on\n\n<a href="/p/58/#86">A: What Is The Best Way To Share Scripts Between Members Of A Lab?</a> : \nThis might be useful .\n\nA Quick Guide to Organizing Computational Biology Projects\n\n	7	A: What Is The Best Way To Share Scripts Between Members Of A Lab?	\N	2010-02-26 21:44:04.547-05
187	<a href="/u/55/">Michael Dondrup</a> wrote on\n\n<a href="/p/69/#87">A: Using Hdf5 To Store  Bio-Data</a> : \nThere is also a Perl binding to HDF5: PDL::IO::HDF5\n\nhttp://search.cpan.org/~cerney/PDL-IO-HDF5-0.5/\nThis requires the Perl Data Language (PDL) package. The way, data-structures can be handled, sub-ranges of data can be defined  an data can be manipulated is actually very elegant in PDL such that co\n	55	A: Using Hdf5 To Store  Bio-Data	\N	2010-02-27 22:00:56.14-05
188	<a href="/u/23/">Giovanni M Dall&#39;Olio</a> wrote on\n\n<a href="/p/88/">Agile Programming For Bioinformaticians - Any Suggestions?</a> : \nI am planning to prepare a talk for my workmates, to introduce them the basics of some agile programming methodology, which I think could give us good ideas to improve our working as a team.\n\nMy idea was to take inspiration from extreme programming and explain the rules I like the most: use of A7 ca\n	23	Agile Programming For Bioinformaticians - Any Suggestions?	\N	2010-03-01 14:51:12.3-05
189	<a href="/u/2/">Istvan Albert</a> wrote on\n\n<a href="/p/88/#89">A: Agile Programming For Bioinformaticians - Any Suggestions?</a> : \nI think the approach is unsuited for individuals who are not comfortable with programming in general. There is a long way to go until someone becomes confident in their abilities. Before that this approach is not only ineffective, it might be even be detrimental.\n\nInstead what helps most is transpar\n	2	A: Agile Programming For Bioinformaticians - Any Suggestions?	\N	2010-03-01 15:06:55.973-05
190	<a href="/u/10/">Question Bot</a> wrote on\n\n<a href="/p/90/">Computing The Reverse And Complement Of A Sequence With Biopython</a> : \nAn example that computes the reverse complement of a sequence with BioPython\n\n#\n# Reverse complement example with BioPython\n#\n\nfrom Bio.Seq import Seq\n\n# a separate function to reverse strings (or other iterables)\ndef rev(it):\n    &quot;Reverses an interable and returns it as a string&quot;\n    return &#39;&#39;.join\n	10	Computing The Reverse And Complement Of A Sequence With Biopython	\N	2010-03-01 15:26:09.937-05
191	<a href="/u/39/">Konrad</a> wrote on\n\n<a href="/p/88/#91">A: Agile Programming For Bioinformaticians - Any Suggestions?</a> : \nI would suggest to have a look at Scrum, too. Certain parts would help not only bioinformations. For example estimating the time expenditure of tasks and the resulting burn down charts can be really helpful to see if something is stuck especially when working together on bigger projects.The daily sc\n	39	A: Agile Programming For Bioinformaticians - Any Suggestions?	\N	2010-03-01 15:41:28.687-05
192	<a href="/u/10/">Question Bot</a> wrote on\n\n<a href="/p/92/">(Closed) Computing The Reverse And Complement Of A Sequence With Pygr</a> : \nComputing the reverse complement with the Pygr bioinformatics framework:\n\n#\n# Reverse complement example with pygr\n#\n\nfrom pygr.sequence import Sequence\n\n# needs a separate function to reverse strings\ndef rev(it):\n    &quot;Reverses an interable and returns it as a string&quot;\n    return &#39;&#39;.join(reversed(it)\n	10	Computing The Reverse And Complement Of A Sequence With Pygr	\N	2010-03-01 15:48:25.83-05
193	<a href="/u/45/">Alex</a> wrote on\n\n<a href="/p/5/#93">A: Recommend Easy To Use Microarray Clustering Software</a> : \nPossibly related:\nhttp://mmc.gnets.ncsu.edu/\n\n	45	A: Recommend Easy To Use Microarray Clustering Software	\N	2010-03-01 15:51:52.19-05
194	<a href="/u/23/">Giovanni M Dall&#39;Olio</a> wrote on\n\n<a href="/p/90/#94">A: Computing The Reverse And Complement Of A Sequence With Biopython</a> : \nWouldn&#39;t it better to have a single question titled &#39;How to compute the reverse complement with python&#39; and put all the examples as different answers? Otherwise it seems a bit confusing..\n\n	23	A: Computing The Reverse And Complement Of A Sequence With Biopython	\N	2010-03-01 17:07:15.283-05
195	<a href="/u/24/">Etal</a> wrote on\n\n<a href="/p/79/#95">A: How To Organize A Pipeline Of Small Scripts Together?</a> : \nThe most important thing for me has been keeping a README file at the top of each project directory, where I write down not just how to run the scripts, but why I wrote them in the first place -- coming back to a project after a several-month lull, it&#39;s remarkable difficult to figure out what all th\n	24	A: How To Organize A Pipeline Of Small Scripts Together?	\N	2010-03-01 17:32:26.107-05
196	<a href="/u/24/">Etal</a> wrote on\n\n<a href="/p/90/#96">A: Computing The Reverse And Complement Of A Sequence With Biopython</a> : \nThe Bio.Seq module provides two easy ways to get the complement and reverse complement from a sequence:\n\n\nIf you have a string, use the functions complement(dna) and reverse_complement(dna)\nIf you have a Seq object, use its methods with the same names: dna.complement() and dna.reverse_complement\n\n\nT\n	24	A: Computing The Reverse And Complement Of A Sequence With Biopython	\N	2010-03-01 17:52:22.51-05
197	<a href="/u/59/">Daniel Swan</a> wrote on\n\n<a href="/p/22/#97">A: Gene Id Conversion Tool</a> : \nhttp://idconverter.bioinfo.cnio.es/\n\nIs another possible solution to this, although you might find this is not as up to date as you might like either.\n\n	59	A: Gene Id Conversion Tool	\N	2010-03-01 18:05:13.92-05
198	<a href="/u/55/">Michael Dondrup</a> wrote on\n\n<a href="/p/22/#98">A: Gene Id Conversion Tool</a> : \nBioMart has already been mentioned. It can do much more than ID conversion but it is very useful for conversion purposes, it is regularly updated and you can select different genome builds and all kinds of genomic features. It seems to me that you wish to retrieve GeneIDs linked to Affymetrix IDs. T\n	55	A: Gene Id Conversion Tool	\N	2010-03-01 20:51:25.98-05
199	<a href="/u/10/">Question Bot</a> wrote on\n\n<a href="/p/99/">Fast Interval Intersection Methodologies</a> : \nMost genomic annotations are specified as intervals along the genome. \n\n\nInterval trees have been known to provide an efficient datastructure that allows for very fast overlap querying. \nNested Containment Lists have been proposed as an even faster alternative \n\n\nProvide code examples in your progra\n	10	Fast Interval Intersection Methodologies	\N	2010-03-01 21:01:20.047-05
200	<a href="/u/2/">Istvan Albert</a> wrote on\n\n<a href="/p/99/#100">A: Fast Interval Intersection Methodologies</a> : \nThis code example generates 10,000 intervals then queries them for overlapping regions. Requires only the presence of Python.\n\nThe code below requires the either the installation of the bx python package or alternatively you may just download the quicksect.py module and place it next to the script i\n	2	A: Fast Interval Intersection Methodologies	\N	2010-03-01 21:06:18.193-05
201	<a href="/u/1/">Biostar Community</a> wrote on\n<a href="/p/101/">How to find motifs with Galaxy?</a> :\nI have a few hundred yeast sequences (20-80bp long) and I want to find common motifs (conserved bases at certain indices) in them. I am using a Mac	1	How to find motifs with Galaxy?	\N	2014-05-09 10:39:20.047-04
202	Hello <b>john</b>! Welcome to Biostar <i class="fa fa-globe"></i>!\n\n<p style="padding-top:10px;">\n    We hope you'll find the site useful and our community friendly.\n</p>\n<p>\n    We encourage you to participate:\n    <b>upvote</b> posts that you like, ask <b>questions</b>, write <b>comments</b> and <b>answers</b>, follow posts,\n    bookmark content. You can keep up with the lates content via email (see your user account settings) or RSS feeds.\n</p>\n<p>\n    Together, by sharing the know-how, personal experiences, tips and tricks of the trade\n    we can become more productive and successful as scientists.\n</p>\n\n	1	Welcome!	\N	2014-05-09 10:39:23.89-04
\.


--
-- Name: messages_messagebody_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('messages_messagebody_id_seq', 202, true);


--
-- Data for Name: planet_blog; Type: TABLE DATA; Schema: public; Owner: -
--

COPY planet_blog (id, title, "desc", feed, link, active, list_order) FROM stdin;
1	Kevin's GATTACA World	My Weblog on Bioinformatics, Genome Science and Next Generation Sequencing	http://feeds.feedburner.com/MyWeblogOnBioinformaticsGenomeScienceNextGenerationSequencing	http://kevin-gattaca.blogspot.com/	t	0
2	Omics! Omics!	A computational biologist's personal views on new technologies &amp; publications on genomics &amp; proteomics and their impact on drug discovery	http://feeds.feedburner.com/OmicsOmics	http://omicsomics.blogspot.com/	t	0
3	YOKOFAKUN		http://plindenbaum.blogspot.com/feeds/posts/default	http://plindenbaum.blogspot.com/	t	0
4	What You're Doing Is Rather Desperate	Notes from the life of a computational biologist	http://nsaunders.wordpress.com/feed/	http://nsaunders.wordpress.com	t	0
5	Blue Collar Bioinformatics		http://feeds2.feedburner.com/bcbio	http://bcbio.wordpress.com	t	0
\.


--
-- Name: planet_blog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('planet_blog_id_seq', 5, true);


--
-- Data for Name: planet_blogpost; Type: TABLE DATA; Schema: public; Owner: -
--

COPY planet_blogpost (id, blog_id, uid, title, content, html, creation_date, insert_date, published, link) FROM stdin;
1	1	tag:blogger.com,1999:blog-8959227089815463704.post-6750884431982311373	Geographic population structure analysis of worldwide human populations infers their biogeographical origins : Nature Communications : Nature Publishing Group	  There's no stopping a cheesy geneticist when he puts his mind to making a research idea stick ... like coming up with acronyms like GPS to determine biogeographical origin ...   http://www.nature.com/ncomms/2014/140429/ncomms4513/full/ncomms4513.html  	  There's no stopping a cheesy geneticist when he puts his mind to making a research idea stick ... like coming up with acronyms like GPS to determine biogeographical origin ...   http://www.nature.com/ncomms/2014/140429/ncomms4513/full/ncomms4513.html  	2014-05-01 20:00:00-04	2014-05-09 10:47:06.262-04	f	http://feedproxy.google.com/~r/MyWeblogOnBioinformaticsGenomeScienceNextGenerationSequencing/~3/ALuC5xFhtc8/geographic-population-structure.html
2	1	tag:blogger.com,1999:blog-8959227089815463704.post-894146776514373738	Gut check: Microbes in our stomachs may be making us miserable - Salon.com	Seems like gut microbiome is getting more and more air time in news.   http://www.salon.com/2014/04/28/gut_check_microbes_in_your_stomach_may_be_making_you_miserable_partner/?utm_source=facebook&amp;utm_medium=socialflow    	Seems like gut microbiome is getting more and more air time in news.   http://www.salon.com/2014/04/28/gut_check_microbes_in_your_stomach_may_be_making_you_miserable_partner/?utm_source=facebook&amp;utm_medium=socialflow    	2014-04-27 20:00:00-04	2014-05-09 10:47:06.269-04	f	http://feedproxy.google.com/~r/MyWeblogOnBioinformaticsGenomeScienceNextGenerationSequencing/~3/h_9na9QwXYs/gut-check-microbes-in-our-stomachs-may.html
3	1	tag:blogger.com,1999:blog-8959227089815463704.post-2952401788432414585	Fwd: Welcome to the Google Genomics Preview	Sweet!!---------- Forwarded message ----------  Welcome to the Google Genomics Preview! You've been approved for early access to the API.       The goal of the Genomics API is to encourage interoperability and build a foundation to store, process, search, analyze and share tens of petabytes of genomic data.       We've loaded sample data from public BAM files:      * The complete 1000 Genomes Project      * Selections from the Personal Genome Project      How to get started:      * Follow the instructions in the developer documentation       * Try the sample genome browser which calls the API      * Try out the other open source examples -- an R script, Python MapReduce, and a Java file-based implementation      * Write your own code to call the API and explore new uses      This is only the beginning. Your feedback will be essential to make the API useful. Please submit feature requests, bugs and suggestions on our GitHub page.       Thank you for being part of the first wave. If you'd rather join with a different email address (Gmail or Google Apps domain), please fill out the request form with that address too, and we'll grant access soon. Thank you for your interest!      Sincerely,      The Google Genomics team      	Sweet!!---------- Forwarded message ----------  Welcome to the Google Genomics Preview! You've been approved for early access to the API.       The goal of the Genomics API is to encourage interoperability and build a foundation to store, process, search, analyze and share tens of petabytes of genomic data.       We've loaded sample data from public BAM files:      * The complete 1000 Genomes Project      * Selections from the Personal Genome Project      How to get started:      * Follow the instructions in the developer documentation       * Try the sample genome browser which calls the API      * Try out the other open source examples -- an R script, Python MapReduce, and a Java file-based implementation      * Write your own code to call the API and explore new uses      This is only the beginning. Your feedback will be essential to make the API useful. Please submit feature requests, bugs and suggestions on our GitHub page.       Thank you for being part of the first wave. If you'd rather join with a different email address (Gmail or Google Apps domain), please fill out the request form with that address too, and we'll grant access soon. Thank you for your interest!      Sincerely,      The Google Genomics team      	2014-04-19 20:00:00-04	2014-05-09 10:47:06.281-04	f	http://feedproxy.google.com/~r/MyWeblogOnBioinformaticsGenomeScienceNextGenerationSequencing/~3/cujIVDCBhYo/fwd-welcome-to-google-genomics-preview.html
4	2	tag:blogger.com,1999:blog-36768584.post-5086008806446578077	NGS Saves A Young Life	One of the most electrifying talks at AGBT this year was given by Joe DeRisi of UCSF, who gave a brief intro on the difficulty of diagnosing the root cause of encephalitis (as it can be autoimmune, viral, protozoal, bacterial and probably a few other causes) and then ran down a gripping case history which seemed straight out of House.Read more »	One of the most electrifying talks at AGBT this year was given by Joe DeRisi of UCSF, who gave a brief intro on the difficulty of diagnosing the root cause of encephalitis (as it can be autoimmune, viral, protozoal, bacterial and probably a few other causes) and then ran down a gripping case history which seemed straight out of House.Read more »	2014-02-25 19:00:00-05	2014-05-09 10:47:07.033-04	f	http://omicsomics.blogspot.com/2014/02/ngs-saves-young-life.html
5	2	tag:blogger.com,1999:blog-36768584.post-2256957260103276078	A Sunset for Draft Genomes?	The sun set during AGBT 2014 for a final time over a week ago.  The posters have long been down, and perhaps the liver enzyme levels of the attendees are now down to normal as well.  This year’s conference underscored a possibility that was suggested last year: that the era of the poorly connected, low quality draft genome is headed for the sunset as wellRead more »	The sun set during AGBT 2014 for a final time over a week ago.  The posters have long been down, and perhaps the liver enzyme levels of the attendees are now down to normal as well.  This year’s conference underscored a possibility that was suggested last year: that the era of the poorly connected, low quality draft genome is headed for the sunset as wellRead more »	2014-02-24 19:00:00-05	2014-05-09 10:47:07.051-04	f	http://omicsomics.blogspot.com/2014/02/a-sunset-for-draft-genomes.html
6	2	tag:blogger.com,1999:blog-36768584.post-6988867569351222907	How will you deal with GRCh38?	I was foolishly attempting to catch up with Twitter last night during Valerie Schneider's AGBT talk last night on the new human reference, GRCh38. After all, my personal answer to my title is nothing, because this isn't a field I work in.  But Dr. Schneider is a very good speaker and I could not help but have my attention pulled in.  While clearly not the final word on a human reference, this new edition fixes many gaps, expands the coverage of highly polymorphic regions, and even models the difficult to assemble centromeres.  Better assembly, combined with emerging tools to better handle those complex regions via graph representations, means better mapping send better variant calls.So, a significant advance, but a bit unpleasant one if you are in the space.  You now have several ugly options before you with regard to your prior data mapped to an earlier reference.The do nothing option must appeal to some. Forgo the advantages of the new reference and just stick to the old. Perhaps start new projects on the new one, leading to a cacophony of internal tools dealing with different versions, with an ongoing risk of mismatched results. Also, cross your fingers that none of changes might be revised if analyzed against the new reference.  Perhaps this route will be rationalized as healthy procrastination until a well-vetted set of graph-aware mappers exist, but once you start putting-off it is hard to stop doing so. The other pole would be to embrace the new reference whole-heartedly and realign all the old data against the new reference. After burning a lot of compute cycles and storage space running in place, spend a lot of time reconciling old and new results. Then decide whether to ditch all your old alignments, or suffer an even larger storage burden.A tempting shortcut would be to just remap alignments and variants by the known relationships between the two references. After all, the vast majority of the results will simply shift coordinates a bit, but with no other effects.  In theory, one could estimate all the map regions that are now suspect and simply realign the reads which map to those regions, plus attempt to place reads that previously failed to map. Again reconciliation of results, but on a much reduced scale.None would seem particularly appealing options. Perhaps that latter route will be a growth industry of new tools acting on BAM, CRAM or VCF which themselves will provide a morass of competing claims of accuracy, efficiency and speed. Doesn't make me at all in a hurry to leave a cozy world of haploid genomes that are often finished by a simple pipeline!	I was foolishly attempting to catch up with Twitter last night during Valerie Schneider's AGBT talk last night on the new human reference, GRCh38. After all, my personal answer to my title is nothing, because this isn't a field I work in.  But Dr. Schneider is a very good speaker and I could not help but have my attention pulled in.  While clearly not the final word on a human reference, this new edition fixes many gaps, expands the coverage of highly polymorphic regions, and even models the difficult to assemble centromeres.  Better assembly, combined with emerging tools to better handle those complex regions via graph representations, means better mapping send better variant calls.So, a significant advance, but a bit unpleasant one if you are in the space.  You now have several ugly options before you with regard to your prior data mapped to an earlier reference.The do nothing option must appeal to some. Forgo the advantages of the new reference and just stick to the old. Perhaps start new projects on the new one, leading to a cacophony of internal tools dealing with different versions, with an ongoing risk of mismatched results. Also, cross your fingers that none of changes might be revised if analyzed against the new reference.  Perhaps this route will be rationalized as healthy procrastination until a well-vetted set of graph-aware mappers exist, but once you start putting-off it is hard to stop doing so. The other pole would be to embrace the new reference whole-heartedly and realign all the old data against the new reference. After burning a lot of compute cycles and storage space running in place, spend a lot of time reconciling old and new results. Then decide whether to ditch all your old alignments, or suffer an even larger storage burden.A tempting shortcut would be to just remap alignments and variants by the known relationships between the two references. After all, the vast majority of the results will simply shift coordinates a bit, but with no other effects.  In theory, one could estimate all the map regions that are now suspect and simply realign the reads which map to those regions, plus attempt to place reads that previously failed to map. Again reconciliation of results, but on a much reduced scale.None would seem particularly appealing options. Perhaps that latter route will be a growth industry of new tools acting on BAM, CRAM or VCF which themselves will provide a morass of competing claims of accuracy, efficiency and speed. Doesn't make me at all in a hurry to leave a cozy world of haploid genomes that are often finished by a simple pipeline!	2014-02-12 19:00:00-05	2014-05-09 10:47:07.059-04	f	http://omicsomics.blogspot.com/2014/02/how-will-you-deal-with-grch38.html
7	3	tag:blogger.com,1999:blog-14688252.post-1413366006721621665	Parallelizing #RStats using #make	In the current post, I'll show how to use R as the main SHELL of GNU-Make instead of using a classical linux shell like 'bash'. Why would you do this ? awesomeness\nMake-based workflow management\nMake-based execution with --jobs.  GNU make knows how to execute several recipes at once. Normally, make will execute only one recipe at a time, waiting for it to finish before executing the next. However	In the current post, I'll show how to use R as the main SHELL of GNU-Make instead of using a classical linux shell like 'bash'. Why would you do this ? awesomeness\nMake-based workflow management\nMake-based execution with --jobs.  GNU make knows how to execute several recipes at once. Normally, make will execute only one recipe at a time, waiting for it to finish before executing the next. However	2014-01-29 19:00:00-05	2014-05-09 10:47:07.839-04	f	http://plindenbaum.blogspot.com/2014/01/parallelizing-rstats-using-make.html
8	3	tag:blogger.com,1999:blog-14688252.post-4555212046957957643	Mapping the UCSC/Web-Sequences to a world map.	People at the UCSC have recently released a new track for the GenomeBrowser\nWe BLATted the Internet! The DNA sequences from 40 billion webpages mapped to hg19 and other species: http://t.co/5XAsFCguE2/ UCSC Genome Browser (@GenomeBrowser) January 23, 2014"We're pleased to announce the release of the Web Sequences track on the UCSC Genome Browser. This track, produced in collaboration with	People at the UCSC have recently released a new track for the GenomeBrowser\nWe BLATted the Internet! The DNA sequences from 40 billion webpages mapped to hg19 and other species: http://t.co/5XAsFCguE2/ UCSC Genome Browser (@GenomeBrowser) January 23, 2014"We're pleased to announce the release of the Web Sequences track on the UCSC Genome Browser. This track, produced in collaboration with	2014-01-28 19:00:00-05	2014-05-09 10:47:07.846-04	f	http://plindenbaum.blogspot.com/2014/01/mapping-ucscweb-sequences-to-world-map.html
9	3	tag:blogger.com,1999:blog-14688252.post-842379474834141569	(video) #renabigo2013 "Make &amp; Bioinformatics:everything but #usegalaxy"	(In French): "Mon Make à moi": parallélisations, workflows et pipelines pour le NGS, tout sauf Galaxy [34:50 mn]\nLes workflows en Bio-Informatique\nCentre Inria de Rennes - IRISA\n29 Novembre 2013	(In French): "Mon Make à moi": parallélisations, workflows et pipelines pour le NGS, tout sauf Galaxy [34:50 mn]\nLes workflows en Bio-Informatique\nCentre Inria de Rennes - IRISA\n29 Novembre 2013	2013-12-19 19:00:00-05	2014-05-09 10:47:07.851-04	f	http://plindenbaum.blogspot.com/2013/12/video-renabigo2013-make.html
10	4	http://nsaunders.wordpress.com/?p=3727	When is db=all not db=all? When you use Entrez ELink.	Just a brief technical note. I figured that for a given compound in PubChem, it would be interesting to know whether that compound had been used in a high-throughput experiment, which you might find in GEO. Very easy using the E-utilities, as implemented in the R package rentrez: Browsing the rentrez documentation, I note that […]	Just a brief technical note. I figured that for a given compound in PubChem, it would be interesting to know whether that compound had been used in a high-throughput experiment, which you might find in GEO. Very easy using the E-utilities, as implemented in the R package rentrez: Browsing the rentrez documentation, I note that […]	2014-04-28 20:00:00-04	2014-05-09 10:47:08.508-04	f	http://nsaunders.wordpress.com/2014/04/30/when-is-dball-not-dball-when-you-use-entrez-elink/
11	4	http://nsaunders.wordpress.com/?p=3724	On the road: CSS and eResearch Conference 2014	Next week I’ll be in Melbourne for one of my favourite meetings, the annual Computational and Simulation Sciences and eResearch Conference. The main reason for my visit is the Bioinformatics FOAM workshop. Day 1 (March 27) is not advertised since it is an internal CSIRO day, but I’ll be presenting a talk titled “SQL, noSQL […]	Next week I’ll be in Melbourne for one of my favourite meetings, the annual Computational and Simulation Sciences and eResearch Conference. The main reason for my visit is the Bioinformatics FOAM workshop. Day 1 (March 27) is not advertised since it is an internal CSIRO day, but I’ll be presenting a talk titled “SQL, noSQL […]	2014-03-19 20:00:00-04	2014-05-09 10:47:08.515-04	f	http://nsaunders.wordpress.com/2014/03/20/on-the-road-css-and-eresearch-conference-2014/
12	4	http://nsaunders.wordpress.com/?p=3675	“Advance” access and DOIs: what’s the problem?	When I arrive at work, the first task for the day is “check feeds”. If I’m lucky, in the “journal TOCs” category, there will be an abstract that looks interesting, like this one on the left (click for larger version). Sometimes, the title is a direct link to the article at the journal website. Often […]	When I arrive at work, the first task for the day is “check feeds”. If I’m lucky, in the “journal TOCs” category, there will be an abstract that looks interesting, like this one on the left (click for larger version). Sometimes, the title is a direct link to the article at the journal website. Often […]	2014-03-08 19:00:00-05	2014-05-09 10:47:08.521-04	f	http://nsaunders.wordpress.com/2014/03/10/advance-access-and-dois-whats-the-problem/
13	5	http://bcbio.wordpress.com/?p=570	Improving reproducibility and installation of genomic analysis pipelines with Docker	Motivation bcbio-nextgen is a community developed, best-practice pipeline for genomic data processing, performing automated variant calling and RNA-seq analyses from high throughput sequencing data. It has an automated installation script that sets up the code and third party tools used during analysis, and we’ve been working on improving the process to make getting started with […]	Motivation bcbio-nextgen is a community developed, best-practice pipeline for genomic data processing, performing automated variant calling and RNA-seq analyses from high throughput sequencing data. It has an automated installation script that sets up the code and third party tools used during analysis, and we’ve been working on improving the process to make getting started with […]	2014-03-05 19:00:00-05	2014-05-09 10:47:10.532-04	f	http://feedproxy.google.com/~r/bcbio/~3/e6pn3H4dKBk/
14	5	http://bcbio.wordpress.com/?p=540	Updated comparison of variant detection methods: Ensemble, FreeBayes and minimal BAM preparation pipelines	Variant evaluation overview I previously discussed our approach for evaluating variant detection methods using a highly confident set of reference calls provided by NIST’s Genome in a Bottle consortium for the NA12878 human HapMap genome, In this post, I’ll update those conclusions based on recent improvements in GATK and FreeBayes. The comparisons use bcbio-nextgen, an […]	Variant evaluation overview I previously discussed our approach for evaluating variant detection methods using a highly confident set of reference calls provided by NIST’s Genome in a Bottle consortium for the NA12878 human HapMap genome, In this post, I’ll update those conclusions based on recent improvements in GATK and FreeBayes. The comparisons use bcbio-nextgen, an […]	2013-10-20 20:00:00-04	2014-05-09 10:47:10.54-04	f	http://feedproxy.google.com/~r/bcbio/~3/GItde4TSDGQ/
15	5	http://bcbio.wordpress.com/?p=524	Summary from Bioinformatics Open Science Codefest 2013: Tools, infrastructure, standards and visualization	The 2013 Bioinformatics Open Source Conference (BOSC) starts tomorrow in Berlin, Germany. It’s a yearly conference devoted to community-based software development projects supporting biological research. Members of the Open Bioinformatics Foundation discuss implementations and approaches to better provide interoperable and reusable software, libraries and pipelines. For the past five years, a two day Codefest and […]	The 2013 Bioinformatics Open Source Conference (BOSC) starts tomorrow in Berlin, Germany. It’s a yearly conference devoted to community-based software development projects supporting biological research. Members of the Open Bioinformatics Foundation discuss implementations and approaches to better provide interoperable and reusable software, libraries and pipelines. For the past five years, a two day Codefest and […]	2013-07-17 20:00:00-04	2014-05-09 10:47:10.547-04	f	http://feedproxy.google.com/~r/bcbio/~3/9HApjLRjbrs/
\.


--
-- Name: planet_blogpost_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('planet_blogpost_id_seq', 15, true);


--
-- Data for Name: posts_emailentry; Type: TABLE DATA; Schema: public; Owner: -
--

COPY posts_emailentry (id, post_id, text, creation_date, sent_at, status) FROM stdin;
\.


--
-- Name: posts_emailentry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('posts_emailentry_id_seq', 1, false);


--
-- Data for Name: posts_emailsub; Type: TABLE DATA; Schema: public; Owner: -
--

COPY posts_emailsub (id, email, status) FROM stdin;
\.


--
-- Name: posts_emailsub_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('posts_emailsub_id_seq', 1, false);


--
-- Data for Name: posts_post; Type: TABLE DATA; Schema: public; Owner: -
--

COPY posts_post (id, title, author_id, lastedit_user_id, rank, status, type, vote_count, view_count, reply_count, comment_count, book_count, changed, subs_count, thread_score, creation_date, lastedit_date, sticky, has_accepted, root_id, parent_id, content, tag_val, site_id, html) FROM stdin;
8	A: Finding Common Motifs In Sequences	6	6	0	1	1	3	0	0	0	0	t	0	0	2009-09-30 21:32:29.097-04	2009-09-30 21:32:29.097-04	f	f	4	4	<p>You can also use MEME:  <a href='http://meme.sdsc.edu/'>http://meme.sdsc.edu/</a>.</p>\n		\N	<p>You can also use MEME:  <a rel="nofollow" href="http://meme.sdsc.edu/">http://meme.sdsc.edu/</a>.</p>\n
3	A: How Do I Convert From Bed Format To Gff Format?	2	2	0	1	1	1	0	0	0	0	t	0	0	2009-09-30 16:56:18.353-04	2009-09-30 21:46:25.51-04	f	f	2	2	<p>Both formats are tab delimited text files used to represent DNA features in genomes. The order of columns between the two are different, there are also columns that correspond to attributes missing from one or the other format. Nonetheless <strong>the most important</strong> difference between the two is the coordinate systems that they assume. </p>\n\n<p>The <a href='http://genome.ucsc.edu/FAQ/FAQformat#format1'>BED</a> format developed at <code>UCSC</code> uses a zero based indexing and an open end interval whereas the <a href='http://www.sanger.ac.uk/Software/formats/GFF/GFF_Spec.shtml'>GFF</a> format developed at <code>Sanger</code> assumes a 1 based coordinate system that includes both start and end coordinates. Therefore</p>\n\n<p>The <code>[0,100]</code> interval in <code>BED</code> format corresponds to <code>[1,100]</code> in <code>GFF</code> format and both are <code>100</code> base long. That the first element in BED format will be have the index of <code>0</code> where the last <code>100th</code> element will have the index of <code>99</code>! Whereas in <code>GFF</code> the first element will have the index of <code>1</code> and the last element will have the index of <code>100</code>.</p>\n\n<p>To convert between the two you may use <a href='http://main.g2.bx.psu.edu/'>Galaxy</a> and select the section called <code>Select Formats</code> that will list various transformation options.</p>\n		\N	<p>Both formats are tab delimited text files used to represent DNA features in genomes. The order of columns between the two are different, there are also columns that correspond to attributes missing from one or the other format. Nonetheless <strong>the most important</strong> difference between the two is the coordinate systems that they assume. </p>\n\n<p>The <a rel="nofollow" href="http://genome.ucsc.edu/FAQ/FAQformat#format1">BED</a> format developed at <code>UCSC</code> uses a zero based indexing and an open end interval whereas the <a rel="nofollow" href="http://www.sanger.ac.uk/Software/formats/GFF/GFF_Spec.shtml">GFF</a> format developed at <code>Sanger</code> assumes a 1 based coordinate system that includes both start and end coordinates. Therefore</p>\n\n<p>The <code>[0,100]</code> interval in <code>BED</code> format corresponds to <code>[1,100]</code> in <code>GFF</code> format and both are <code>100</code> base long. That the first element in BED format will be have the index of <code>0</code> where the last <code>100th</code> element will have the index of <code>99</code>! Whereas in <code>GFF</code> the first element will have the index of <code>1</code> and the last element will have the index of <code>100</code>.</p>\n\n<p>To convert between the two you may use <a rel="nofollow" href="http://main.g2.bx.psu.edu/">Galaxy</a> and select the section called <code>Select Formats</code> that will list various transformation options.</p>\n
6	Test By Zhenhai	5	2	0	3	0	0	2	0	0	0	t	7	0	2009-09-30 20:49:39.563-04	2009-09-30 20:57:55.26-04	f	f	6	6	<p>Hi, I just created my user id a few minutes ago. </p>\n\n<p>Post this question to see how it works.</p>\n	test	\N	<p>Hi, I just created my user id a few minutes ago. </p>\n\n<p>Post this question to see how it works.</p>\n
7	A: Finding Common Motifs In Sequences	5	5	0	1	1	3	0	0	0	0	t	0	0	2009-09-30 20:55:02.457-04	2009-09-30 20:55:02.457-04	f	f	4	4	<p>try this out?</p>\n\n<p><a href='http://fraenkel.mit.edu/webmotifs/form.html'>http://fraenkel.mit.edu/webmotifs/form.html</a></p>\n		\N	<p>try this out?</p>\n\n<p><a rel="nofollow" href="http://fraenkel.mit.edu/webmotifs/form.html">http://fraenkel.mit.edu/webmotifs/form.html</a></p>\n
9	A: Finding Common Motifs In Sequences	7	2	0	1	1	0	0	0	0	0	t	0	0	2009-09-30 21:35:28.02-04	2009-10-01 03:09:51.16-04	f	f	4	4	<pre>\nACGGGCCCGACGATGCGTCGTA\n\nACGTACGTCGAACCGTCGTCGT\n\nACGTGCGTCGAAACGTCAGTCG\n\nACGGGTTCGATCGTCGTCGTCG\n</pre>\n\n<p>may be in Python I will break down the first sequence of required motif length into a sliding window and will search for those list of motifs in the rest of sequences using regular expression in python using <code>re.search()</code> method.</p>\n		\N	<pre>ACGGGCCCGACGATGCGTCGTA\n\nACGTACGTCGAACCGTCGTCGT\n\nACGTGCGTCGAAACGTCAGTCG\n\nACGGGTTCGATCGTCGTCGTCG\n</pre>\n\n<p>may be in Python I will break down the first sequence of required motif length into a sliding window and will search for those list of motifs in the rest of sequences using regular expression in python using <code>re.search()</code> method.</p>\n
19	A: Recommend Easy To Use Microarray Clustering Software	5	5	0	1	1	1	0	0	0	0	t	0	0	2009-10-16 14:25:38.237-04	2009-10-16 14:25:38.237-04	f	f	5	5	<p>I would recommend a combination of cluster and treeview.</p>\n\n<p>pretty powerful!</p>\n		\N	<p>I would recommend a combination of cluster and treeview.</p>\n\n<p>pretty powerful!</p>\n
11	A: How To Generate Multi-Nucleotide Occupancy Counts For Each Coordinate Of My Read	2	2	0	1	1	2	0	0	0	0	t	0	0	2009-10-05 18:03:01.06-04	2009-10-13 17:00:00.047-04	f	f	10	10	<p>The code snippet below will populate the <code>store</code> dictionary keyed by the nucleotide patterns and values as lists that contain the occupancy for each index. (Updated answer now includes arbitrary lenght nucleotide counts)::</p>\n\n<pre><code>from itertools import count\n\ndef pattern_update(sequence, width=2, store={}):\n    """\n    Accumulates nucleotide patterns of a certain width with \n    position counts at each index.\n    """\n\n    # open intervals need a padding at end for proper slicing\n    size  = len(sequence) + 1\n\n    def zeroes():\n        "Generates an empty array that holds the positions"\n        return [ 0 ] * (size - width)\n\n    # these are the end indices\n    ends = range(width, size)\n\n    for lo, hi in zip(count(), ends):\n        # upon encoutering a missing key initialize \n        # that value for that key to the return value of the empty() function\n        key = sequence[lo:hi]\n        store.setdefault(key, zeroes())[lo] += 1\n\n    return store\n</code></pre>\n\n<p>The code at <a href='http://github.com/ialbert/biostar-codesample/blob/master/python/multipatt.py'>multipatt.py</a> demonstrates its use in a full program. Set the <code>size</code> to the maximal possible sequence size. A typical use case::</p>\n\n<pre><code>store = {}\nseq1 = 'ATGCT'\npattern_update(seq1, width=2, store=store)    \n\nseq2 = 'ATCGC'\npattern_update(seq2, width=2, store=store)    \n\nprint store\n</code></pre>\n\n<p>will print::</p>\n\n<pre><code>{'CG': [0, 0, 1, 0], 'GC': [0, 0, 1, 1], 'AT': [2, 0, 0, 0], \n'TG': [0, 1, 0, 0], 'TC': [0, 1, 0, 0], 'CT': [0, 0, 0, 1]}\n</code></pre>\n		\N	<p>The code snippet below will populate the <code>store</code> dictionary keyed by the nucleotide patterns and values as lists that contain the occupancy for each index. (Updated answer now includes arbitrary lenght nucleotide counts)::</p>\n\n<pre><code>from itertools import count\n\ndef pattern_update(sequence, width=2, store={}):\n    """\n    Accumulates nucleotide patterns of a certain width with \n    position counts at each index.\n    """\n\n    # open intervals need a padding at end for proper slicing\n    size  = len(sequence) + 1\n\n    def zeroes():\n        "Generates an empty array that holds the positions"\n        return [ 0 ] * (size - width)\n\n    # these are the end indices\n    ends = range(width, size)\n\n    for lo, hi in zip(count(), ends):\n        # upon encoutering a missing key initialize \n        # that value for that key to the return value of the empty() function\n        key = sequence[lo:hi]\n        store.setdefault(key, zeroes())[lo] += 1\n\n    return store\n</code></pre>\n\n<p>The code at <a rel="nofollow" href="http://github.com/ialbert/biostar-codesample/blob/master/python/multipatt.py">multipatt.py</a> demonstrates its use in a full program. Set the <code>size</code> to the maximal possible sequence size. A typical use case::</p>\n\n<pre><code>store = {}\nseq1 = 'ATGCT'\npattern_update(seq1, width=2, store=store)    \n\nseq2 = 'ATCGC'\npattern_update(seq2, width=2, store=store)    \n\nprint store\n</code></pre>\n\n<p>will print::</p>\n\n<pre><code>{'CG': [0, 0, 1, 0], 'GC': [0, 0, 1, 1], 'AT': [2, 0, 0, 0], \n'TG': [0, 1, 0, 0], 'TC': [0, 1, 0, 0], 'CT': [0, 0, 0, 1]}\n</code></pre>\n
10	How To Generate Multi-Nucleotide Occupancy Counts For Each Coordinate Of My Reads?	10	2	0	1	0	2	18	1	0	0	t	14	4	2009-10-05 17:51:37.043-04	2009-10-13 16:53:15.19-04	f	f	10	10	<p>I need to generate nucleotide occupancy counts for each position of a given sequence then summed over each of the input sequences. An example desired output (for di-nucleotide AT):</p>\n\n<p><img src='http://github.com/ialbert/biostar-codesample/raw/master/python/images/dinuc.png' alt='dinucleotide occupancy' /></p>\n	nucleotides	\N	<p>I need to generate nucleotide occupancy counts for each position of a given sequence then summed over each of the input sequences. An example desired output (for di-nucleotide AT):</p>\n\n<p><img src="http://github.com/ialbert/biostar-codesample/raw/master/python/images/dinuc.png" alt="dinucleotide occupancy"></p>\n
12	A: Recommend Easy To Use Microarray Clustering Software	2	2	0	1	1	2	0	0	0	0	t	0	0	2009-10-05 18:09:57.673-04	2009-10-05 18:09:57.673-04	f	f	5	5	<p>One of my favorites is the <a href='http://www.tm4.org/mev.html'>MEV</a> micro-array data analysis tool.\nIt is simple to use and it has a very large number of features. </p>\n\n<p>Works well for any type of data. You can also load into it data from a file that is in a simple text format:</p>\n\n<pre>\nGENE1, value1, value2\nGENE2, value1, value2\n</pre>\n\n<p>Feel free to post your favorite clustering tool.</p>\n		\N	<p>One of my favorites is the <a rel="nofollow" href="http://www.tm4.org/mev.html">MEV</a> micro-array data analysis tool.\nIt is simple to use and it has a very large number of features. </p>\n\n<p>Works well for any type of data. You can also load into it data from a file that is in a simple text format:</p>\n\n<pre>GENE1, value1, value2\nGENE2, value1, value2\n</pre>\n\n<p>Feel free to post your favorite clustering tool.</p>\n
14	A: Chip Dna Deep Sequence	2	2	0	1	1	0	0	0	0	0	t	0	0	2009-10-06 22:10:32.73-04	2009-10-06 22:10:32.73-04	f	f	13	13	<p>I recall that our first samples that we ran on the Solid sequencer have had bad performance. Not quite an 80% loss but around 40%-60% reads were unmappable (yeast). Some other lab members will hopefully chime in with more details. </p>\n		\N	<p>I recall that our first samples that we ran on the Solid sequencer have had bad performance. Not quite an 80% loss but around 40%-60% reads were unmappable (yeast). Some other lab members will hopefully chime in with more details. </p>\n
15	A: Chip Dna Deep Sequence	5	5	0	1	1	1	0	0	0	0	t	0	0	2009-10-06 22:41:24.877-04	2009-10-06 22:41:24.877-04	f	f	13	13	<p>Hi there,</p>\n\n<p>We have done numbers of SOLiD sequencing run on yeast samples. Normally there are only 30-40 percent of total tags can be uniquely mapped back to yeast genome. </p>\n\n<p>What I would recommend is do it on solexa. You get much higher quality tags.</p>\n\n<p>cheers,</p>\n		\N	<p>Hi there,</p>\n\n<p>We have done numbers of SOLiD sequencing run on yeast samples. Normally there are only 30-40 percent of total tags can be uniquely mapped back to yeast genome. </p>\n\n<p>What I would recommend is do it on solexa. You get much higher quality tags.</p>\n\n<p>cheers,</p>\n
16	A: Chip Dna Deep Sequence	13	13	0	1	1	1	0	0	0	0	t	0	0	2009-10-07 00:04:41.747-04	2009-10-07 00:04:41.747-04	f	f	13	13	<p>Your 20% mapping yield looks like low for normal ChIP experiment, even for human. Several factors can reduce this mapping yield. I am wondering which kind of ChIP was used in your case. That is, which kind of proteins was ChIPed?</p>\n		\N	<p>Your 20% mapping yield looks like low for normal ChIP experiment, even for human. Several factors can reduce this mapping yield. I am wondering which kind of ChIP was used in your case. That is, which kind of proteins was ChIPed?</p>\n
13	Chip Dna Deep Sequence	12	12	0	1	0	2	72	3	0	0	t	28	4	2009-10-06 20:58:10.227-04	2009-10-06 20:58:10.227-04	f	f	13	13	<p>Hi, everyone,\nI am posting this question for my friend.\nHe is analyzing his CHIP DNA solid deep sequence data, and find out that near 80% reads can not be mapped to the human genome. We are wondering if this high percentage unmapped reads is normal in CHIP DNA deep sequence or there may be something wrong with his result.</p>\n	solid,deep,sequence	\N	<p>Hi, everyone,\nI am posting this question for my friend.\nHe is analyzing his CHIP DNA solid deep sequence data, and find out that near 80% reads can not be mapped to the human genome. We are wondering if this high percentage unmapped reads is normal in CHIP DNA deep sequence or there may be something wrong with his result.</p>\n
17	A: Site Use Guidelines	10	2	0	1	1	1	0	0	0	0	t	0	0	2009-10-07 18:41:44.823-04	2009-10-07 19:16:18.69-04	f	f	1	1	<p>If you are shy about asking the question on your own behalf submit it to to the <strong>Question Bot</strong> and it will be posted anonymously. Send email to the <code>Question Bot</code> link at the bottom.</p>\n		\N	<p>If you are shy about asking the question on your own behalf submit it to to the <strong>Question Bot</strong> and it will be posted anonymously. Send email to the <code>Question Bot</code> link at the bottom.</p>\n
18	A: Site Use Guidelines	14	14	0	1	1	1	0	0	0	0	t	0	0	2009-10-09 05:28:20.413-04	2009-10-09 05:28:20.413-04	f	f	1	1	<p>Hi,</p>\n\n<p>I don't think a new user can vote on a question or an answer.\nThe site says I need 15 reputation...</p>\n		\N	<p>Hi,</p>\n\n<p>I don't think a new user can vote on a question or an answer.\nThe site says I need 15 reputation...</p>\n
20	Do You Have To Be A Guy To Dress Up As Boy George	15	2	0	3	0	0	0	0	0	0	t	7	0	2009-10-18 05:22:53.98-04	2009-10-18 18:23:04.07-04	f	f	20	20	<p>any ideas im a girl</p>\n	boy,george	\N	<p>any ideas im a girl</p>\n
21	Do You Have To Be A Guy To Dress Up As Boy George	15	2	0	3	0	0	0	0	0	0	t	7	0	2009-10-18 05:23:34.373-04	2009-10-18 18:25:02.687-04	f	f	21	21	<p>any ideas im a girl</p>\n	boy,george	\N	<p>any ideas im a girl</p>\n
23	A: Gene Id Conversion Tool	2	2	0	1	1	0	0	0	0	0	t	0	0	2009-10-23 21:46:45.407-04	2009-10-23 21:46:45.407-04	f	f	22	22	<p>I don't know of a direct solution myself, but this is a topic that may be of interest for the biological data analysis class that I am teaching. </p>\n\n<p>If you specify the organism/genomic builds that you are interested in we may be able to generate a full translation list as an in class example or a homework. I was planning on covering an <code>Affymetrix ID</code> to <code>Genebank example</code> anyhow.</p>\n		\N	<p>I don't know of a direct solution myself, but this is a topic that may be of interest for the biological data analysis class that I am teaching. </p>\n\n<p>If you specify the organism/genomic builds that you are interested in we may be able to generate a full translation list as an in class example or a homework. I was planning on covering an <code>Affymetrix ID</code> to <code>Genebank example</code> anyhow.</p>\n
25	A: How To Set Shrimp Parameters For Best Sensitivity With 35Bp Colorspace Data?	18	18	0	1	1	2	0	0	0	0	t	0	0	2009-12-01 15:57:35.3-05	2009-12-01 15:57:35.3-05	f	f	24	24	<p>I just read the SHRiMP manual again, but I think that their explanation about -M option may not be enough to answer your question. I usually use the "seed" mode by using -s, -n, and -w and the option -M is a new feature of the version 1.3.1, which I have never tried before.</p>\n\n<p>I recommend for you to use the "seed" mode--the default would be good, but please adjust the -s option if you want more sensitivity. Always fast speed compensates sensitivity and the -M option seems to exist for this purpose.</p>\n\n<p>Hope my message to be helpful for your project.</p>\n		\N	<p>I just read the SHRiMP manual again, but I think that their explanation about -M option may not be enough to answer your question. I usually use the "seed" mode by using -s, -n, and -w and the option -M is a new feature of the version 1.3.1, which I have never tried before.</p>\n\n<p>I recommend for you to use the "seed" mode--the default would be good, but please adjust the -s option if you want more sensitivity. Always fast speed compensates sensitivity and the -M option seems to exist for this purpose.</p>\n\n<p>Hope my message to be helpful for your project.</p>\n
26	A: How To Set Shrimp Parameters For Best Sensitivity With 35Bp Colorspace Data?	2	2	0	1	1	1	0	0	0	0	t	0	0	2009-12-01 19:00:53.443-05	2009-12-01 19:00:53.443-05	f	f	24	24	<blockquote>\n  <p>Since my reads are only 20-25bp long,\n  should I changed the default 4 spaced\n  seeds to 3?</p>\n</blockquote>\n\n<p>while the shrimp manual says:</p>\n\n<ul>\n<li>We recommend using the default 4 seeds of weight 12 in most cases.</li>\n</ul>\n\n<p>you could try running on a smaller sample and see what happens. </p>\n		\N	<blockquote>\n  <p>Since my reads are only 20-25bp long,\n  should I changed the default 4 spaced\n  seeds to 3?</p>\n</blockquote>\n\n<p>while the shrimp manual says:</p>\n\n<ul>\n<li>We recommend using the default 4 seeds of weight 12 in most cases.</li>\n</ul>\n\n<p>you could try running on a smaller sample and see what happens. </p>\n
24	How To Set Shrimp Parameters For Best Sensitivity With 35Bp Colorspace Data?	14	14	0	1	0	1	32	2	0	0	t	21	4	2009-12-01 08:13:53.637-05	2009-12-01 08:13:53.637-05	f	f	24	24	<p>Hi,</p>\n\n<p>I have 35bp Solid colorspace sequencing data, and the actual sequences to be mapped are 20-25bp after removing the linker sequence.</p>\n\n<p>I hope to find all the hits allowing no more than n mismatches (say n=3), not only the best hit.</p>\n\n<p>I know there is a -M option to specify -M sensitivity,35bp. I wonder whether this setting will guarantee the best sensitivity in this case. Since my reads are only 20-25bp long, should I changed the default 4 spaced seeds to 3?</p>\n\n<p>I'm new to SHRiMP, so I'd like to hear some suggestions on setting the parameters of SHRiMP to achieve the best sensitivity.</p>\n\n<p>Thank you!</p>\n	shrimp,sequencing,short,aligner	\N	<p>Hi,</p>\n\n<p>I have 35bp Solid colorspace sequencing data, and the actual sequences to be mapped are 20-25bp after removing the linker sequence.</p>\n\n<p>I hope to find all the hits allowing no more than n mismatches (say n=3), not only the best hit.</p>\n\n<p>I know there is a -M option to specify -M sensitivity,35bp. I wonder whether this setting will guarantee the best sensitivity in this case. Since my reads are only 20-25bp long, should I changed the default 4 spaced seeds to 3?</p>\n\n<p>I'm new to SHRiMP, so I'd like to hear some suggestions on setting the parameters of SHRiMP to achieve the best sensitivity.</p>\n\n<p>Thank you!</p>\n
27	A: Gene Id Conversion Tool	19	19	0	1	1	2	0	0	0	0	t	0	0	2009-12-08 22:45:54.547-05	2009-12-08 22:45:54.547-05	f	f	22	22	<p>The following link has a list of ID conversion tools:</p>\n\n<p><a href='http://hum-molgen.org/NewsGen/08-2009/000020.html'>http://hum-molgen.org/NewsGen/08-2009/000020.html</a></p>\n		\N	<p>The following link has a list of ID conversion tools:</p>\n\n<p><a rel="nofollow" href="http://hum-molgen.org/NewsGen/08-2009/000020.html">http://hum-molgen.org/NewsGen/08-2009/000020.html</a></p>\n
29	A: Tips On Compiling And Using Meme 4.3 With A Sun Grid Engine Computation Cluster	2	2	0	1	1	0	0	0	0	0	t	0	0	2010-01-13 22:17:50.023-05	2010-01-13 22:17:50.023-05	f	f	28	28	<p>This may not be overly useful but it very much sounds like a configuration problem.</p>\n\n<p>Usually there is  configure flag that needs to be set to point to the libraries, something like:</p>\n\n<pre><code>--with-mpidir=MPIDIR\n--with-mpicc=MPICC\n</code></pre>\n\n<p>It also appears that the MEME suite does not support Open MPI (as per <a href='http://meme.sdsc.edu/meme4/meme-install.html'>install notes</a>).</p>\n\n<p>I would also recommend posting on the MEME user forum:</p>\n\n<p><a href='https://www.nbcr.net/forum/viewforum.php?f=5'>https://www.nbcr.net/forum/viewforum.php?f=5</a></p>\n		\N	<p>This may not be overly useful but it very much sounds like a configuration problem.</p>\n\n<p>Usually there is  configure flag that needs to be set to point to the libraries, something like:</p>\n\n<pre><code>--with-mpidir=MPIDIR\n--with-mpicc=MPICC\n</code></pre>\n\n<p>It also appears that the MEME suite does not support Open MPI (as per <a rel="nofollow" href="http://meme.sdsc.edu/meme4/meme-install.html">install notes</a>).</p>\n\n<p>I would also recommend posting on the MEME user forum:</p>\n\n<p><a rel="nofollow" href="https://www.nbcr.net/forum/viewforum.php?f=5">https://www.nbcr.net/forum/viewforum.php?f=5</a></p>\n
28	Tips On Compiling And Using Meme 4.3 With A Sun Grid Engine Computation Cluster	20	20	0	1	0	1	59	1	0	0	t	14	1	2010-01-13 13:59:22.603-05	2010-01-13 13:59:22.603-05	f	f	28	28	<p>Has anyone compiled and used MEME 4.x for use in a parallel computation environment, based upon operation with a Sun Grid Engine (SGE) cluster?</p>\n\n<p>I can compile the suite and its tests pass. However, when I attempt to use the <code>-p n</code> option, to specify <code>n</code> computation nodes, I get several error messages:</p>\n\n<pre><code>/gridware/codine/util/arch: Command not found.\n/gridware/codine/util/arch: Command not found.\n/gridware/codine/util/arch: Command not found.\n/gridware/codine/util/arch: Command not found.\n1: Command not found.\n</code></pre>\n\n<p>We do not have <code>/gridware/codine/util/arch</code>, but we do have <code>/gridengine/sgi/util/arch</code>.</p>\n\n<p>I tried looking around MEME's source code, particularly at <code>meme.c</code> and <code>mp.h</code>, but there are no references to these paths.</p>\n\n<p>I'm wondering if I am missing makefile directives. Here is my <code>./configure</code> statement:</p>\n\n<pre><code>./configure --prefix=/home/areynolds/proj/meme/meme_4.3.0_build --with-url="http://meme.nbcr.net/meme" --enable-openmp --enable-debug\n</code></pre>\n\n<p>Is MPI a requirement; are there directives I am missing for MPI?</p>\n\n<p>Thank you for any advice.</p>\n	meme,sge,motif,motif,compilation	\N	<p>Has anyone compiled and used MEME 4.x for use in a parallel computation environment, based upon operation with a Sun Grid Engine (SGE) cluster?</p>\n\n<p>I can compile the suite and its tests pass. However, when I attempt to use the <code>-p n</code> option, to specify <code>n</code> computation nodes, I get several error messages:</p>\n\n<pre><code>/gridware/codine/util/arch: Command not found.\n/gridware/codine/util/arch: Command not found.\n/gridware/codine/util/arch: Command not found.\n/gridware/codine/util/arch: Command not found.\n1: Command not found.\n</code></pre>\n\n<p>We do not have <code>/gridware/codine/util/arch</code>, but we do have <code>/gridengine/sgi/util/arch</code>.</p>\n\n<p>I tried looking around MEME's source code, particularly at <code>meme.c</code> and <code>mp.h</code>, but there are no references to these paths.</p>\n\n<p>I'm wondering if I am missing makefile directives. Here is my <code>./configure</code> statement:</p>\n\n<pre><code>./configure --prefix=/home/areynolds/proj/meme/meme_4.3.0_build --with-url="<a rel="nofollow" href="http://meme.nbcr.net/meme">http://meme.nbcr.net/meme</a>" --enable-openmp --enable-debug\n</code></pre>\n\n<p>Is MPI a requirement; are there directives I am missing for MPI?</p>\n\n<p>Thank you for any advice.</p>\n
30	A: How Do I Convert From Bed Format To Gff Format?	20	20	0	1	1	2	0	0	0	0	t	0	0	2010-01-15 09:48:14.66-05	2010-01-15 09:48:14.66-05	f	f	2	2	<p>Here's a Perl script I wrote if you wanted to do something local. </p>\n\n<p>There's some code in there for translating yeast chromosome names that can be removed, if not needed. I also used a <code>Site</code> feature in the GFF file as the region ID, which might also need tweaking, depending on what features you're interested in.</p>\n\n<pre><code>#!/usr/bin/perl -w\n\nuse strict;\nuse Bio::Tools::GFF;\nuse feature qw(say switch);\n\nmy $gffio = Bio::Tools::GFF-&gt;new(-fh =&gt; \\*STDIN, -gff_version =&gt; 2);\nmy $feature;\n\nwhile ($feature = $gffio-&gt;next_feature()) {\n    # print $gffio-&gt;gff_string($feature)."\\n";\n\n    # cf. http://www.sanger.ac.uk/Software/formats/GFF/GFF_Spec.shtml\n    my $seq_id = $feature-&gt;seq_id();   \n    my $start = $feature-&gt;start() - 1;\n    my $end = $feature-&gt;end();\n    my $strand = $feature-&gt;strand();\n    my @sites = $feature-&gt;get_tag_values('Site');\n\n    # translate strand\n    given ( $strand ) {\n        when ($_ == 1)  { $strand = "+"; }\n        when ($_ == -1) { $strand = "-"; }\n    }\n\n    # translate yeast chromosome to UCSC browser-readable chromosome\n    # cf. http://www.yeastgenome.org/sgdpub/Saccharomyces_cerevisiae.pdf\n    given ( $seq_id ) {\n        when ( $_ eq "I" )    { $seq_id = "chr1"; }\n        when ( $_ eq "II" )   { $seq_id = "chr2"; }\n        when ( $_ eq "III" )  { $seq_id = "chr3"; }\n        when ( $_ eq "IV" )   { $seq_id = "chr4"; }\n        when ( $_ eq "V" )    { $seq_id = "chr5"; }\n        when ( $_ eq "VI" )   { $seq_id = "chr6"; }\n        when ( $_ eq "VII" )  { $seq_id = "chr7"; }\n        when ( $_ eq "VIII" ) { $seq_id = "chr8"; }\n        when ( $_ eq "IX" )   { $seq_id = "chr9"; }\n        when ( $_ eq "X" )    { $seq_id = "chr10"; }\n        when ( $_ eq "XI" )   { $seq_id = "chr11"; }\n        when ( $_ eq "XII" )  { $seq_id = "chr12"; }\n        when ( $_ eq "XIII" ) { $seq_id = "chr13"; }\n        when ( $_ eq "XIV" )  { $seq_id = "chr14"; }\n        when ( $_ eq "XV" )   { $seq_id = "chr15"; }\n        when ( $_ eq "XVI" )  { $seq_id = "chr16"; }\n        default { }\n    }\n\n    # output\n    print "$seq_id\\t$start\\t$end\\t$sites[0]\\t0.0\\t$strand\\n";\n}\n$gffio-&gt;close();\n</code></pre>\n\n<p>To use it:</p>\n\n<pre><code>gff2bed.pl &lt; data.gff &gt; data.bed\n</code></pre>\n		\N	<p>Here's a Perl script I wrote if you wanted to do something local. </p>\n\n<p>There's some code in there for translating yeast chromosome names that can be removed, if not needed. I also used a <code>Site</code> feature in the GFF file as the region ID, which might also need tweaking, depending on what features you're interested in.</p>\n\n<pre><code>#!/usr/bin/perl -w\n\nuse strict;\nuse Bio::Tools::GFF;\nuse feature qw(say switch);\n\nmy $gffio = Bio::Tools::GFF-&gt;new(-fh =&gt; \\*STDIN, -gff_version =&gt; 2);\nmy $feature;\n\nwhile ($feature = $gffio-&gt;next_feature()) {\n    # print $gffio-&gt;gff_string($feature)."\\n";\n\n    # cf. <a rel="nofollow" href="http://www.sanger.ac.uk/Software/formats/GFF/GFF_Spec.shtml">http://www.sanger.ac.uk/Software/formats/GFF/GFF_Spec.shtml</a>\n    my $seq_id = $feature-&gt;seq_id();   \n    my $start = $feature-&gt;start() - 1;\n    my $end = $feature-&gt;end();\n    my $strand = $feature-&gt;strand();\n    my @sites = $feature-&gt;get_tag_values('Site');\n\n    # translate strand\n    given ( $strand ) {\n        when ($_ == 1)  { $strand = "+"; }\n        when ($_ == -1) { $strand = "-"; }\n    }\n\n    # translate yeast chromosome to UCSC browser-readable chromosome\n    # cf. <a rel="nofollow" href="http://www.yeastgenome.org/sgdpub/Saccharomyces_cerevisiae.pdf">http://www.yeastgenome.org/sgdpub/Saccharomyces_cerevisiae.pdf</a>\n    given ( $seq_id ) {\n        when ( $_ eq "I" )    { $seq_id = "chr1"; }\n        when ( $_ eq "II" )   { $seq_id = "chr2"; }\n        when ( $_ eq "III" )  { $seq_id = "chr3"; }\n        when ( $_ eq "IV" )   { $seq_id = "chr4"; }\n        when ( $_ eq "V" )    { $seq_id = "chr5"; }\n        when ( $_ eq "VI" )   { $seq_id = "chr6"; }\n        when ( $_ eq "VII" )  { $seq_id = "chr7"; }\n        when ( $_ eq "VIII" ) { $seq_id = "chr8"; }\n        when ( $_ eq "IX" )   { $seq_id = "chr9"; }\n        when ( $_ eq "X" )    { $seq_id = "chr10"; }\n        when ( $_ eq "XI" )   { $seq_id = "chr11"; }\n        when ( $_ eq "XII" )  { $seq_id = "chr12"; }\n        when ( $_ eq "XIII" ) { $seq_id = "chr13"; }\n        when ( $_ eq "XIV" )  { $seq_id = "chr14"; }\n        when ( $_ eq "XV" )   { $seq_id = "chr15"; }\n        when ( $_ eq "XVI" )  { $seq_id = "chr16"; }\n        default { }\n    }\n\n    # output\n    print "$seq_id\\t$start\\t$end\\t$sites[0]\\t0.0\\t$strand\\n";\n}\n$gffio-&gt;close();\n</code></pre>\n\n<p>To use it:</p>\n\n<pre><code>gff2bed.pl &lt; data.gff &gt; data.bed\n</code></pre>\n
2	How Do I Convert From Bed Format To Gff Format?	2	2	0	1	0	0	187	2	0	1	t	14	3	2009-09-30 16:55:00.133-04	2009-09-30 17:09:43.357-04	f	f	2	2	<p>I have a file in GFF format and I need to convert it to BED format. What do I do?</p>\n	bed,gff,galaxy	\N	<p>I have a file in GFF format and I need to convert it to BED format. What do I do?</p>\n
32	A: How Do I Map, Align, And Plot My Solid Results?	2	2	0	1	1	1	0	0	0	0	t	0	0	2010-01-22 16:13:42.79-05	2010-01-22 16:13:42.79-05	f	f	31	31	<p>Personally I would advise that if you know someone who can partially perform the task you should have them do it, and ask them to explain and show it to you how they've done it.</p>\n\n<p>The task at hand is complex. The solution always depends immensely on the particulars of the problem, moreover you will be facing myriads of frustrating limitations, errors and problems.</p>\n\n<p>Learning directly from someone who has done it, establishing a personal rapport with them will allow you to ease into this problem domain. In fact when you are finished mapping your RNA - your are still likely to be far from being done - yet you might have expanded a lot of energy and excitement. </p>\n		\N	<p>Personally I would advise that if you know someone who can partially perform the task you should have them do it, and ask them to explain and show it to you how they've done it.</p>\n\n<p>The task at hand is complex. The solution always depends immensely on the particulars of the problem, moreover you will be facing myriads of frustrating limitations, errors and problems.</p>\n\n<p>Learning directly from someone who has done it, establishing a personal rapport with them will allow you to ease into this problem domain. In fact when you are finished mapping your RNA - your are still likely to be far from being done - yet you might have expanded a lot of energy and excitement. </p>\n
35	A: Which Operating System Do You Prefer For Bioinformatics?	2	2	0	1	1	1	0	0	0	0	t	0	0	2010-01-26 21:23:45.583-05	2010-01-26 21:23:45.583-05	f	f	33	33	<p>Often people are limited to their choices by factors outside of their control. One lab that I work with requires the use of Mac computers another is using Windows mostly. Large scale computations seem to be best suited for Linux systems.</p>\n\n<p>Luckily there is a migration towards unified capabilities across all platforms. Installing Cygwin on Windows allows us to tap into the power of Unix, while Linux distros have advanced graphical user interfaces like Windows and Macs.</p>\n\n<p>From my own observations of non technical people, the installation of new and interdependent software packages seems to be the most difficult on Mac computers and easiest on Windows due to the computational architecture that makes all Windows computers identical. </p>\n		\N	<p>Often people are limited to their choices by factors outside of their control. One lab that I work with requires the use of Mac computers another is using Windows mostly. Large scale computations seem to be best suited for Linux systems.</p>\n\n<p>Luckily there is a migration towards unified capabilities across all platforms. Installing Cygwin on Windows allows us to tap into the power of Unix, while Linux distros have advanced graphical user interfaces like Windows and Macs.</p>\n\n<p>From my own observations of non technical people, the installation of new and interdependent software packages seems to be the most difficult on Mac computers and easiest on Windows due to the computational architecture that makes all Windows computers identical. </p>\n
36	A: Which Are The Best Programming Languages To Study For A Bioinformatician?	2	2	0	1	1	1	0	0	0	0	t	0	0	2010-01-26 21:32:29.45-05	2010-01-26 21:32:29.45-05	f	f	34	34	<p>It is important to be considerate and not characterize one particular approach negatively. My favorite quote is:</p>\n\n<p><strong>Programming is pure thought.</strong></p>\n\n<p>Hopefully everyone is able to pick an approach that matches their individual way of thinking. While I myself do not program in Perl, I consider it to be one of the most popular and powerful platforms for doing bioinformatics analysis. </p>\n		\N	<p>It is important to be considerate and not characterize one particular approach negatively. My favorite quote is:</p>\n\n<p><strong>Programming is pure thought.</strong></p>\n\n<p>Hopefully everyone is able to pick an approach that matches their individual way of thinking. While I myself do not program in Perl, I consider it to be one of the most popular and powerful platforms for doing bioinformatics analysis. </p>\n
37	A: Which Operating System Do You Prefer For Bioinformatics?	2	2	0	1	1	1	0	0	0	0	t	0	0	2010-01-26 21:38:24.477-05	2010-01-26 21:38:24.477-05	f	f	33	33	<p>Tips for installing software om Max OS X:</p>\n\n<ul>\n<li>install the Apple developer tools called <strong>Xcode</strong> <a href='http://developer.apple.com/tools/xcode/'>http://developer.apple.com/tools/xcode/</a></li>\n<li>install <strong>MacPorts</strong> from <a href='http://www.macports.org/'>http://www.macports.org/</a></li>\n</ul>\n\n<p>You can now easily install everything from command line using the <code>port</code> command. List all available software</p>\n\n<pre><code>port list\n</code></pre>\n\n<p>Install libraries and software. etc:</p>\n\n<pre><code>port install &lt;some-library&gt;\n</code></pre>\n		\N	<p>Tips for installing software om Max OS X:</p>\n\n<ul>\n<li>install the Apple developer tools called <strong>Xcode</strong> <a rel="nofollow" href="http://developer.apple.com/tools/xcode/">http://developer.apple.com/tools/xcode/</a></li>\n<li>install <strong>MacPorts</strong> from <a rel="nofollow" href="http://www.macports.org/">http://www.macports.org/</a></li>\n</ul>\n\n<p>You can now easily install everything from command line using the <code>port</code> command. List all available software</p>\n\n<pre><code>port list\n</code></pre>\n\n<p>Install libraries and software. etc:</p>\n\n<pre><code>port install &lt;some-library&gt;\n</code></pre>\n
38	A: Which Are The Best Programming Languages To Study For A Bioinformatician?	25	25	0	1	1	1	0	0	0	0	t	0	0	2010-01-27 00:42:14.167-05	2010-01-27 00:42:14.167-05	f	f	34	34	<p>Any programming language is good as long you know what you're doing.</p>\n		\N	<p>Any programming language is good as long you know what you're doing.</p>\n
39	A: Gene Id Conversion Tool	23	23	0	1	1	2	0	0	0	0	t	0	0	2010-01-27 11:08:52.87-05	2010-01-27 11:08:52.87-05	f	f	22	22	<p>You can also do it with the following services:</p>\n\n<ul>\n<li><a href='http://www.uniprot.org/?tab=mapping'>uniprot</a> - Click on 'Id Mapping' from the home page.</li>\n<li><a href='http://www.biomart.org/biomart/martview/'>biomart</a> - choose a database and a version, then put the ids you want to convert under Filters->Id List limit (select the proper input id in the menu), and then the output ids under 'Attributes'. Biomart is a general tool that enables you to extract a lot of different informations from databases - sequences, ontologies, transcripts, homologues - but maybe for converting gene ids is a bit too complex.</li>\n<li><a href='http://main.g2.bx.psu.edu/'>galaxy</a> - I can't help too much about this here but I am sure it has a function for doing that - and many other things.</li>\n</ul>\n		\N	<p>You can also do it with the following services:</p>\n\n<ul>\n<li><a rel="nofollow" href="http://www.uniprot.org/?tab=mapping">uniprot</a> - Click on 'Id Mapping' from the home page.</li>\n<li><a rel="nofollow" href="http://www.biomart.org/biomart/martview/">biomart</a> - choose a database and a version, then put the ids you want to convert under Filters-&gt;Id List limit (select the proper input id in the menu), and then the output ids under 'Attributes'. Biomart is a general tool that enables you to extract a lot of different informations from databases - sequences, ontologies, transcripts, homologues - but maybe for converting gene ids is a bit too complex.</li>\n<li><a rel="nofollow" href="http://main.g2.bx.psu.edu/">galaxy</a> - I can't help too much about this here but I am sure it has a function for doing that - and many other things.</li>\n</ul>\n
40	A: Finding Common Motifs In Sequences	23	23	0	1	1	1	0	0	0	0	t	0	0	2010-01-28 16:31:50.47-05	2010-01-28 16:31:50.47-05	f	f	4	4	<p>Meme has been the first program to be published for doing that.\nAs an alternative you can find one of the <a href='http://www.be.embnet.org/embosshelp/'>EMBOSS tools</a>; if you are scared by a terminal and want to do it from a web-based interface, you can use the EMBOSS tools from <a href='http://main.g2.bx.psu.edu/'>galaxy</a></p>\n		\N	<p>Meme has been the first program to be published for doing that.\nAs an alternative you can find one of the <a rel="nofollow" href="http://www.be.embnet.org/embosshelp/">EMBOSS tools</a>; if you are scared by a terminal and want to do it from a web-based interface, you can use the EMBOSS tools from <a rel="nofollow" href="http://main.g2.bx.psu.edu/">galaxy</a></p>\n
42	A: Site Use Guidelines	23	23	0	1	1	0	0	0	0	0	t	0	0	2010-01-28 17:22:04.203-05	2010-01-28 17:22:04.203-05	f	f	1	1	<p>The StackExchange websites have been designed for making questions related to programming and technical issues.</p>\n\n<p>For example, for this reason, if you try to write a question which starts with 'What is your favorite experience...' you get a disclaimer saying that 'your question seems to be probably subjective and it is likely to be closed'.</p>\n\n<p>However, I think that it is very useful to make subjective and opinion-based questions on bioinformatics, as there are few places to do so... So, what is your policy? Will you accept subjective questions?</p>\n		\N	<p>The StackExchange websites have been designed for making questions related to programming and technical issues.</p>\n\n<p>For example, for this reason, if you try to write a question which starts with 'What is your favorite experience...' you get a disclaimer saying that 'your question seems to be probably subjective and it is likely to be closed'.</p>\n\n<p>However, I think that it is very useful to make subjective and opinion-based questions on bioinformatics, as there are few places to do so... So, what is your policy? Will you accept subjective questions?</p>\n
43	A: Which Are The Best Programming Languages To Study For A Bioinformatician?	23	23	0	1	1	7	0	0	0	0	t	0	0	2010-01-28 18:58:20.5-05	2010-01-28 18:58:20.5-05	f	f	34	34	<p>The choice of a programming language is purely subjective, but when a student asks you which programming language he should start with, you have to make an answer, or at least provide some informations.</p>\n\n<p>I think that a bioinformatician who studies <strong>R</strong> and at least two or three libraries (lattice/ggplot2, plyr) early can have an advantage, because he will be able to represent his data properly and obtain good results without too much effort. If your supervisor is not a computer scientist, he will be a lot more impressed by plots and charts than by programs, even if they are well written, with unittests etc.</p>\n\n<p><strong>Python</strong> is a good programming language to learn as a general purpose tool. Its bigger advantages are its easy to read syntax, and its paradigm 'there is only one way to do it', so the number of language keywords is reduced to the minimum, and two programs with the same function written by different people will be very similar (which is what doesn't happen with perl). \nThe negative points of python are that its CSV files reading/plotting interface is not ready yet (the best is pylab), so you must rely on R to produce nice plots.</p>\n\n<p>Honestly I don't like <strong>perl</strong>, because I think it can induce to many bad-behaviours in novel programmers. For example, in perl there are many similar constructs to accomplish the same objective: so, it is very difficult to understand a program written by someone else, because you have to known all the possible constructs and hope there are enough comments. It is already very difficult to reproduce a bioinformatician experiment, if you write your code in a difficult language it is a lot worst. \nMoreover, I know of many people who have been using perl for years, but that don't even use functions, because it looks too complicated. How can it be? It looks very inefficient. \nThe only good point of perl is its repositories, bioperl and CPAN; however, I know of people using perl that don't even know of the existence of these, so I don't understand why they keep going with perl.</p>\n\n<p>Apart from programming language, is it very useful to learn the basic usage of <strong>gnu-make</strong>, or of a derivate. This program is very useful when you have lot of different scripts, as it allows you to define a pipeline in order to run them. \nSome basic <strong>bash commands</strong> may also be very useful if you work with a lot of flat files (head, sed, gawk, grep, ...)</p>\n		\N	<p>The choice of a programming language is purely subjective, but when a student asks you which programming language he should start with, you have to make an answer, or at least provide some informations.</p>\n\n<p>I think that a bioinformatician who studies <strong>R</strong> and at least two or three libraries (lattice/ggplot2, plyr) early can have an advantage, because he will be able to represent his data properly and obtain good results without too much effort. If your supervisor is not a computer scientist, he will be a lot more impressed by plots and charts than by programs, even if they are well written, with unittests etc.</p>\n\n<p><strong>Python</strong> is a good programming language to learn as a general purpose tool. Its bigger advantages are its easy to read syntax, and its paradigm 'there is only one way to do it', so the number of language keywords is reduced to the minimum, and two programs with the same function written by different people will be very similar (which is what doesn't happen with perl). \nThe negative points of python are that its CSV files reading/plotting interface is not ready yet (the best is pylab), so you must rely on R to produce nice plots.</p>\n\n<p>Honestly I don't like <strong>perl</strong>, because I think it can induce to many bad-behaviours in novel programmers. For example, in perl there are many similar constructs to accomplish the same objective: so, it is very difficult to understand a program written by someone else, because you have to known all the possible constructs and hope there are enough comments. It is already very difficult to reproduce a bioinformatician experiment, if you write your code in a difficult language it is a lot worst. \nMoreover, I know of many people who have been using perl for years, but that don't even use functions, because it looks too complicated. How can it be? It looks very inefficient. \nThe only good point of perl is its repositories, bioperl and CPAN; however, I know of people using perl that don't even know of the existence of these, so I don't understand why they keep going with perl.</p>\n\n<p>Apart from programming language, is it very useful to learn the basic usage of <strong>gnu-make</strong>, or of a derivate. This program is very useful when you have lot of different scripts, as it allows you to define a pipeline in order to run them. \nSome basic <strong>bash commands</strong> may also be very useful if you work with a lot of flat files (head, sed, gawk, grep, ...)</p>\n
44	A: How Much Do You Trust Geneontology?	2	2	0	1	1	1	0	0	0	0	t	0	0	2010-01-28 23:41:29.17-05	2010-01-28 23:41:29.17-05	f	f	41	41	<p>The GO terms and classifications are primarily an based on opinions and a human interpretation of a small group of people of what the current state of the knowledge is.Thus  are more subjective than say experimental measurements would be. </p>\n\n<p>In fact it is surprising that it works at all; and it does indeed.  We just need to becareful not too read to much into it.</p>\n		\N	<p>The GO terms and classifications are primarily an based on opinions and a human interpretation of a small group of people of what the current state of the knowledge is.Thus  are more subjective than say experimental measurements would be. </p>\n\n<p>In fact it is surprising that it works at all; and it does indeed.  We just need to becareful not too read to much into it.</p>\n
49	A: Where Can I Get The Secondary Structure Of A Protein?	2	2	0	1	1	1	0	0	0	0	t	0	0	2010-02-12 21:01:49.187-05	2010-02-12 21:01:49.187-05	f	f	48	48	<p>Protein structure prediction is a complex issue that is likely to require multiple approaches. There are many methods/tools listed at the </p>\n\n<ul>\n<li><a href='http://www.expasy.ch/'>Expert Protein Analysis System website</a></li>\n</ul>\n		\N	<p>Protein structure prediction is a complex issue that is likely to require multiple approaches. There are many methods/tools listed at the </p>\n\n<ul>\n<li><a rel="nofollow" href="http://www.expasy.ch/">Expert Protein Analysis System website</a></li>\n</ul>\n
45	A: How Much Do You Trust Geneontology?	4	4	0	1	1	2	0	0	0	0	t	0	0	2010-01-29 06:50:26.02-05	2010-01-29 06:50:26.02-05	f	f	41	41	<p>In my experience it's case by case. In other words just because you are getting significant p-values, does not mean the results are biologically significant. I once submitted clusters of microarray data and received a bunch of hits that were significant by p-value, but really didn't have a theme. The GO terms I saw were from many different processes without an overall term (besides biological process) which linked them together. When I've looked at published GO terms searches I generally see a strong theme among many of the terms (however that doesn't necessarily mean it has biological significance until tested empirically). So seeing themes among your terms may suggest higher significance, but it should make biological sense too. </p>\n		\N	<p>In my experience it's case by case. In other words just because you are getting significant p-values, does not mean the results are biologically significant. I once submitted clusters of microarray data and received a bunch of hits that were significant by p-value, but really didn't have a theme. The GO terms I saw were from many different processes without an overall term (besides biological process) which linked them together. When I've looked at published GO terms searches I generally see a strong theme among many of the terms (however that doesn't necessarily mean it has biological significance until tested empirically). So seeing themes among your terms may suggest higher significance, but it should make biological sense too. </p>\n
41	How Much Do You Trust Geneontology?	23	2	0	1	0	3	119	2	0	0	t	21	6	2010-01-28 17:17:37.437-05	2010-01-29 15:08:07.753-05	f	f	41	41	<p><a href='http://www.geneontology.org/'>GeneOntology</a> is a nice project to provide a standard terminology for genes and gene functions, to help avoid the use of synonyms and wrong spelling when describing a gene.</p>\n\n<p>I have been using the GeneOntology for a while, but honestly I think that it contains many errors and that many terms have not enough terms associated. Moreover, the terminology they use is not always clear and there are some duplications.</p>\n\n<p>It is frequent to read in article or in slideshows charts were the GO classification is used to infer the properties of a set of genes... But I wonder if the authors check the GO annotations that they use.</p>\n\n<p>What is your experience about <a href='http://www.geneontology.org/'>GO</a>?</p>\n	subjective,gene,go	\N	<p><a rel="nofollow" href="http://www.geneontology.org/">GeneOntology</a> is a nice project to provide a standard terminology for genes and gene functions, to help avoid the use of synonyms and wrong spelling when describing a gene.</p>\n\n<p>I have been using the GeneOntology for a while, but honestly I think that it contains many errors and that many terms have not enough terms associated. Moreover, the terminology they use is not always clear and there are some duplications.</p>\n\n<p>It is frequent to read in article or in slideshows charts were the GO classification is used to infer the properties of a set of genes... But I wonder if the authors check the GO annotations that they use.</p>\n\n<p>What is your experience about <a rel="nofollow" href="http://www.geneontology.org/">GO</a>?</p>\n
47	A: What Is Your Experience With The String (Interactions) Database?	2	2	0	1	1	1	0	0	0	0	t	0	0	2010-01-29 15:06:06.18-05	2010-01-29 15:06:06.18-05	f	f	46	46	<p>I have not used STRING in particular but I have worked with protein interactions before (DIP dataset). I recall that even experimentally produced protein-protein interactions may have very large false positive ratios  (as for false negatives, who knows?) Some papers claim that up to 50% of the interactions were spurious; and repeated experiments showed very small overlaps. Predictions may be even less reliable.</p>\n\n<p>At the same time the DIP dataset performed substantially better if we only considered the interactions for which there were multiple sources of evidence, so that may be a strategy to consider in your case as well.</p>\n		\N	<p>I have not used STRING in particular but I have worked with protein interactions before (DIP dataset). I recall that even experimentally produced protein-protein interactions may have very large false positive ratios  (as for false negatives, who knows?) Some papers claim that up to 50% of the interactions were spurious; and repeated experiments showed very small overlaps. Predictions may be even less reliable.</p>\n\n<p>At the same time the DIP dataset performed substantially better if we only considered the interactions for which there were multiple sources of evidence, so that may be a strategy to consider in your case as well.</p>\n
50	A: Where Can I Get The Secondary Structure Of A Protein?	26	26	0	1	1	3	0	0	0	0	t	0	0	2010-02-12 22:57:06.68-05	2010-02-12 22:57:06.68-05	f	f	48	48	<p>I think you found the best answer yourself: use a predictor! There are several out there...</p>\n\n<p>You suggest that there should be a Secondary Structure Database. I'm not sure that makes much sense, let me explain my point of view (which may not be that of everyone): most often, the data that is found in databases is the "state of knowledge" of the described object, based on experimentation.</p>\n\n<p>That may be the case for secondary structures of proteins, but only in the case where the said proteins have been crystalized. In those cases, it is not only the secondary structures but also the tertiary structures (with the caveat that the crystal structure of a protein does not prove "all" states that a protein may take in real "dynamic" physiological conditions).</p>\n\n<p>For all those proteins that have not been crystalized, then we can only rely on predictions. And I use them quite frequently: they are extremely useful! But as far as I know, no prediction is accepted as fact. They're "educated guesses" that are often correct, but sometimes wrong. The results may differ from one prediction method to another. Also they change each time the algorithms are improved...</p>\n\n<p>If there was a database of predicted secondary structures, people would likely take them for granted (make the equation prediction = fact) which would be quite "unscientific".</p>\n\n<p>I think such a resource would be more of a hindrance than an asset to the scientific community...</p>\n		\N	<p>I think you found the best answer yourself: use a predictor! There are several out there...</p>\n\n<p>You suggest that there should be a Secondary Structure Database. I'm not sure that makes much sense, let me explain my point of view (which may not be that of everyone): most often, the data that is found in databases is the "state of knowledge" of the described object, based on experimentation.</p>\n\n<p>That may be the case for secondary structures of proteins, but only in the case where the said proteins have been crystalized. In those cases, it is not only the secondary structures but also the tertiary structures (with the caveat that the crystal structure of a protein does not prove "all" states that a protein may take in real "dynamic" physiological conditions).</p>\n\n<p>For all those proteins that have not been crystalized, then we can only rely on predictions. And I use them quite frequently: they are extremely useful! But as far as I know, no prediction is accepted as fact. They're "educated guesses" that are often correct, but sometimes wrong. The results may differ from one prediction method to another. Also they change each time the algorithms are improved...</p>\n\n<p>If there was a database of predicted secondary structures, people would likely take them for granted (make the equation prediction = fact) which would be quite "unscientific".</p>\n\n<p>I think such a resource would be more of a hindrance than an asset to the scientific community...</p>\n
52	A: Turn Off Blast Search On Reverse Complement Strand In Blastn	2	2	0	1	1	1	0	0	0	0	t	0	0	2010-02-16 03:31:37.06-05	2010-02-16 03:31:37.06-05	f	f	51	51	<p>The -S flag can select the strands:</p>\n\n<pre><code>-S  Query strands to search against database \n    (for blast[nx], and tblastx) 3 is both, 1 is top, 2 is bottom [Integer]\n</code></pre>\n		\N	<p>The -S flag can select the strands:</p>\n\n<pre><code>-S  Query strands to search against database \n    (for blast[nx], and tblastx) 3 is both, 1 is top, 2 is bottom [Integer]\n</code></pre>\n
51	Turn Off Blast Search On Reverse Complement Strand In Blastn	14	2	0	1	0	1	55	1	0	0	t	14	2	2010-02-16 02:13:06.543-05	2010-02-16 20:20:31.193-05	f	f	51	51	<p>I have a quick question:\nHow can I turn off search on reverse complement strand of my query nucleotide sequence in blastn?</p>\n\n<p>For example, I don't want 'GUAAAGCCAAAUCUUCGGUUA' to be a hit when I use 'UAACCGAAGAUUUGGCUUUAC' as the query.</p>\n\n<p>Maybe I missed it when I read the man page, but I really appreciate it if someone can point out the parameter I should use.</p>\n\n<p>Thanks!</p>\n	sequence,blast	\N	<p>I have a quick question:\nHow can I turn off search on reverse complement strand of my query nucleotide sequence in blastn?</p>\n\n<p>For example, I don't want 'GUAAAGCCAAAUCUUCGGUUA' to be a hit when I use 'UAACCGAAGAUUUGGCUUUAC' as the query.</p>\n\n<p>Maybe I missed it when I read the man page, but I really appreciate it if someone can point out the parameter I should use.</p>\n\n<p>Thanks!</p>\n
54	A: How Do I Map, Align, And Plot My Solid Results?	27	27	0	1	1	1	0	0	0	0	t	0	0	2010-02-19 08:31:24.643-05	2010-02-19 08:31:24.643-05	f	f	31	31	<p>You can try <a href='http://bio-bwa.sourceforge.net/'>BWA</a> as well:\n<a href='http://maq.sourceforge.net/bwa-man.shtml'>http://maq.sourceforge.net/bwa-man.shtml</a></p>\n		\N	<p>You can try <a rel="nofollow" href="http://bio-bwa.sourceforge.net/">BWA</a> as well:\n<a rel="nofollow" href="http://maq.sourceforge.net/bwa-man.shtml">http://maq.sourceforge.net/bwa-man.shtml</a></p>\n
31	How Do I Map, Align, And Plot My Solid Results?	4	4	0	1	0	2	79	2	0	0	t	17	4	2010-01-22 04:14:17.38-05	2010-01-22 04:14:17.38-05	f	f	31	31	<p>Hi, I recently performed an RNA immunoprecipitation followed by SOLiD sequencing (50 bp fragmented reads). I haven't received my first SOLiD sequencing results yet, but I was told I should have them soon. I've tried doing my own research on how to map, align, and plot my results but I don't have a concrete workflow as to how I will analyze my results yet. I have very little experience doing any programming and would prefer to use galaxy. There are labs on my campus I can go to to get my color space data mapped, but I would like to do things myself. Is there a way on galaxy (or another program) to convert my color space data to sequence, then map those reads to the yeast transcriptome and analyze it? Even if you can't answer my question directly I'd appreciate any tips from anyone who has worked with RNA-seq data already.    </p>\n\n<p>Thanks in advance </p>\n	solid,rna,galaxy	\N	<p>Hi, I recently performed an RNA immunoprecipitation followed by SOLiD sequencing (50 bp fragmented reads). I haven't received my first SOLiD sequencing results yet, but I was told I should have them soon. I've tried doing my own research on how to map, align, and plot my results but I don't have a concrete workflow as to how I will analyze my results yet. I have very little experience doing any programming and would prefer to use galaxy. There are labs on my campus I can go to to get my color space data mapped, but I would like to do things myself. Is there a way on galaxy (or another program) to convert my color space data to sequence, then map those reads to the yeast transcriptome and analyze it? Even if you can't answer my question directly I'd appreciate any tips from anyone who has worked with RNA-seq data already.    </p>\n\n<p>Thanks in advance </p>\n
55	A: How To Do Quality Trimming Of Solid Reads In Colour Space?	28	28	0	1	1	1	0	0	0	0	t	0	0	2010-02-19 14:33:45.533-05	2010-02-19 14:33:45.533-05	f	f	53	53	<p>The <a href='http://solidsoftwaretools.com/gf/project/saet/'>Solid Accuracy Enhancer Tool</a> might be useful for this.</p>\n		\N	<p>The <a rel="nofollow" href="http://solidsoftwaretools.com/gf/project/saet/">Solid Accuracy Enhancer Tool</a> might be useful for this.</p>\n
53	How To Do Quality Trimming Of Solid Reads In Colour Space?	27	27	0	1	0	1	53	1	0	0	t	14	2	2010-02-19 08:29:18.733-05	2010-02-19 08:29:18.733-05	f	f	53	53	<p>The reads returned from the Solid sequencing provider are littered with dots and some bases have a negative quality value. Does anyone know if there is a good method to extract high quality regions from the reads without distorting the reading of bases in colour space?</p>\n	solid	\N	<p>The reads returned from the Solid sequencing provider are littered with dots and some bases have a negative quality value. Does anyone know if there is a good method to extract high quality regions from the reads without distorting the reading of bases in colour space?</p>\n
57	A: How To Get The Sequence Of A Genomic Region From Ucsc?	2	2	0	1	1	2	0	0	0	0	t	0	0	2010-02-21 20:11:20.45-05	2010-02-21 20:11:20.45-05	f	f	56	56	<p>The Genome Browser is for visualization.</p>\n\n<p>To get data in many formats use the <a href='http://genome.ucsc.edu/cgi-bin/hgTables?org=human'>UCSC Table Browser</a> then select the output format of your choice.</p>\n\n<p>You may also need to select the right <strong>group</strong> and <strong>track</strong> to get the data you want.</p>\n		\N	<p>The Genome Browser is for visualization.</p>\n\n<p>To get data in many formats use the <a rel="nofollow" href="http://genome.ucsc.edu/cgi-bin/hgTables?org=human">UCSC Table Browser</a> then select the output format of your choice.</p>\n\n<p>You may also need to select the right <strong>group</strong> and <strong>track</strong> to get the data you want.</p>\n
59	A: How To Get The Sequence Of A Genomic Region From Ucsc?	30	30	0	1	1	3	0	0	0	0	t	0	0	2010-02-25 18:32:53.74-05	2010-02-25 18:32:53.74-05	f	f	56	56	<p>Use the <strong>DAS</strong> server:</p>\n\n<p><a href='http://genome.ucsc.edu/cgi-bin/das/hg19/dna?segment=chr1:100000,200000'>http://genome.ucsc.edu/cgi-bin/das/hg19/dna?segment=chr1:100000,200000</a></p>\n		\N	<p>Use the <strong>DAS</strong> server:</p>\n\n<p><a rel="nofollow" href="http://genome.ucsc.edu/cgi-bin/das/hg19/dna?segment=chr1:100000,200000">http://genome.ucsc.edu/cgi-bin/das/hg19/dna?segment=chr1:100000,200000</a></p>\n
56	How To Get The Sequence Of A Genomic Region From Ucsc?	23	2	0	1	0	4	80	2	0	0	t	21	9	2010-02-21 17:13:39.32-05	2010-02-22 16:40:46.36-05	f	f	56	56	<p>Let's say I want to download the fasta sequence of the region chr1:100000..200000 from the UCSC browser.\nHow do you do that? I can't find a button to 'export to fasta' in the UCSC genome browser. I think that the solution is to click on one of the tracks displayed, but I am not sure of which.\nIf I go to the Tables section, I can't find a table with the fasta sequences among the many.</p>\n	sequence,ucsc,fasta	\N	<p>Let's say I want to download the fasta sequence of the region chr1:100000..200000 from the UCSC browser.\nHow do you do that? I can't find a button to 'export to fasta' in the UCSC genome browser. I think that the solution is to click on one of the tracks displayed, but I am not sure of which.\nIf I go to the Tables section, I can't find a table with the fasta sequences among the many.</p>\n
60	A: Finding Common Motifs In Sequences	31	31	0	1	1	1	0	0	0	0	t	0	0	2010-02-25 18:51:28.29-05	2010-02-25 18:51:28.29-05	f	f	4	4	<p>Some time ago I used SOMBRERO (<a href='http://bioinf.nuigalway.ie/sombrero/download.html'>http://bioinf.nuigalway.ie/sombrero/download.html</a>) with a good degree of success on finding motifs in a very diverse set of sequences. They have a Mac version for download as well as parallel versions for Irix and Linux.</p>\n		\N	<p>Some time ago I used SOMBRERO (<a rel="nofollow" href="http://bioinf.nuigalway.ie/sombrero/download.html">http://bioinf.nuigalway.ie/sombrero/download.html</a>) with a good degree of success on finding motifs in a very diverse set of sequences. They have a Mac version for download as well as parallel versions for Irix and Linux.</p>\n
4	Finding Common Motifs In Sequences	3	3	0	1	0	3	150	5	0	0	t	42	11	2009-09-30 18:09:06.677-04	2009-09-30 18:09:06.677-04	f	f	4	4	<p>I have a few hundred yeast sequences (20-80bp long) and I want to find common motifs (conserved bases at certain indices) in them. I am using a Mac</p>\n	yeast,motif	\N	<p>I have a few hundred yeast sequences (20-80bp long) and I want to find common motifs (conserved bases at certain indices) in them. I am using a Mac</p>\n
61	A: What Is The Best Way To Share Scripts Between Members Of A Lab?	31	31	0	1	1	1	0	0	0	0	t	0	0	2010-02-25 18:54:49.08-05	2010-02-25 18:54:49.08-05	f	f	58	58	<p>I would recommend you to setup a wiki for your group. If you do not have a server readily you can always use one of the many wiki services available for free like Wikispaces (www.wikispaces.com).</p>\n		\N	<p>I would recommend you to setup a wiki for your group. If you do not have a server readily you can always use one of the many wiki services available for free like Wikispaces www.wikispaces.com).</p>\n
62	A: What Is The Best Way To Share Scripts Between Members Of A Lab?	2	2	0	1	1	2	0	0	0	0	t	0	0	2010-02-25 19:24:46.38-05	2010-02-25 19:24:46.38-05	f	f	58	58	<p>Integrating with the source code management tool is essential, that way when code gets changed everyone can easily get the updated version. Wikis are also a good idea.</p>\n		\N	<p>Integrating with the source code management tool is essential, that way when code gets changed everyone can easily get the updated version. Wikis are also a good idea.</p>\n
86	A: What Is The Best Way To Share Scripts Between Members Of A Lab?	7	7	0	1	1	2	0	0	0	0	t	0	0	2010-02-26 21:44:04.547-05	2010-02-26 21:44:04.547-05	f	f	58	58	<p>This might be useful .</p>\n\n<p><a href='http://www.ploscompbiol.org/article/info%3Adoi%2F10.1371%2Fjournal.pcbi.1000424'>A Quick Guide to Organizing Computational Biology Projects</a></p>\n		\N	<p>This might be useful .</p>\n\n<p><a rel="nofollow" href="http://www.ploscompbiol.org/article/info%3Adoi%2F10.1371%2Fjournal.pcbi.1000424">A Quick Guide to Organizing Computational Biology Projects</a></p>\n
63	A: What Is Your Experience With The String (Interactions) Database?	35	35	0	1	1	3	0	0	0	0	t	0	0	2010-02-25 22:33:37.903-05	2010-02-25 22:33:37.903-05	f	f	46	46	<p>I've been using STRING extensively, but not for protein-protein interactions work. STRING, as you note, is a bit of a mutt in terms of the different data sources it mines. Some that you're missing include a broad literature-based search, as well as gene expression data sets. So if you're interested primarily in physical interactions or any other single type of data source, STRING is a poor choice for your work. On the other hand, STRING does provide confidence scores for each association, as well as annotation for their data source types (with the license). So you can use those to filter out the interactions derived from data types you don't want to see.</p>\n		\N	<p>I've been using STRING extensively, but not for protein-protein interactions work. STRING, as you note, is a bit of a mutt in terms of the different data sources it mines. Some that you're missing include a broad literature-based search, as well as gene expression data sets. So if you're interested primarily in physical interactions or any other single type of data source, STRING is a poor choice for your work. On the other hand, STRING does provide confidence scores for each association, as well as annotation for their data source types (with the license). So you can use those to filter out the interactions derived from data types you don't want to see.</p>\n
46	What Is Your Experience With The String (Interactions) Database?	23	87	0	1	0	3	93	2	0	0	t	21	7	2010-01-29 12:42:23.043-05	2010-03-05 23:31:43.937-05	f	f	46	46	<p>STRING is a database of predicted protein-protein interactions at EMBL. It cluster the results from many sources of protein-protein interactions databases, like Mint, etc.., and it also use the informations from KEGG-pathways and reactome, to provide the best annotations for the interactions of a protein.</p>\n\n<p>I am a bit confused from the results that I see there, because when I look at the genes in the pathway I am studying, I see many errors and annotations that I don't understand.</p>\n\n<p>What is your experience with STRING? If you want to do me a favor, go there and try to see the interactions annotated for a gene that you know already. Do you see anything weird?</p>\n	subjective,string,protein,interacti,ppi,pin	\N	<p>STRING is a database of predicted protein-protein interactions at EMBL. It cluster the results from many sources of protein-protein interactions databases, like Mint, etc.., and it also use the informations from KEGG-pathways and reactome, to provide the best annotations for the interactions of a protein.</p>\n\n<p>I am a bit confused from the results that I see there, because when I look at the genes in the pathway I am studying, I see many errors and annotations that I don't understand.</p>\n\n<p>What is your experience with STRING? If you want to do me a favor, go there and try to see the interactions annotated for a gene that you know already. Do you see anything weird?</p>\n
64	A: Which Are The Best Programming Languages To Study For A Bioinformatician?	35	35	0	1	1	2	0	0	0	0	t	0	0	2010-02-25 22:41:22.31-05	2010-02-25 22:41:22.31-05	f	f	34	34	<p>Perl can be quite lovely if you choose to write it well. If you find yourself in need of writing some perl, I'd highly recommend getting the Perl Best Practices book and going through it to learn how to make your perl code not suck. Essential tools for helping with that are perlcritic and perltidy, both of which I have bound to quick keystrokes in my emacs cperl-mode so as to make sure my code is in reasonably good shape. There's lots of blog articles out there about writing "Modern Perl" or "Enlightened Perl" that help make the language not just bearable but actually quite nice for a certain type of brain.</p>\n\n<p>One thing that Perl does very well that no other language does is quick text processing on the command line. If you want to do some simple processing of a text file (which is pretty standard in this business), perl is a fantastic package to do so. Stringing together a set of UNIX utilities on a Linux system will usually have you running for a half dozen manpages looking for conflicting and unique switches, where with perl I find that there's far less I have to remember to get the same effect. The book Minimal Perl goes in to this sort of thing in detail (perl as a better awk/sed/grep/etc) and I highly recommend having a look. At the very least, I've found that using perl in this fashion filled a hole in my toolkit that I didn't even realize was there. R and Python can, of course, do this sort of thing too, but not nearly so well as Perl.</p>\n		\N	<p>Perl can be quite lovely if you choose to write it well. If you find yourself in need of writing some perl, I'd highly recommend getting the Perl Best Practices book and going through it to learn how to make your perl code not suck. Essential tools for helping with that are perlcritic and perltidy, both of which I have bound to quick keystrokes in my emacs cperl-mode so as to make sure my code is in reasonably good shape. There's lots of blog articles out there about writing "Modern Perl" or "Enlightened Perl" that help make the language not just bearable but actually quite nice for a certain type of brain.</p>\n\n<p>One thing that Perl does very well that no other language does is quick text processing on the command line. If you want to do some simple processing of a text file (which is pretty standard in this business), perl is a fantastic package to do so. Stringing together a set of UNIX utilities on a Linux system will usually have you running for a half dozen manpages looking for conflicting and unique switches, where with perl I find that there's far less I have to remember to get the same effect. The book Minimal Perl goes in to this sort of thing in detail (perl as a better awk/sed/grep/etc) and I highly recommend having a look. At the very least, I've found that using perl in this fashion filled a hole in my toolkit that I didn't even realize was there. R and Python can, of course, do this sort of thing too, but not nearly so well as Perl.</p>\n
34	Which Are The Best Programming Languages To Study For A Bioinformatician?	23	23	0	1	0	3	486	4	0	0	t	28	14	2010-01-26 16:45:06.737-05	2010-04-15 12:08:30.167-04	f	f	34	34	<p>This is also a very classic question: Which is your favorite programming language in bioinformatics? Which languages would you recommend to a student wishing to enter the world of bioinformatics?</p>\n\n<p>This topic has already been discussed on the Internet, but I think it would be nice to discuss it here. Here there are some links to previous polls and discussions:</p>\n\n<ul>\n<li><a href='http://www.bioinformatics.org/poll/index.php?dispid=17'>Bioinformatics.org poll</a></li>\n<li><a href='http://openwetware.org/wiki/Biogang:Projects/Bioinformatics_Career_Survey_2008'>Bioinformatics Career survey 2008 by Michael Barton</a></li>\n</ul>\n	subjective,programming,languages	\N	<p>This is also a very classic question: Which is your favorite programming language in bioinformatics? Which languages would you recommend to a student wishing to enter the world of bioinformatics?</p>\n\n<p>This topic has already been discussed on the Internet, but I think it would be nice to discuss it here. Here there are some links to previous polls and discussions:</p>\n\n<ul>\n<li><a rel="nofollow" href="http://www.bioinformatics.org/poll/index.php?dispid=17">Bioinformatics.org poll</a></li>\n<li><a rel="nofollow" href="http://openwetware.org/wiki/Biogang:Projects/Bioinformatics_Career_Survey_2008">Bioinformatics Career survey 2008 by Michael Barton</a></li>\n</ul>\n
65	A: Which Operating System Do You Prefer For Bioinformatics?	33	33	0	1	1	2	0	0	0	0	t	0	0	2010-02-25 22:50:25.157-05	2010-02-25 22:50:25.157-05	f	f	33	33	<p>My tip: install Cygwin if you are using Windows </p>\n		\N	<p>My tip: install Cygwin if you are using Windows </p>\n
66	A: Site Use Guidelines	33	33	0	1	1	2	0	0	0	0	t	0	0	2010-02-25 22:52:10.69-05	2010-02-25 22:52:10.69-05	f	f	1	1	<p>Who is running this site?</p>\n		\N	<p>Who is running this site?</p>\n
97	A: Gene Id Conversion Tool	59	59	0	1	1	2	0	0	0	0	t	0	0	2010-03-01 18:05:13.92-05	2010-03-01 18:05:13.92-05	f	f	22	22	<p><a href='http://idconverter.bioinfo.cnio.es/'>http://idconverter.bioinfo.cnio.es/</a></p>\n\n<p>Is another possible solution to this, although you might find this is not as up to date as you might like either.</p>\n		\N	<p><a rel="nofollow" href="http://idconverter.bioinfo.cnio.es/">http://idconverter.bioinfo.cnio.es/</a></p>\n\n<p>Is another possible solution to this, although you might find this is not as up to date as you might like either.</p>\n
67	A: Which Operating System Do You Prefer For Bioinformatics?	38	38	0	1	1	3	0	0	0	0	t	0	0	2010-02-26 10:51:33.997-05	2010-02-26 10:56:37.95-05	f	f	33	33	<p>All of the 3 major platforms have their advantages, and I use all 3 practically every day. Mac OS X is my primary desktop OS, for a number of reasons, but mostly because I just seem more productive using it than any of the alternatives. All of my coding work is done over SSH on Linux (almost exclusively Ubuntu) servers. The power of Aptitude package management, and the robustness of this platform means that there really is no other choice for this kind of work. Finally I run Windows 7 on my netbook, because it is an excellent OS for that platform, and enables me to do everything I want that machine to be capable of, note-taking, blog writing, as a display machine for Powerpoint etc. It is also useful to have Internet Explorer kicking around somewhere for compatability testing.</p>\n\n<p>I wouldn't consider using any machine that I didn't have admin rights on for work purposes, if I have to jump through hoops to get stuff installed, it just slows me down too much. This is another reason for using OS X for my primary desktop, it allows me to escape the University's "Common Desktop" policy for Windows PCs, which would take control of my computer out of my hands.</p>\n		\N	<p>All of the 3 major platforms have their advantages, and I use all 3 practically every day. Mac OS X is my primary desktop OS, for a number of reasons, but mostly because I just seem more productive using it than any of the alternatives. All of my coding work is done over SSH on Linux (almost exclusively Ubuntu) servers. The power of Aptitude package management, and the robustness of this platform means that there really is no other choice for this kind of work. Finally I run Windows 7 on my netbook, because it is an excellent OS for that platform, and enables me to do everything I want that machine to be capable of, note-taking, blog writing, as a display machine for Powerpoint etc. It is also useful to have Internet Explorer kicking around somewhere for compatability testing.</p>\n\n<p>I wouldn't consider using any machine that I didn't have admin rights on for work purposes, if I have to jump through hoops to get stuff installed, it just slows me down too much. This is another reason for using OS X for my primary desktop, it allows me to escape the University's "Common Desktop" policy for Windows PCs, which would take control of my computer out of my hands.</p>\n
33	Which Operating System Do You Prefer For Bioinformatics?	23	23	0	1	0	2	307	4	0	0	t	28	9	2010-01-26 16:14:38.623-05	2010-03-02 22:16:12.33-05	f	f	33	33	<p>So, you will probably hate me for asking this question here, as there are lot of forum and blog posts on internet about it and it is also a very subjective question.</p>\n\n<p>However, it may be a starting point for a good discussion, if we don't flame... Which operating system do you usually use for your work? Did you install it by yourself, and do you have administrative rights on it, or is there any IT administrator in your lab? </p>\n	general,subjective,os	\N	<p>So, you will probably hate me for asking this question here, as there are lot of forum and blog posts on internet about it and it is also a very subjective question.</p>\n\n<p>However, it may be a starting point for a good discussion, if we don't flame... Which operating system do you usually use for your work? Did you install it by yourself, and do you have administrative rights on it, or is there any IT administrator in your lab? </p>\n
68	A: What Is The Best Way To Share Scripts Between Members Of A Lab?	38	38	0	1	1	2	0	0	0	0	t	0	0	2010-02-26 11:07:14.7-05	2010-02-26 11:07:14.7-05	f	f	58	58	<p>If you want to see the code, but also store associated information, such as expected outputs etc, then a wiki probably is the best choice (we prefer <a href='http://www.dokuwiki.org/dokuwiki'>DokuWiki</a> here), although this would involve a lot of manual effort to document each script. </p>\n\n<p>Use of a site such as GitHub would give you version control + a handy place to read code, although it is not free to host private repositories there, which I guess is what the majority of labs would require. </p>\n\n<p>If privacy is not a concern, then I would consider GitHub <a href='http://gist.github.com/'>gists</a> for code, which can then be embedded in a <a href='http://posterous.com/'>Posterous</a> blog for comments. Posterous automatically unfolds Gist URLs into code samples in blog posts, so then you can annotate them easily. This would be a lot less manual effort than a wiki.</p>\n		\N	<p>If you want to see the code, but also store associated information, such as expected outputs etc, then a wiki probably is the best choice (we prefer <a rel="nofollow" href="http://www.dokuwiki.org/dokuwiki">DokuWiki</a> here), although this would involve a lot of manual effort to document each script. </p>\n\n<p>Use of a site such as GitHub would give you version control + a handy place to read code, although it is not free to host private repositories there, which I guess is what the majority of labs would require. </p>\n\n<p>If privacy is not a concern, then I would consider GitHub <a rel="nofollow" href="http://gist.github.com/">gists</a> for code, which can then be embedded in a <a rel="nofollow" href="http://posterous.com/">Posterous</a> blog for comments. Posterous automatically unfolds Gist URLs into code samples in blog posts, so then you can annotate them easily. This would be a lot less manual effort than a wiki.</p>\n
70	A: What Is The Best Way To Share Scripts Between Members Of A Lab?	40	40	0	1	1	2	0	0	0	0	t	0	0	2010-02-26 14:15:16.893-05	2010-02-26 14:15:16.893-05	f	f	58	58	<p>You might also want to setup a simple snippets database. Navysnip application by Jason Strutz is easy to install and run if you have ruby and rubyonrails installed.</p>\n\n<p>git clone git://github.com/navyrain/navysnip.git\n  cd navysnip\n  sudo rake gems:install\n  rake db:migrate\n  ruby script/server\nThen visit your app at <a href='http://localhost:3000'>http://localhost:3000</a></p>\n\n<p>check out <a href='http://github.com/navyrain/navysnip'>http://github.com/navyrain/navysnip</a>  for complete details</p>\n		\N	<p>You might also want to setup a simple snippets database. Navysnip application by Jason Strutz is easy to install and run if you have ruby and rubyonrails installed.</p>\n\n<p>git clone git://github.com/navyrain/navysnip.git\n  cd navysnip\n  sudo rake gems:install\n  rake db:migrate\n  ruby script/server\nThen visit your app at <a rel="nofollow" href="http://localhost:3000">http://localhost:3000</a></p>\n\n<p>check out <a rel="nofollow" href="http://github.com/navyrain/navysnip">http://github.com/navyrain/navysnip</a>  for complete details</p>\n
71	A: Using Hdf5 To Store  Bio-Data	42	42	0	1	1	2	0	0	0	0	t	0	0	2010-02-26 14:47:41.697-05	2010-02-26 14:47:41.697-05	f	f	69	69	<p>Hello Pierre!</p>\n\n<p>I have been talking with the BioHDF guys and from what they tell me, their work will be centered around a number of command-line APIs, written in C, that will address some areas of usage which for now do not seem to overlap. </p>\n\n<p>I have seen this example on their site:\n<a href='http://www.hdfgroup.org/projects/biohdf/biohdf_tools.html'>http://www.hdfgroup.org/projects/biohdf/biohdf_tools.html</a>\nDon't know if that helps.</p>\n\n<p>I have been talking with them to see if we can achieve an API for saving genotype data. Don't know yet where that will lead me.</p>\n\n<p>If you are looking for something more versatile, you will probably have to delve in the official HDF5 C code ( <a href='http://www.hdfgroup.org/HDF5/Tutor/'>http://www.hdfgroup.org/HDF5/Tutor/</a> ), which seems to be the only one that offers all the functionality and goodies of that impressive storage system. </p>\n		\N	<p>Hello Pierre!</p>\n\n<p>I have been talking with the BioHDF guys and from what they tell me, their work will be centered around a number of command-line APIs, written in C, that will address some areas of usage which for now do not seem to overlap. </p>\n\n<p>I have seen this example on their site:\n<a rel="nofollow" href="http://www.hdfgroup.org/projects/biohdf/biohdf_tools.html">http://www.hdfgroup.org/projects/biohdf/biohdf_tools.html</a>\nDon't know if that helps.</p>\n\n<p>I have been talking with them to see if we can achieve an API for saving genotype data. Don't know yet where that will lead me.</p>\n\n<p>If you are looking for something more versatile, you will probably have to delve in the official HDF5 C code ( <a rel="nofollow" href="http://www.hdfgroup.org/HDF5/Tutor/">http://www.hdfgroup.org/HDF5/Tutor/</a> ), which seems to be the only one that offers all the functionality and goodies of that impressive storage system. </p>\n
72	A: Using Hdf5 To Store  Bio-Data	23	23	0	1	1	1	0	0	0	0	t	0	0	2010-02-26 14:54:03.447-05	2010-02-26 14:54:03.447-05	f	f	69	69	<p>Unfortunately I don't have any example to shows you yet.\nI don't know how to program in C/C++ so I have been looking at two hdf5 wrappers in python, <a href='http://www.pytables.org/moin'>PyTables</a> and <a href='http://h5py.alfven.org/'>H5PY</a>.</p>\n\n<p>PyTables has a database-like approach in which HDF5 is used as a sort of hierarchical database, in which a column can be a table itself, allowing to store nested data. For example, you have a table called 'SNPs' with two columns, 'id' and 'genotypes'; the column 'genotypes' contains a nested table, with the columns 'individual' and 'genotype'; and so on.</p>\n\n<p>H5Py is basically a re-implementation of numpy's arrays, so you can store and access arrays/matrixes as you would do with numpy (it is similar to arrays and matrixes in matlab, R, and any other language with this data type) and they are stored in an HDF5 file so the access is faster.</p>\n		\N	<p>Unfortunately I don't have any example to shows you yet.\nI don't know how to program in C/C++ so I have been looking at two hdf5 wrappers in python, <a rel="nofollow" href="http://www.pytables.org/moin">PyTables</a> and <a rel="nofollow" href="http://h5py.alfven.org/">H5PY</a>.</p>\n\n<p>PyTables has a database-like approach in which HDF5 is used as a sort of hierarchical database, in which a column can be a table itself, allowing to store nested data. For example, you have a table called 'SNPs' with two columns, 'id' and 'genotypes'; the column 'genotypes' contains a nested table, with the columns 'individual' and 'genotype'; and so on.</p>\n\n<p>H5Py is basically a re-implementation of numpy's arrays, so you can store and access arrays/matrixes as you would do with numpy (it is similar to arrays and matrixes in matlab, R, and any other language with this data type) and they are stored in an HDF5 file so the access is faster.</p>\n
73	A: Using Hdf5 To Store  Bio-Data	2	2	0	1	1	3	0	0	0	0	t	0	0	2010-02-26 14:56:22.753-05	2010-02-26 15:01:39.187-05	f	f	69	69	<p>In the <a href='http://code.google.com/p/genetrack/'>GeneTrack</a> software we have used HDF to store values for each genomic base. Its main advantage over other storage systems was that it was able to return consecutive values with minimal overhead. </p>\n\n<p>For example it is <em>extremely fast</em> (ms) in retrieving say 100,000 consecutive values starting with a certain index.We used the <a href='http://www.pytables.org/moin'>Python bindings</a> to HDF. An added advantage of these bindings is that they will return the data back as numpy arrays (very fast numerical operations). </p>\n\n<p>Here is the relevant code that deals with HDF only: <a href='http://code.google.com/p/genetrack/source/browse/trunk/atlas/hdf.py'>hdf.py</a></p>\n\n<p>The HDF schema is set up in a different module, but in the end it simply something like:</p>\n\n<pre><code>class MySchema( IsDescription ):\n    """\n    Stores a triplet of float values for each index.\n    """\n    ix = IntCol  ( pos=1 )  # index\n    wx = FloatCol( pos=2 )  # values on the W (forward) strand\n    cx = FloatCol( pos=3 )  # value on the C (reverse) strand\n    ax = FloatCol( pos=4 )  # weighted value on the combined W + C strands\n</code></pre>\n		\N	<p>In the <a rel="nofollow" href="http://code.google.com/p/genetrack/">GeneTrack</a> software we have used HDF to store values for each genomic base. Its main advantage over other storage systems was that it was able to return consecutive values with minimal overhead. </p>\n\n<p>For example it is <em>extremely fast</em> (ms) in retrieving say 100,000 consecutive values starting with a certain index.We used the <a rel="nofollow" href="http://www.pytables.org/moin">Python bindings</a> to HDF. An added advantage of these bindings is that they will return the data back as numpy arrays (very fast numerical operations). </p>\n\n<p>Here is the relevant code that deals with HDF only: <a rel="nofollow" href="http://code.google.com/p/genetrack/source/browse/trunk/atlas/hdf.py">hdf.py</a></p>\n\n<p>The HDF schema is set up in a different module, but in the end it simply something like:</p>\n\n<pre><code>class MySchema( IsDescription ):\n    """\n    Stores a triplet of float values for each index.\n    """\n    ix = IntCol  ( pos=1 )  # index\n    wx = FloatCol( pos=2 )  # values on the W (forward) strand\n    cx = FloatCol( pos=3 )  # value on the C (reverse) strand\n    ax = FloatCol( pos=4 )  # weighted value on the combined W + C strands\n</code></pre>\n
74	A: Using Hdf5 To Store  Bio-Data	42	42	0	1	1	4	0	0	0	0	t	0	0	2010-02-26 15:26:41.15-05	2010-02-26 15:26:41.15-05	f	f	69	69	<p>What I do have is a netCDF-3 based Java application that I could show you.\nNetCDF-3 is basically the same idea as HDF, but quite more limited as it cannot do compound datatypes among other limitations.</p>\n\n<p>But here's a small test code example to toy with:</p>\n\n<p>package netCDF;</p>\n\n<p>import java.io.File;\nimport ucar.ma2.<em>;\nimport ucar.nc2.</em>;\nimport java.io.IOException;\nimport java.util.ArrayList;</p>\n\n<p>/**</p>\n\n<hr />\n\n<ul>\n<li>@author Fernando Muñiz Fernandez</li>\n<li>IBE, Institute of Evolutionary Biology (UPF-CSIC)</li>\n<li>CEXS-UPF-PRBB</li>\n</ul>\n\n<hr />\n\n<ul>\n<li><p>THIS TO CREATE THE netCDF-3 GENOTYPE FILE\n*/\npublic class CreateNetcdf {</p>\n\n<p>public static NetcdfFileWriteable setDimsAndAttributes(Integer studyId, \n                                      String technology, \n                                      String description, \n                                      String strand, \n                                      int sampleSetSize,\n                                      int markerSetSize) throws InvalidRangeException, IOException {</p>\n\n<pre><code>///////////// CREATE netCDF-3 FILE ////////////\nString genotypesFolder = "/media/data/genotypes";\nFile pathToStudy = new File(genotypesFolder+"/netCDF_test");\nint gtSpan = constants.cNetCDF.Strides.STRIDE_GT;\nint markerSpan = constants.cNetCDF.Strides.STRIDE_MARKER_NAME;\nint sampleSpan = constants.cNetCDF.Strides.STRIDE_SAMPLE_NAME;\n\nString matrixName = "prototype";\nString writeFileName = pathToStudy+"/"+matrixName+".nc";\nNetcdfFileWriteable ncfile = NetcdfFileWriteable.createNew(writeFileName, false);\n\n// add dimensions\nDimension samplesDim = ncfile.addDimension("samples", sampleSetSize);\nDimension markersDim = ncfile.addDimension("markers", markerSetSize);\nDimension gtSpanDim = ncfile.addDimension("span", gtSpan);\nArrayList dims = new ArrayList();\ndims.add(samplesDim);\ndims.add(markersDim);\ndims.add(gtSpanDim);\n\nArrayList markerGenotypeDims = new ArrayList();\nmarkerGenotypeDims.add(markersDim);\nmarkerGenotypeDims.add(markerSpan);\n\nArrayList markerPositionDim = new ArrayList();\nmarkerPositionDim.add(markersDim);\n\nArrayList markerPropertyDim32 = new ArrayList();\nmarkerPropertyDim32.add(markersDim);\nmarkerPropertyDim32.add(32);\n\nArrayList markerPropertyDim16 = new ArrayList();\nmarkerPropertyDim16.add(markersDim);\nmarkerPropertyDim16.add(16);\n\nArrayList markerPropertyDim8 = new ArrayList();\nmarkerPropertyDim8.add(markersDim);\nmarkerPropertyDim8.add(8);\n\nArrayList markerPropertyDim2 = new ArrayList();\nmarkerPropertyDim2.add(markersDim);\nmarkerPropertyDim2.add(2);\n\nArrayList markerPropertyDim1 = new ArrayList();\nmarkerPropertyDim1.add(markersDim);\nmarkerPropertyDim1.add(1);\n\nArrayList sampleSetDims = new ArrayList();\nsampleSetDims.add(samplesDim);\nsampleSetDims.add(sampleSpan);\n\n// Define Marker Variables\nncfile.addVariable("markerset", DataType.CHAR, markerGenotypeDims);\nncfile.addVariableAttribute("markerset", constants.cNetCDF.Attributes.LENGTH, markerSetSize);\n\nncfile.addVariable("marker_chromosome", DataType.CHAR, markerPropertyDim8);\nncfile.addVariable("marker_position", DataType.CHAR, markerPropertyDim32);\nncfile.addVariable("marker_position_int", DataType.INT, markerPositionDim);\nncfile.addVariable("marker_strand", DataType.CHAR, markerPropertyDim8);\n\nncfile.addVariable("marker_property_1", DataType.CHAR, markerPropertyDim1);\nncfile.addVariable("marker_property_2", DataType.CHAR, markerPropertyDim2);\nncfile.addVariable("marker_property_8", DataType.CHAR, markerPropertyDim8);\nncfile.addVariable("marker_property_16", DataType.CHAR, markerPropertyDim16);\nncfile.addVariable("marker_property_32", DataType.CHAR, markerPropertyDim32);\n\n// Define Sample Variables\nncfile.addVariable("sampleset", DataType.CHAR, sampleSetDims);\nncfile.addVariableAttribute("sampleset", constants.cNetCDF.Attributes.LENGTH, sampleSetSize);\n\n// Define Genotype Variables\nncfile.addVariable("genotypes", DataType.CHAR, dims);\nncfile.addVariableAttribute("genotypes", constants.cNetCDF.Attributes.GLOB_STRAND, "+/-");\n\n// add global attributes\nncfile.addGlobalAttribute(constants.cNetCDF.Attributes.GLOB_STUDY, studyId);\nncfile.addGlobalAttribute(constants.cNetCDF.Attributes.GLOB_TECHNOLOGY, "INTERNAL");\nncfile.addGlobalAttribute(constants.cNetCDF.Attributes.GLOB_DESCRIPTION, "Matrix created by MOAPI through addition of 2 matrices");\n\nreturn ncfile;\n</code></pre>\n\n<p>}\n}</p></li>\n</ul>\n\n<p>Use the above in the following way:</p>\n\n<p>package netCDF;</p>\n\n<p>import java.util.List;\nimport ucar.ma2.<em>;\nimport ucar.nc2.</em>;\nimport java.io.IOException;</p>\n\n<p>/**</p>\n\n<hr />\n\n<p>* @author Fernando Muñiz Fernandez\n * IBE, Institute of Evolutionary Biology (UPF-CSIC)\n * CEXS-UPF-PRBB</p>\n\n<hr />\n\n<p>* THIS TO GENERATE A netCDF-3 GENOTYPE DB\n */</p>\n\n<p>public class TestWriteNetcdf {</p>\n\n<pre><code>public static void main(String[] arg) throws InvalidRangeException, IOException {\n\n    NetcdfFileWriteable ncfile = netCDF.CreateNetcdf.setDimsAndAttributes(0, \n                                                                      "INTERNAL", \n                                                                      "test in TestWriteNetcdf", \n                                                                      "+/-", \n                                                                      5,\n                                                                      10);\n\n    // create the file\n    try {\n        ncfile.create();\n    } catch (IOException e) {\n        System.err.println("ERROR creating file "+ncfile.getLocation()+"\\n"+e);\n    }\n\n\n    ////////////// FILL'ER UP! ////////////////\n    List&lt;Dimension&gt; dims = ncfile.getDimensions();\n    Dimension samplesDim = dims.get(0);\n    Dimension markersDim = dims.get(1);\n    Dimension markerSpanDim = dims.get(2);\n\n    ArrayChar charArray = new ArrayChar.D3(samplesDim.getLength(),markersDim.getLength(),markerSpanDim.getLength());\n    int i,j;\n    Index ima = charArray.getIndex();\n\n\n    int method = 1;\n    switch (method) {\n        case 1: \n            // METHOD 1: Feed the complete genotype in one go\n            for (i=0; i&lt;samplesDim.getLength(); i++) {\n                for (j=0; j&lt;markersDim.getLength(); j++) {\n                    char c = (char) ((char) j + 65);\n                    String s = Character.toString(c) + Character.toString(c);\n                    charArray.setString(ima.set(i,j,0),s);\n                    System.out.println("SNP: "+i);\n                }\n            }\n            break;\n        case 2: \n            //METHOD 2: One snp at a time -&gt; feed in all samples\n            for (i=0; i&lt;markersDim.getLength(); i++) {\n                charArray.setString(ima.set(i,0), "s"+i+"I0");\n                System.out.println("SNP: "+i);\n            }\n            break;\n        case 3: \n            //METHOD 3: One sample at a time -&gt; feed in all snps\n            break;\n    }\n\n\n\n    int[] offsetOrigin = new int[3]; //0,0\n    try {\n        ncfile.write("genotypes", offsetOrigin, charArray);\n        //ncfile.write("genotype", origin, A);\n    } catch (IOException e) {\n        System.err.println("ERROR writing file");\n    } catch (InvalidRangeException e) {\n        e.printStackTrace();\n    }\n\n    // close the file\n    try {\n        ncfile.close();\n    } catch (IOException e) {\n        System.err.println("ERROR creating file "+ncfile.getLocation()+"\\n"+e);\n    }\n\n}\n</code></pre>\n\n<p>}</p>\n		\N	<p>What I do have is a netCDF-3 based Java application that I could show you.\nNetCDF-3 is basically the same idea as HDF, but quite more limited as it cannot do compound datatypes among other limitations.</p>\n\n<p>But here's a small test code example to toy with:</p>\n\n<p>package netCDF;</p>\n\n<p>import java.io.File;\nimport ucar.ma2.<em>;\nimport ucar.nc2.</em>;\nimport java.io.IOException;\nimport java.util.ArrayList;</p>\n\n<p>/**</p>\n\n<hr>\n\n<ul>\n<li>@author Fernando Muñiz Fernandez</li>\n<li>IBE, Institute of Evolutionary Biology (UPF-CSIC)</li>\n<li>CEXS-UPF-PRBB</li>\n</ul>\n\n<hr>\n\n<ul>\n<li><p>THIS TO CREATE THE netCDF-3 GENOTYPE FILE\n*/\npublic class CreateNetcdf {</p>\n\n<p>public static NetcdfFileWriteable setDimsAndAttributes(Integer studyId, \n                                      String technology, \n                                      String description, \n                                      String strand, \n                                      int sampleSetSize,\n                                      int markerSetSize) throws InvalidRangeException, IOException {</p>\n\n<pre><code>///////////// CREATE netCDF-3 FILE ////////////\nString genotypesFolder = "/media/data/genotypes";\nFile pathToStudy = new File(genotypesFolder+"/netCDF_test");\nint gtSpan = constants.cNetCDF.Strides.STRIDE_GT;\nint markerSpan = constants.cNetCDF.Strides.STRIDE_MARKER_NAME;\nint sampleSpan = constants.cNetCDF.Strides.STRIDE_SAMPLE_NAME;\n\nString matrixName = "prototype";\nString writeFileName = pathToStudy+"/"+matrixName+".nc";\nNetcdfFileWriteable ncfile = NetcdfFileWriteable.createNew(writeFileName, false);\n\n// add dimensions\nDimension samplesDim = ncfile.addDimension("samples", sampleSetSize);\nDimension markersDim = ncfile.addDimension("markers", markerSetSize);\nDimension gtSpanDim = ncfile.addDimension("span", gtSpan);\nArrayList dims = new ArrayList();\ndims.add(samplesDim);\ndims.add(markersDim);\ndims.add(gtSpanDim);\n\nArrayList markerGenotypeDims = new ArrayList();\nmarkerGenotypeDims.add(markersDim);\nmarkerGenotypeDims.add(markerSpan);\n\nArrayList markerPositionDim = new ArrayList();\nmarkerPositionDim.add(markersDim);\n\nArrayList markerPropertyDim32 = new ArrayList();\nmarkerPropertyDim32.add(markersDim);\nmarkerPropertyDim32.add(32);\n\nArrayList markerPropertyDim16 = new ArrayList();\nmarkerPropertyDim16.add(markersDim);\nmarkerPropertyDim16.add(16);\n\nArrayList markerPropertyDim8 = new ArrayList();\nmarkerPropertyDim8.add(markersDim);\nmarkerPropertyDim8.add(8);\n\nArrayList markerPropertyDim2 = new ArrayList();\nmarkerPropertyDim2.add(markersDim);\nmarkerPropertyDim2.add(2);\n\nArrayList markerPropertyDim1 = new ArrayList();\nmarkerPropertyDim1.add(markersDim);\nmarkerPropertyDim1.add(1);\n\nArrayList sampleSetDims = new ArrayList();\nsampleSetDims.add(samplesDim);\nsampleSetDims.add(sampleSpan);\n\n// Define Marker Variables\nncfile.addVariable("markerset", DataType.CHAR, markerGenotypeDims);\nncfile.addVariableAttribute("markerset", constants.cNetCDF.Attributes.LENGTH, markerSetSize);\n\nncfile.addVariable("marker_chromosome", DataType.CHAR, markerPropertyDim8);\nncfile.addVariable("marker_position", DataType.CHAR, markerPropertyDim32);\nncfile.addVariable("marker_position_int", DataType.INT, markerPositionDim);\nncfile.addVariable("marker_strand", DataType.CHAR, markerPropertyDim8);\n\nncfile.addVariable("marker_property_1", DataType.CHAR, markerPropertyDim1);\nncfile.addVariable("marker_property_2", DataType.CHAR, markerPropertyDim2);\nncfile.addVariable("marker_property_8", DataType.CHAR, markerPropertyDim8);\nncfile.addVariable("marker_property_16", DataType.CHAR, markerPropertyDim16);\nncfile.addVariable("marker_property_32", DataType.CHAR, markerPropertyDim32);\n\n// Define Sample Variables\nncfile.addVariable("sampleset", DataType.CHAR, sampleSetDims);\nncfile.addVariableAttribute("sampleset", constants.cNetCDF.Attributes.LENGTH, sampleSetSize);\n\n// Define Genotype Variables\nncfile.addVariable("genotypes", DataType.CHAR, dims);\nncfile.addVariableAttribute("genotypes", constants.cNetCDF.Attributes.GLOB_STRAND, "+/-");\n\n// add global attributes\nncfile.addGlobalAttribute(constants.cNetCDF.Attributes.GLOB_STUDY, studyId);\nncfile.addGlobalAttribute(constants.cNetCDF.Attributes.GLOB_TECHNOLOGY, "INTERNAL");\nncfile.addGlobalAttribute(constants.cNetCDF.Attributes.GLOB_DESCRIPTION, "Matrix created by MOAPI through addition of 2 matrices");\n\nreturn ncfile;\n</code></pre>\n\n<p>}\n}</p></li>\n</ul>\n\n<p>Use the above in the following way:</p>\n\n<p>package netCDF;</p>\n\n<p>import java.util.List;\nimport ucar.ma2.<em>;\nimport ucar.nc2.</em>;\nimport java.io.IOException;</p>\n\n<p>/**</p>\n\n<hr>\n\n<p>* @author Fernando Muñiz Fernandez\n * IBE, Institute of Evolutionary Biology (UPF-CSIC)\n * CEXS-UPF-PRBB</p>\n\n<hr>\n\n<p>* THIS TO GENERATE A netCDF-3 GENOTYPE DB\n */</p>\n\n<p>public class TestWriteNetcdf {</p>\n\n<pre><code>public static void main(String[] arg) throws InvalidRangeException, IOException {\n\n    NetcdfFileWriteable ncfile = netCDF.CreateNetcdf.setDimsAndAttributes(0, \n                                                                      "INTERNAL", \n                                                                      "test in TestWriteNetcdf", \n                                                                      "+/-", \n                                                                      5,\n                                                                      10);\n\n    // create the file\n    try {\n        ncfile.create();\n    } catch (IOException e) {\n        System.err.println("ERROR creating file "+ncfile.getLocation()+"\\n"+e);\n    }\n\n\n    ////////////// FILL'ER UP! ////////////////\n    List&lt;Dimension&gt; dims = ncfile.getDimensions();\n    Dimension samplesDim = dims.get(0);\n    Dimension markersDim = dims.get(1);\n    Dimension markerSpanDim = dims.get(2);\n\n    ArrayChar charArray = new ArrayChar.D3(samplesDim.getLength(),markersDim.getLength(),markerSpanDim.getLength());\n    int i,j;\n    Index ima = charArray.getIndex();\n\n\n    int method = 1;\n    switch (method) {\n        case 1: \n            // METHOD 1: Feed the complete genotype in one go\n            for (i=0; i&lt;samplesDim.getLength(); i++) {\n                for (j=0; j&lt;markersDim.getLength(); j++) {\n                    char c = (char) ((char) j + 65);\n                    String s = Character.toString(c) + Character.toString(c);\n                    charArray.setString(ima.set(i,j,0),s);\n                    System.out.println("SNP: "+i);\n                }\n            }\n            break;\n        case 2: \n            //METHOD 2: One snp at a time -&gt; feed in all samples\n            for (i=0; i&lt;markersDim.getLength(); i++) {\n                charArray.setString(ima.set(i,0), "s"+i+"I0");\n                System.out.println("SNP: "+i);\n            }\n            break;\n        case 3: \n            //METHOD 3: One sample at a time -&gt; feed in all snps\n            break;\n    }\n\n\n\n    int[] offsetOrigin = new int[3]; //0,0\n    try {\n        ncfile.write("genotypes", offsetOrigin, charArray);\n        //ncfile.write("genotype", origin, A);\n    } catch (IOException e) {\n        System.err.println("ERROR writing file");\n    } catch (InvalidRangeException e) {\n        e.printStackTrace();\n    }\n\n    // close the file\n    try {\n        ncfile.close();\n    } catch (IOException e) {\n        System.err.println("ERROR creating file "+ncfile.getLocation()+"\\n"+e);\n    }\n\n}\n</code></pre>\n\n<p>}</p>\n
75	A: Site Use Guidelines	26	26	0	1	1	1	0	0	0	0	t	0	0	2010-02-26 15:44:01.49-05	2010-02-26 15:44:01.49-05	f	f	1	1	<p>This is an excellent initiative: congratulations and thank you for setting it up!</p>\n\n<p>I guess this site will be all the more useful as there are more contributers... So I guess that good questions for the administrator(s) of this site are: </p>\n\n<ul>\n<li>Do you have a plan for advertising this site/attracting new Users?</li>\n<li>How can the Users help?</li>\n</ul>\n		\N	<p>This is an excellent initiative: congratulations and thank you for setting it up!</p>\n\n<p>I guess this site will be all the more useful as there are more contributers... So I guess that good questions for the administrator(s) of this site are: </p>\n\n<ul>\n<li>Do you have a plan for advertising this site/attracting new Users?</li>\n<li>How can the Users help?</li>\n</ul>\n
1	Site Use Guidelines	2	2	0	1	0	2	70	5	0	0	t	42	8	2009-09-30 16:12:07.053-04	2010-02-26 15:10:59.777-05	f	f	1	1	<p>Here are a few guidelines:</p>\n\n<ol>\n<li>The site's goal is to answer bioinformatics and systems biology related questions</li>\n<li>Answer questions to gain <em>reputation</em>. </li>\n<li>Don't forget to vote for answers that you like! Registered users may vote on answers.</li>\n<li>If you are the one asking the original question you may also select the best answer</li>\n<li>Subscribe to the RSS feeds for all questions or a single question to keep up to date with the developments</li>\n</ol>\n	guidelines	\N	<p>Here are a few guidelines:</p>\n\n<ol>\n<li>The site's goal is to answer bioinformatics and systems biology related questions</li>\n<li>Answer questions to gain <em>reputation</em>. </li>\n<li>Don't forget to vote for answers that you like! Registered users may vote on answers.</li>\n<li>If you are the one asking the original question you may also select the best answer</li>\n<li>Subscribe to the RSS feeds for all questions or a single question to keep up to date with the developments</li>\n</ol>\n
76	Looking For A 'Hello World" Plugin For Taverna.	30	30	0	1	0	3	77	0	0	0	t	7	3	2010-02-26 16:37:25.81-05	2010-03-03 14:39:44.443-05	f	f	76	76	<p>Hi all,\nI'd like to create a very simple plugin for <a href='http://www.taverna.org.uk/'>Taverna 2.0</a>, something very simple like like implementing a 'convertDnaToRna'. There is already some source code that can be found on the net e.g. Egon Willighagen's code at <a href='http://github.com/egonw/cdk-taverna'>http://github.com/egonw/cdk-taverna</a> but it requires to know <strong>Maven</strong> and.... I'm too <strong>lazy</strong> :-)</p>\n\n<p>How can I implement this kind of simple plugin without maven ? ( I <em>just</em> want to compile, package &amp; create the right XML config files)</p>\n\n<p>Thanks !</p>\n	compilation,taverna,plugin,maven,workflow	\N	<p>Hi all,\nI'd like to create a very simple plugin for <a rel="nofollow" href="http://www.taverna.org.uk/">Taverna 2.0</a>, something very simple like like implementing a 'convertDnaToRna'. There is already some source code that can be found on the net e.g. Egon Willighagen's code at <a rel="nofollow" href="http://github.com/egonw/cdk-taverna">http://github.com/egonw/cdk-taverna</a> but it requires to know <strong>Maven</strong> and.... I'm too <strong>lazy</strong> :-)</p>\n\n<p>How can I implement this kind of simple plugin without maven ? ( I <em>just</em> want to compile, package &amp; create the right XML config files)</p>\n\n<p>Thanks !</p>\n
78	A: How Do I Convert An Illumina Export File To Bed?	10	10	0	1	1	2	0	0	0	0	t	0	0	2010-02-26 17:15:18.997-05	2010-02-26 17:15:18.997-05	f	f	77	77	<p>I found a script <a href='http://mng.iop.kcl.ac.uk/site/node/378'>on another site</a>, Uses perl but I have not checked for correctness:</p>\n\n<pre><code>#!/usr/bin/perl\n\nuse strict;\nuse warnings;\nuse IO::File;\n\nmy $filename = shift @ARGV;\ndie "Usage\\n\\tperl sorted2bed.pl s_X_sorted.txt &gt; s_X_sorted.bed\\n" unless $filename;\nchomp $filename;\n\nmy $fh = new IO::File;\n$fh-&gt;open("&lt; $filename") or die "Can't open file $filename for reading: $!";\n\nmy $count = 1;\nwhile(my $line = &lt;$fh&gt;){\n   warn "Line $count\\n" if $count%1000 == 0;\n   $count++;\n   my @line = split "\\t", $line;\n   my $chr = $line[10];\n   $chr =~ s/(.+)\\.fa/$1/;\n   #Illumina is 1-based, BED is 0-based\n   my $start = $line[12]-1;\n   my $read = $line[8];\n   my $end = $start + length $read;\n   my $strand = $line[13] eq 'F' ? '+': '-';\n   my $score = $line[15];\n   my $bedline = "$chr\\t$start\\t$end\\t$read\\t$score\\t$strand\\n";\n   print $bedline;\n}\n$fh-&gt;close;\n\nwarn "Done";\n</code></pre>\n		\N	<p>I found a script <a rel="nofollow" href="http://mng.iop.kcl.ac.uk/site/node/378">on another site</a>, Uses perl but I have not checked for correctness:</p>\n\n<pre><code>#!/usr/bin/perl\n\nuse strict;\nuse warnings;\nuse IO::File;\n\nmy $filename = shift @ARGV;\ndie "Usage\\n\\tperl sorted2bed.pl s_X_sorted.txt &gt; s_X_sorted.bed\\n" unless $filename;\nchomp $filename;\n\nmy $fh = new IO::File;\n$fh-&gt;open("&lt; $filename") or die "Can't open file $filename for reading: $!";\n\nmy $count = 1;\nwhile(my $line = &lt;$fh&gt;){\n   warn "Line $count\\n" if $count%1000 == 0;\n   $count++;\n   my @line = split "\\t", $line;\n   my $chr = $line[10];\n   $chr =~ s/(.+)\\.fa/$1/;\n   #Illumina is 1-based, BED is 0-based\n   my $start = $line[12]-1;\n   my $read = $line[8];\n   my $end = $start + length $read;\n   my $strand = $line[13] eq 'F' ? '+': '-';\n   my $score = $line[15];\n   my $bedline = "$chr\\t$start\\t$end\\t$read\\t$score\\t$strand\\n";\n   print $bedline;\n}\n$fh-&gt;close;\n\nwarn "Done";\n</code></pre>\n
77	How Do I Convert An Illumina Export File To Bed?	44	23	0	1	0	1	111	1	0	0	t	14	3	2010-02-26 16:49:18.627-05	2010-03-02 18:45:34.307-05	f	f	77	77	<p>I have some illumina data generated from the latest version of the illumina pipeline (1.6.0) I need to convert my data into BED to view in ucsc genome browser.</p>\n\n<p>This seems like it should be a fairly common task, however, I am unable to find any scripts to convert my data.</p>\n	bed,conversion,format	\N	<p>I have some illumina data generated from the latest version of the illumina pipeline (1.6.0) I need to convert my data into BED to view in ucsc genome browser.</p>\n\n<p>This seems like it should be a fairly common task, however, I am unable to find any scripts to convert my data.</p>\n
80	A: How To Organize A Pipeline Of Small Scripts Together?	2	2	0	1	1	4	0	0	0	0	t	0	0	2010-02-26 17:58:09.55-05	2010-02-26 17:58:09.55-05	f	f	79	79	<p>I don't have personal experience with this package but it is something that I plan to explore in the near future:</p>\n\n<p><strong><a href='http://code.google.com/p/ruffus/'>Ruffus </a></strong> a lightweight python module to run computational pipelines. </p>\n		\N	<p>I don't have personal experience with this package but it is something that I plan to explore in the near future:</p>\n\n<p><strong><a rel="nofollow" href="http://code.google.com/p/ruffus/">Ruffus </a></strong> a lightweight python module to run computational pipelines. </p>\n
81	A: How To Organize A Pipeline Of Small Scripts Together?	23	23	0	1	1	5	0	0	0	0	t	0	0	2010-02-26 18:03:52.94-05	2010-02-26 18:03:52.94-05	f	f	79	79	<p>My favorite way of defining pipelines is by writing Makefiles, about which you can find <a href='http://software-carpentry.org/build.html'>a very good introduction</a> in Software Carpentry for Bioinformatics: <a href='http://swc.scipy.org/lec/build.html'>http://swc.scipy.org/lec/build.html</a> .</p>\n\n<p>Although they have been originally developed for compiling programs, Makefiles allow to define which operations are needed to create each file, with a declarative syntax that it is a bit old-style but still does its job. Each Makefile is composed of a set of rules, which define operations needed to calculate a file and that can be combined together to make a pipeline. Other advantages of makefiles are conditional execution of tasks, so you can stop the execution of a pipeline and get back to it later, without having to repeat calculations. However, one of the big disadvantages of Makefiles is its old syntax... in particular, rules are identified by the names of the files that they create, and there is no such thing as 'titles' for rules, which make more tricky.</p>\n\n<p>I think one of the best solutions would be to use <a href='http://skam.sourceforge.net/skam-intro.html'>BioMake</a>, that allow to define tasks with titles that are not the name of the output files. To understand it better, look at <a href='http://skam.sourceforge.net/skam-intro.html'>this example</a>: you see that each rule has a title and a series of parameters like its output, inputs, comments, etc.</p>\n\n<p>Unfortunately, I can't make biomake to run on my computer, as it requires very old dependencies and it is written in a very difficult perl. I have tried many alternatives and I think that <a href='http://rake.rubyforge.org/files/doc/rational_rdoc.html'>rake</a> is the one that is more close to biomake, but unfortunately I don't understand ruby's syntax. </p>\n\n<p>So, I am still looking for a good alternative... Maybe one day I will have to time to re-write BioMake in python :-)</p>\n		\N	<p>My favorite way of defining pipelines is by writing Makefiles, about which you can find <a rel="nofollow" href="http://software-carpentry.org/build.html">a very good introduction</a> in Software Carpentry for Bioinformatics: <a rel="nofollow" href="http://swc.scipy.org/lec/build.html">http://swc.scipy.org/lec/build.html</a> .</p>\n\n<p>Although they have been originally developed for compiling programs, Makefiles allow to define which operations are needed to create each file, with a declarative syntax that it is a bit old-style but still does its job. Each Makefile is composed of a set of rules, which define operations needed to calculate a file and that can be combined together to make a pipeline. Other advantages of makefiles are conditional execution of tasks, so you can stop the execution of a pipeline and get back to it later, without having to repeat calculations. However, one of the big disadvantages of Makefiles is its old syntax... in particular, rules are identified by the names of the files that they create, and there is no such thing as 'titles' for rules, which make more tricky.</p>\n\n<p>I think one of the best solutions would be to use <a rel="nofollow" href="http://skam.sourceforge.net/skam-intro.html">BioMake</a>, that allow to define tasks with titles that are not the name of the output files. To understand it better, look at <a rel="nofollow" href="http://skam.sourceforge.net/skam-intro.html">this example</a>: you see that each rule has a title and a series of parameters like its output, inputs, comments, etc.</p>\n\n<p>Unfortunately, I can't make biomake to run on my computer, as it requires very old dependencies and it is written in a very difficult perl. I have tried many alternatives and I think that <a rel="nofollow" href="http://rake.rubyforge.org/files/doc/rational_rdoc.html">rake</a> is the one that is more close to biomake, but unfortunately I don't understand ruby's syntax. </p>\n\n<p>So, I am still looking for a good alternative... Maybe one day I will have to time to re-write BioMake in python :-)</p>\n
82	A: How To Organize A Pipeline Of Small Scripts Together?	47	47	0	1	1	3	0	0	0	0	t	0	0	2010-02-26 18:04:53.577-05	2010-02-26 18:04:53.577-05	f	f	79	79	<p>Since I work a lot with Python, I usually write a wrapper method that embeds the external script/program, i.e. calls it, parses its output and returns the desired information. The 'glueing' of several such methods then takes place within my Python code that calls all these wrappers. I guess that's a very common thing to do.</p>\n\n<p>Chris</p>\n		\N	<p>Since I work a lot with Python, I usually write a wrapper method that embeds the external script/program, i.e. calls it, parses its output and returns the desired information. The 'glueing' of several such methods then takes place within my Python code that calls all these wrappers. I guess that's a very common thing to do.</p>\n\n<p>Chris</p>\n
83	A: Where Can I Get The Secondary Structure Of A Protein?	7	7	0	1	1	4	0	0	0	0	t	0	0	2010-02-26 18:16:41.967-05	2010-02-26 18:16:41.967-05	f	f	48	48	<p>If you have the PDB file then you can use the standard tool called DSSP , it is supposed to be the gold standard for obtaining secondary structure. In case you just have sequence then I personally prefer PSIPRED , it takes evolutionary information into account to predict the secondary structure . According to CASP evaluation it is one of the best secondary structure predictor available.</p>\n		\N	<p>If you have the PDB file then you can use the standard tool called DSSP , it is supposed to be the gold standard for obtaining secondary structure. In case you just have sequence then I personally prefer PSIPRED , it takes evolutionary information into account to predict the secondary structure . According to CASP evaluation it is one of the best secondary structure predictor available.</p>\n
48	Where Can I Get The Secondary Structure Of A Protein?	23	23	0	1	0	2	157	3	0	0	t	28	10	2010-02-12 18:33:06.82-05	2010-02-27 10:58:45.557-05	f	f	48	48	<p>As in the title... I have a protein and I would like to know its secundary structure.\nI couldn't find it in uniprot, althought I tought they had annotations for it there.\nIn the end I have used a predictor (<a href='http://www.compbio.dundee.ac.uk/www-jpred'>jpred</a>) but there it should be a database somewhere.</p>\n	sequence,protein,structure	\N	<p>As in the title... I have a protein and I would like to know its secundary structure.\nI couldn't find it in uniprot, althought I tought they had annotations for it there.\nIn the end I have used a predictor (<a rel="nofollow" href="http://www.compbio.dundee.ac.uk/www-jpred">jpred</a>) but there it should be a database somewhere.</p>\n
84	A: How To Organize A Pipeline Of Small Scripts Together?	53	53	0	1	1	3	0	0	0	0	t	0	0	2010-02-26 21:16:31.97-05	2010-02-26 21:16:31.97-05	f	f	79	79	<p>My answer would be: don't bother. I've often found that much of the scripts I write are never used again after the initial use. Therefore spending time using a complex framework that considers dependency between scripts is a waste because the results might be negative and you never visit the analysis again. Even if you do end up using the script multiple times a simple hacky bash script might be more than enough to meet the requirements.</p>\n\n<p>There will however be the 1-2% of initial analyses that return a interesting result and therefore need to be expanded with more deeper investigation. I think this is the point to invest more time time in organising the project. For me I use Rake because it's simple and allows me to write in the language I'm used to (Ruby).</p>\n\n<p>Overall I think pragmatism is the important factor in computational biology. Just do enough to get the results you need and only invest more time when it's necessary. There's so many blind alleys in computational analysis of biological data it's not worth investing too much of your time until it's necessary.</p>\n		\N	<p>My answer would be: don't bother. I've often found that much of the scripts I write are never used again after the initial use. Therefore spending time using a complex framework that considers dependency between scripts is a waste because the results might be negative and you never visit the analysis again. Even if you do end up using the script multiple times a simple hacky bash script might be more than enough to meet the requirements.</p>\n\n<p>There will however be the 1-2% of initial analyses that return a interesting result and therefore need to be expanded with more deeper investigation. I think this is the point to invest more time time in organising the project. For me I use Rake because it's simple and allows me to write in the language I'm used to (Ruby).</p>\n\n<p>Overall I think pragmatism is the important factor in computational biology. Just do enough to get the results you need and only invest more time when it's necessary. There's so many blind alleys in computational analysis of biological data it's not worth investing too much of your time until it's necessary.</p>\n
85	A: What Is The Best Way To Share Scripts Between Members Of A Lab?	24	24	0	1	1	2	0	0	0	0	t	0	0	2010-02-26 21:27:32.303-05	2010-02-26 21:27:32.303-05	f	f	58	58	<p>My lab uses a network-attached storage unit which every Linux workstation mounts by NFS at startup. It was reasonably cheap -- a couple hundred dollars per TB. We also keep copies of public databases on there. We put data sets on there as we're working on them, and also put the more important scripts in a Mercurial repositiory.</p>\n\n<p>As Marcos and Istvan mentioned, a wiki integrated with your VCS would be wise, and Trac (trac.edgewall.org) is the obvious choice for that.</p>\n		\N	<p>My lab uses a network-attached storage unit which every Linux workstation mounts by NFS at startup. It was reasonably cheap -- a couple hundred dollars per TB. We also keep copies of public databases on there. We put data sets on there as we're working on them, and also put the more important scripts in a Mercurial repositiory.</p>\n\n<p>As Marcos and Istvan mentioned, a wiki integrated with your VCS would be wise, and Trac trac.edgewall.org) is the obvious choice for that.</p>\n
58	What Is The Best Way To Share Scripts Between Members Of A Lab?	23	23	0	1	0	1	205	6	0	0	t	49	12	2010-02-25 16:39:15.467-05	2010-02-25 16:39:15.467-05	f	f	58	58	<p>One of the most awful problems in my group is avoiding to rewrite scripts that have been already written by others. Since we have different projects and we work with different data, everybody ends up writing its own scripts in his favorite programming language, and it is very frequent to waste an afternoon on writing a new program and then discover that your workmate already had a script to do that.</p>\n\n<p>Apart from the most logical answer ("talk with your workmates"), we are thinking about having a common place to store our best scripts, and if possible work together on them.\nIt would be similar to an image library like this: <a href='http://matplotlib.sourceforge.net/gallery.html'>http://matplotlib.sourceforge.net/gallery.html</a> , where to put the script and an example of its output (most of our scripts produce graphs), and if possible integrated with Git. </p>\n\n<p>Do you have any idea? How to you cope with the problem in your lab?</p>\n	general,subjective	\N	<p>One of the most awful problems in my group is avoiding to rewrite scripts that have been already written by others. Since we have different projects and we work with different data, everybody ends up writing its own scripts in his favorite programming language, and it is very frequent to waste an afternoon on writing a new program and then discover that your workmate already had a script to do that.</p>\n\n<p>Apart from the most logical answer ("talk with your workmates"), we are thinking about having a common place to store our best scripts, and if possible work together on them.\nIt would be similar to an image library like this: <a rel="nofollow" href="http://matplotlib.sourceforge.net/gallery.html">http://matplotlib.sourceforge.net/gallery.html</a> , where to put the script and an example of its output (most of our scripts produce graphs), and if possible integrated with Git. </p>\n\n<p>Do you have any idea? How to you cope with the problem in your lab?</p>\n
87	A: Using Hdf5 To Store  Bio-Data	55	55	0	1	1	2	0	0	0	0	t	0	0	2010-02-27 22:00:56.14-05	2010-02-27 22:00:56.14-05	f	f	69	69	<p>There is also a Perl binding to HDF5: PDL::IO::HDF5</p>\n\n<p><a href='http://search.cpan.org/~cerney/PDL-IO-HDF5-0.5/'>http://search.cpan.org/~cerney/PDL-IO-HDF5-0.5/</a>\nThis requires the Perl Data Language (PDL) package. The way, data-structures can be handled, sub-ranges of data can be defined  an data can be manipulated is actually very elegant in PDL such that computational code can profit from PDLs vectorized style of writing expressions.</p>\n\n<p>The same is true for R and the hdf5 package: <a href='http://cran.r-project.org/web/packages/hdf5/index.html'>http://cran.r-project.org/web/packages/hdf5/index.html</a></p>\n\n<p>Code examples are in the package documentations of both, the R-hdf5 package documentation is quite little though.</p>\n\n<p>Both of these language bindings might be a very efficient way to read and write HDF5 files.</p>\n\n<p>There are also APIs in Fortran, Java, Python, Matlab, C, or C++. So it might make sense to select the language and define the type of data you wish to store first. </p>\n		\N	<p>There is also a Perl binding to HDF5: PDL::IO::HDF5</p>\n\n<p><a rel="nofollow" href="http://search.cpan.org/~cerney/PDL-IO-HDF5-0.5/">http://search.cpan.org/~cerney/PDL-IO-HDF5-0.5/</a>\nThis requires the Perl Data Language (PDL) package. The way, data-structures can be handled, sub-ranges of data can be defined  an data can be manipulated is actually very elegant in PDL such that computational code can profit from PDLs vectorized style of writing expressions.</p>\n\n<p>The same is true for R and the hdf5 package: <a rel="nofollow" href="http://cran.r-project.org/web/packages/hdf5/index.html">http://cran.r-project.org/web/packages/hdf5/index.html</a></p>\n\n<p>Code examples are in the package documentations of both, the R-hdf5 package documentation is quite little though.</p>\n\n<p>Both of these language bindings might be a very efficient way to read and write HDF5 files.</p>\n\n<p>There are also APIs in Fortran, Java, Python, Matlab, C, or C++. So it might make sense to select the language and define the type of data you wish to store first. </p>\n
69	Using Hdf5 To Store  Bio-Data	30	30	0	1	0	8	314	5	0	0	t	35	20	2010-02-26 13:50:17.577-05	2010-03-03 14:38:58.783-05	f	f	69	69	<p>Hi all,\nhas anobody ever used the <a href='http://www.hdfgroup.org/HDF5/'>HDF5 API</a> to store some biological data (genotypes...). I know about this <a href='http://www.geospiza.com/finchtalk/2008/03/genotyping-with-hdf.html'>kind of reference</a> (BioHDF...)  but I'm looking for some <strong>source code</strong> I could browse to understand how I can access data faster.</p>\n\n<p>Pierre</p>\n\n<p>PS: hum, I'm a new user. I'm not allowed to add the following tags: storage database hdf5 source code </p>\n	hdf,biohdf,hdf,storage	\N	<p>Hi all,\nhas anobody ever used the <a rel="nofollow" href="http://www.hdfgroup.org/HDF5/">HDF5 API</a> to store some biological data (genotypes...). I know about this <a rel="nofollow" href="http://www.geospiza.com/finchtalk/2008/03/genotyping-with-hdf.html">kind of reference</a> (BioHDF...)  but I'm looking for some <strong>source code</strong> I could browse to understand how I can access data faster.</p>\n\n<p>Pierre</p>\n\n<p>PS: hum, I'm a new user. I'm not allowed to add the following tags: storage database hdf5 source code </p>\n
89	A: Agile Programming For Bioinformaticians - Any Suggestions?	2	2	0	1	1	0	0	0	0	0	t	0	0	2010-03-01 15:06:55.973-05	2010-03-01 15:06:55.973-05	f	f	88	88	<p>I think the approach is unsuited for individuals who are not comfortable with programming in general. There is a long way to go until someone becomes confident in their abilities. Before that this approach is not only ineffective, it might be even be detrimental.</p>\n\n<p>Instead what helps most is transparency. Everyone needs to write code in a source code repository that can be viewed, commented and verified. People should become familiar with testing, code coverage, and continuous integration. </p>\n\n<p>Something to read: <a href='http://en.wikipedia.org/wiki/The_Mythical_Man-Month'>Mythical Man Month</a>.</p>\n		\N	<p>I think the approach is unsuited for individuals who are not comfortable with programming in general. There is a long way to go until someone becomes confident in their abilities. Before that this approach is not only ineffective, it might be even be detrimental.</p>\n\n<p>Instead what helps most is transparency. Everyone needs to write code in a source code repository that can be viewed, commented and verified. People should become familiar with testing, code coverage, and continuous integration. </p>\n\n<p>Something to read: <a rel="nofollow" href="http://en.wikipedia.org/wiki/The_Mythical_Man-Month">Mythical Man Month</a>.</p>\n
91	A: Agile Programming For Bioinformaticians - Any Suggestions?	39	39	0	1	1	2	0	0	0	0	t	0	0	2010-03-01 15:41:28.687-05	2010-03-01 15:41:28.687-05	f	f	88	88	<p>I would suggest to have a look at <a href='http://en.wikipedia.org/wiki/Scrum_(development)'>Scrum</a>, too. Certain parts would help not only bioinformations. For example estimating the time expenditure of tasks and the resulting burn down charts can be really helpful to see if something is stuck especially when working together on bigger projects.The daily scrum reports helps to meditate why who is doing what and offers a platform to discuss problems.</p>\n		\N	<p>I would suggest to have a look at <a rel="nofollow" href="http://en.wikipedia.org/wiki/Scrum_(development)">Scrum</a>, too. Certain parts would help not only bioinformations. For example estimating the time expenditure of tasks and the resulting burn down charts can be really helpful to see if something is stuck especially when working together on bigger projects.The daily scrum reports helps to meditate why who is doing what and offers a platform to discuss problems.</p>\n
88	Agile Programming For Bioinformaticians - Any Suggestions?	23	23	0	1	0	1	67	2	0	0	t	21	3	2010-03-01 14:51:12.3-05	2010-03-02 18:44:16.057-05	f	f	88	88	<p>I am planning to prepare a talk for my workmates, to introduce them the basics of some agile programming methodology, which I think could give us good ideas to improve our working as a team.</p>\n\n<p>My idea was to take inspiration from <a href='http://www.extremeprogramming.org/rules/'>extreme programming</a> and explain the rules I like the most: use of <a href='http://www.extremeprogramming.org/example/crcsim.html'>A7 cards to write tasks</a>, <a href='http://www.extremeprogramming.org/rules/planninggame.html'>release planning</a> every 3 week, stand-up meeting every day, <a href='http://www.extremeprogramming.org/rules/movepeople.html'>Move people around</a>, <a href='http://www.extremeprogramming.org/rules/testfirst.html'>unit tests first</a>, <a href='http://www.extremeprogramming.org/rules/pair.html'>pair programming</a> (at least introduce the concept), <a href='http://www.extremeprogramming.org/rules/collective.html'>collective ownership</a>.</p>\n\n<p>It is difficult for me to explain these rules as I don't have much direct experience with, apart for few exceptions, and it is even more difficult because I will have to explain them to people who are not comfortable with programming and with software engineering in general.\nHowever, I also think that I have to prepare this talk early and it will be much more difficult if I wait too much.</p>\n\n<p>Do you have any experience with what I am talking about? Do you have any advice to give me, or can you recommend me a book or a practice that I could explain along with extreme programming?</p>\n	general,agile,good,team	\N	<p>I am planning to prepare a talk for my workmates, to introduce them the basics of some agile programming methodology, which I think could give us good ideas to improve our working as a team.</p>\n\n<p>My idea was to take inspiration from <a rel="nofollow" href="http://www.extremeprogramming.org/rules/">extreme programming</a> and explain the rules I like the most: use of <a rel="nofollow" href="http://www.extremeprogramming.org/example/crcsim.html">A7 cards to write tasks</a>, <a rel="nofollow" href="http://www.extremeprogramming.org/rules/planninggame.html">release planning</a> every 3 week, stand-up meeting every day, <a rel="nofollow" href="http://www.extremeprogramming.org/rules/movepeople.html">Move people around</a>, <a rel="nofollow" href="http://www.extremeprogramming.org/rules/testfirst.html">unit tests first</a>, <a rel="nofollow" href="http://www.extremeprogramming.org/rules/pair.html">pair programming</a> (at least introduce the concept), <a rel="nofollow" href="http://www.extremeprogramming.org/rules/collective.html">collective ownership</a>.</p>\n\n<p>It is difficult for me to explain these rules as I don't have much direct experience with, apart for few exceptions, and it is even more difficult because I will have to explain them to people who are not comfortable with programming and with software engineering in general.\nHowever, I also think that I have to prepare this talk early and it will be much more difficult if I wait too much.</p>\n\n<p>Do you have any experience with what I am talking about? Do you have any advice to give me, or can you recommend me a book or a practice that I could explain along with extreme programming?</p>\n
92	Computing The Reverse And Complement Of A Sequence With Pygr	10	2	0	2	0	1	72	0	0	0	t	7	1	2010-03-01 15:48:25.83-05	2010-03-08 14:51:12.053-05	f	f	92	92	<p>Computing the reverse complement with the <a href='http://code.google.com/p/pygr/wiki/PygrDocumentation'>Pygr</a> bioinformatics framework:</p>\n\n<pre><code>#\n# Reverse complement example with pygr\n#\n\nfrom pygr.sequence import Sequence\n\n# needs a separate function to reverse strings\ndef rev(it):\n    "Reverses an interable and returns it as a string"\n    return ''.join(reversed(it))\n\n# original sequence as as string\nseq = 'ATGGCCATTGTAATGGGCCGCTGAAAGGGTGCCCGATAG'\n\n# create a Sequence class  instance named bobo\ndna = Sequence(seq,'bobo')\n\n# sequence class' type and content\nprint type(dna)\nprint dna\n\n# the -operator reverse complements the DNA, returns a new sequence\nprint -dna\n\n# to reverse the DNA, reverse the input data\nrdna = Sequence( rev(seq),'bobo')\nprint rdna\n\n# to complement the DNA reverse complement, then reverse again\ncseq = rev(str(-dna))\ncdna = Sequence(cseq,'bobo')\n\nprint cdna\n</code></pre>\n\n<p>Produces the output:</p>\n\n<pre><code>&lt;class 'pygr.sequence.Sequence'&gt;\nATGGCCATTGTAATGGGCCGCTGAAAGGGTGCCCGATAG\nCTATCGGGCACCCTTTCAGCGGCCCATTACAATGGCCAT\nGATAGCCCGTGGGAAAGTCGCCGGGTAATGTTACCGGTA\nTACCGGTAACATTACCCGGCGACTTTCCCACGGGCTATC\n</code></pre>\n	python,pygr,use,sequence	\N	<p>Computing the reverse complement with the <a rel="nofollow" href="http://code.google.com/p/pygr/wiki/PygrDocumentation">Pygr</a> bioinformatics framework:</p>\n\n<pre><code>#\n# Reverse complement example with pygr\n#\n\nfrom pygr.sequence import Sequence\n\n# needs a separate function to reverse strings\ndef rev(it):\n    "Reverses an interable and returns it as a string"\n    return ''.join(reversed(it))\n\n# original sequence as as string\nseq = 'ATGGCCATTGTAATGGGCCGCTGAAAGGGTGCCCGATAG'\n\n# create a Sequence class  instance named bobo\ndna = Sequence(seq,'bobo')\n\n# sequence class' type and content\nprint type(dna)\nprint dna\n\n# the -operator reverse complements the DNA, returns a new sequence\nprint -dna\n\n# to reverse the DNA, reverse the input data\nrdna = Sequence( rev(seq),'bobo')\nprint rdna\n\n# to complement the DNA reverse complement, then reverse again\ncseq = rev(str(-dna))\ncdna = Sequence(cseq,'bobo')\n\nprint cdna\n</code></pre>\n\n<p>Produces the output:</p>\n\n<pre><code>&lt;class 'pygr.sequence.Sequence'&gt;\nATGGCCATTGTAATGGGCCGCTGAAAGGGTGCCCGATAG\nCTATCGGGCACCCTTTCAGCGGCCCATTACAATGGCCAT\nGATAGCCCGTGGGAAAGTCGCCGGGTAATGTTACCGGTA\nTACCGGTAACATTACCCGGCGACTTTCCCACGGGCTATC\n</code></pre>\n
93	A: Recommend Easy To Use Microarray Clustering Software	45	45	0	1	1	1	0	0	0	0	t	0	0	2010-03-01 15:51:52.19-05	2010-03-01 15:51:52.19-05	f	f	5	5	<p>Possibly related:\n<a href='http://mmc.gnets.ncsu.edu/'>http://mmc.gnets.ncsu.edu/</a></p>\n		\N	<p>Possibly related:\n<a rel="nofollow" href="http://mmc.gnets.ncsu.edu/">http://mmc.gnets.ncsu.edu/</a></p>\n
5	Recommend Easy To Use Microarray Clustering Software	2	2	0	1	0	1	154	3	0	0	t	21	5	2009-09-30 18:44:22.647-04	2009-10-05 18:10:10.997-04	f	f	5	5	<p>Feel free to post your favorite clustering tool.</p>\n	microarray,clustering	\N	<p>Feel free to post your favorite clustering tool.</p>\n
94	A: Computing The Reverse And Complement Of A Sequence With Biopython	23	23	0	1	1	2	0	0	0	0	t	0	0	2010-03-01 17:07:15.283-05	2010-03-01 17:07:15.283-05	f	f	90	90	<p>Wouldn't it better to have a single question titled 'How to compute the reverse complement with python' and put all the examples as different answers? Otherwise it seems a bit confusing..</p>\n		\N	<p>Wouldn't it better to have a single question titled 'How to compute the reverse complement with python' and put all the examples as different answers? Otherwise it seems a bit confusing..</p>\n
95	A: How To Organize A Pipeline Of Small Scripts Together?	24	24	0	1	1	3	0	0	0	0	t	0	0	2010-03-01 17:32:26.107-05	2010-03-01 17:32:26.107-05	f	f	79	79	<p>The most important thing for me has been keeping a README file at the top of each project directory, where I write down not just <em>how</em> to run the scripts, but <em>why</em> I wrote them in the first place -- coming back to a project after a several-month lull, it's remarkable difficult to figure out what all the half-finished results mean without detailed notes.</p>\n\n<p>That said:</p>\n\n<ul>\n<li><code>make</code> is pretty handy for simple pipelines that need to be re-run a lot</li>\n<li>I'm also intrigued by <a href='http://code.google.com/p/waf/'>waf</a> and <a href='http://www.scons.org/'>scons</a>, since I use Python a lot</li>\n<li>If a pipeline only takes a couple of minutes to run, and you only re-run it every few days, coercing it into a build system doesn't really save time overall for that project</li>\n<li>But once you're used to working with a build system, the threshold where it pays off to use it on a new project drops dramatically</li>\n</ul>\n		\N	<p>The most important thing for me has been keeping a README file at the top of each project directory, where I write down not just <em>how</em> to run the scripts, but <em>why</em> I wrote them in the first place -- coming back to a project after a several-month lull, it's remarkable difficult to figure out what all the half-finished results mean without detailed notes.</p>\n\n<p>That said:</p>\n\n<ul>\n<li><code>make</code> is pretty handy for simple pipelines that need to be re-run a lot</li>\n<li>I'm also intrigued by <a rel="nofollow" href="http://code.google.com/p/waf/">waf</a> and <a rel="nofollow" href="http://www.scons.org/">scons</a>, since I use Python a lot</li>\n<li>If a pipeline only takes a couple of minutes to run, and you only re-run it every few days, coercing it into a build system doesn't really save time overall for that project</li>\n<li>But once you're used to working with a build system, the threshold where it pays off to use it on a new project drops dramatically</li>\n</ul>\n
79	How To Organize A Pipeline Of Small Scripts Together?	23	23	0	1	0	4	276	5	0	2	t	35	23	2010-02-26 17:49:35.15-05	2010-03-02 18:45:01.483-05	f	f	79	79	<p>In bioinformatics it is very common to end up with a lot of small scripts, each one with a different scope - plotting a chart, converting a file into another format, execute small operations - so it is very important to have a good way to clue them together, to define which should be executed before the others and so on.</p>\n\n<p>How do you deal with the problem? Do you use makefiles, taverna workflows, batch scripts, or any other solution?</p>\n	general,make,pipeline,organization	\N	<p>In bioinformatics it is very common to end up with a lot of small scripts, each one with a different scope - plotting a chart, converting a file into another format, execute small operations - so it is very important to have a good way to clue them together, to define which should be executed before the others and so on.</p>\n\n<p>How do you deal with the problem? Do you use makefiles, taverna workflows, batch scripts, or any other solution?</p>\n
96	A: Computing The Reverse And Complement Of A Sequence With Biopython	24	24	0	1	1	2	0	0	0	0	t	0	0	2010-03-01 17:52:22.51-05	2010-03-01 17:52:22.51-05	f	f	90	90	<p>The Bio.Seq module provides two easy ways to get the complement and reverse complement from a sequence:</p>\n\n<ul>\n<li>If you have a string, use the functions <code>complement(dna)</code> and <code>reverse_complement(dna)</code></li>\n<li>If you have a Seq object, use its methods with the same names: <code>dna.complement()</code> and <code>dna.reverse_complement</code></li>\n</ul>\n\n<p>To reverse a sequence, there is a function in the <code>Bio.SeqUtils</code> module called <code>reverse</code> which does what you would expect.</p>\n\n<hr />\n\n<p>(Sorry for going meta, but I don't have commenting privileges yet. This can be deleted if the original post is edited.)</p>\n\n<p>According to <a href='http://meta.stackoverflow.com/questions/17845/etiquette-for-answering-your-own-question'>Meta Stack Overflow</a>, if you want to share the answer to a difficult question that's poorly documented elsewhere online, you should post the question as a genuine one, and then submit your own answer separately. In theory, someone else may have an answer that's better than yours, and this allows it to be voted to the top properly.</p>\n		\N	<p>The Bio.Seq module provides two easy ways to get the complement and reverse complement from a sequence:</p>\n\n<ul>\n<li>If you have a string, use the functions <code>complement(dna)</code> and <code>reverse_complement(dna)</code></li>\n<li>If you have a Seq object, use its methods with the same names: <code>dna.complement()</code> and <code>dna.reverse_complement</code></li>\n</ul>\n\n<p>To reverse a sequence, there is a function in the <code>Bio.SeqUtils</code> module called <code>reverse</code> which does what you would expect.</p>\n\n<hr>\n\n<p>(Sorry for going meta, but I don't have commenting privileges yet. This can be deleted if the original post is edited.)</p>\n\n<p>According to <a rel="nofollow" href="http://meta.stackoverflow.com/questions/17845/etiquette-for-answering-your-own-question">Meta Stack Overflow</a>, if you want to share the answer to a difficult question that's poorly documented elsewhere online, you should post the question as a genuine one, and then submit your own answer separately. In theory, someone else may have an answer that's better than yours, and this allows it to be voted to the top properly.</p>\n
90	Computing The Reverse And Complement Of A Sequence With Biopython	10	10	0	1	0	1	112	2	0	0	t	21	5	2010-03-01 15:26:09.937-05	2010-03-01 17:11:52.887-05	f	f	90	90	<p>An example that computes the reverse complement of a sequence with <a href='http://biopython.org/wiki/Main_Page'>BioPython</a></p>\n\n<pre><code>#\n# Reverse complement example with BioPython\n#\n\nfrom Bio.Seq import Seq\n\n# a separate function to reverse strings (or other iterables)\ndef rev(it):\n    "Reverses an interable and returns it as a string"\n    return ''.join(reversed(it))\n\n# create a Seq class instance\ndna = Seq("ATGGCCATTGTAATGGGCCGCTGAAAGGGTGCCCGATAG")\n\n# original DNA\nprint type(dna)\nprint dna\n\n# reverse complement DNA, returns a new sequence\nprint dna.reverse_complement()\n\n# currently there is no direct way to just reverse a sequence\n# we need to do a little extra work\n\nrseq = rev(str(dna))\nrdna = Seq(rseq)\n\n# reversed sequence\nprint rdna\n\n# to complement DNA, returns a new sequence\nprint dna.complement()\n</code></pre>\n\n<p>Produces the following output:</p>\n\n<pre><code>&lt;class 'Bio.Seq.Seq'&gt;\nATGGCCATTGTAATGGGCCGCTGAAAGGGTGCCCGATAG\nCTATCGGGCACCCTTTCAGCGGCCCATTACAATGGCCAT\nGATAGCCCGTGGGAAAGTCGCCGGGTAATGTTACCGGTA\nTACCGGTAACATTACCCGGCGACTTTCCCACGGGCTATC\n</code></pre>\n	sequence,biopython,python	\N	<p>An example that computes the reverse complement of a sequence with <a rel="nofollow" href="http://biopython.org/wiki/Main_Page">BioPython</a></p>\n\n<pre><code>#\n# Reverse complement example with BioPython\n#\n\nfrom Bio.Seq import Seq\n\n# a separate function to reverse strings (or other iterables)\ndef rev(it):\n    "Reverses an interable and returns it as a string"\n    return ''.join(reversed(it))\n\n# create a Seq class instance\ndna = Seq("ATGGCCATTGTAATGGGCCGCTGAAAGGGTGCCCGATAG")\n\n# original DNA\nprint type(dna)\nprint dna\n\n# reverse complement DNA, returns a new sequence\nprint dna.reverse_complement()\n\n# currently there is no direct way to just reverse a sequence\n# we need to do a little extra work\n\nrseq = rev(str(dna))\nrdna = Seq(rseq)\n\n# reversed sequence\nprint rdna\n\n# to complement DNA, returns a new sequence\nprint dna.complement()\n</code></pre>\n\n<p>Produces the following output:</p>\n\n<pre><code>&lt;class 'Bio.Seq.Seq'&gt;\nATGGCCATTGTAATGGGCCGCTGAAAGGGTGCCCGATAG\nCTATCGGGCACCCTTTCAGCGGCCCATTACAATGGCCAT\nGATAGCCCGTGGGAAAGTCGCCGGGTAATGTTACCGGTA\nTACCGGTAACATTACCCGGCGACTTTCCCACGGGCTATC\n</code></pre>\n
98	A: Gene Id Conversion Tool	55	55	0	1	1	3	0	0	0	0	t	0	0	2010-03-01 20:51:25.98-05	2010-03-01 20:51:25.98-05	f	f	22	22	<p>BioMart has already been mentioned. It can do much more than ID conversion but it is very useful for conversion purposes, it is regularly updated and you can select different genome builds and all kinds of genomic features. It seems to me that you wish to retrieve GeneIDs linked to Affymetrix IDs. To select these attributes in BioMart: go to the <a href='http://www.biomart.org/biomart/martview'>Martview</a> page to start a new BioMart query.</p>\n\n<p>Select attributes on the attribute page: The Ensembl GeneIDs and Transcript IDs are default. Ensembl GeneID and Affy IDs are under the "External" tab. Select your chip there.\nTo limit to those genes which are on the chip, use the Filters->Gene menue. You can limit the genes to those present on various platforms or your favourite set.</p>\n\n<p>There is an URL button in biomart that allows to retrieve a URL for your query and to pass it on to others. Try this example:</p>\n\n<p><a href='http://www.biomart.org/biomart/martview?VIRTUALSCHEMANAME=default&amp;ATTRIBUTES=hsapiens_gene_ensembl.default.feature_page.ensembl_gene_id|hsapiens_gene_ensembl.default.feature_page.ensembl_transcript_id|hsapiens_gene_ensembl.default.feature_page.embl|hsapiens_gene_ensembl.default.feature_page.affy_hg_u133a&amp;FILTERS=hsapiens_gene_ensembl.default.filters.with_affy_hg_u133a.only&amp;VISIBLEPANEL=resultspanel'>BioMart URL</a> URL, that should be a good starting point.</p>\n\n<p>If you are interested in KEGG identifiers (Pathways, Genes), EC-numbers, etc. the  </p>\n\n<p><a href='http://www.genome.jp/kegg/kegg3.html'>KEGG Identifier page</a> could be handy, because the KEGG ids are not in BioMart as far as I know.</p>\n		\N	<p>BioMart has already been mentioned. It can do much more than ID conversion but it is very useful for conversion purposes, it is regularly updated and you can select different genome builds and all kinds of genomic features. It seems to me that you wish to retrieve GeneIDs linked to Affymetrix IDs. To select these attributes in BioMart: go to the <a rel="nofollow" href="http://www.biomart.org/biomart/martview">Martview</a> page to start a new BioMart query.</p>\n\n<p>Select attributes on the attribute page: The Ensembl GeneIDs and Transcript IDs are default. Ensembl GeneID and Affy IDs are under the "External" tab. Select your chip there.\nTo limit to those genes which are on the chip, use the Filters-&gt;Gene menue. You can limit the genes to those present on various platforms or your favourite set.</p>\n\n<p>There is an URL button in biomart that allows to retrieve a URL for your query and to pass it on to others. Try this example:</p>\n\n<p><a rel="nofollow" href="http://www.biomart.org/biomart/martview?VIRTUALSCHEMANAME=default&amp;ATTRIBUTES=hsapiens_gene_ensembl.default.feature_page.ensembl_gene_id|hsapiens_gene_ensembl.default.feature_page.ensembl_transcript_id|hsapiens_gene_ensembl.default.feature_page.embl|hsapiens_gene_ensembl.default.feature_page.affy_hg_u133a&amp;FILTERS=hsapiens_gene_ensembl.default.filters.with_affy_hg_u133a.only&amp;VISIBLEPANEL=resultspanel">BioMart URL</a> URL, that should be a good starting point.</p>\n\n<p>If you are interested in KEGG identifiers (Pathways, Genes), EC-numbers, etc. the  </p>\n\n<p><a rel="nofollow" href="http://www.genome.jp/kegg/kegg3.html">KEGG Identifier page</a> could be handy, because the KEGG ids are not in BioMart as far as I know.</p>\n
22	Gene Id Conversion Tool	16	59	0	1	0	4	493	5	0	2	t	42	13	2009-10-23 19:42:24.427-04	2010-03-03 15:03:06.16-05	f	f	22	22	<p>Hey,</p>\n\n<p>I was using DAVID (<a href='http://david.abcc.ncifcrf.gov/conversion.jsp'>http://david.abcc.ncifcrf.gov/conversion.jsp</a>) to do the gene ID conversion, e.g.conversion between Agilent ID, Genebank accession id and Entrez gene ID, but I found the DAVID database is not updated. Does anyone know a better updataed conversion tool to do this job? Thanks! </p>\n	geneid,accession,mapping,conversion	\N	<p>Hey,</p>\n\n<p>I was using DAVID (<a rel="nofollow" href="http://david.abcc.ncifcrf.gov/conversion.jsp">http://david.abcc.ncifcrf.gov/conversion.jsp</a>) to do the gene ID conversion, e.g.conversion between Agilent ID, Genebank accession id and Entrez gene ID, but I found the DAVID database is not updated. Does anyone know a better updataed conversion tool to do this job? Thanks! </p>\n
100	A: Fast Interval Intersection Methodologies	2	2	0	1	1	2	0	0	0	0	t	0	0	2010-03-01 21:06:18.193-05	2010-03-01 21:13:11.68-05	f	f	99	99	<p>This code example generates 10,000 intervals then queries them for overlapping regions. <strong>Requires only the presence of Python.</strong></p>\n\n<p>The code below requires the either the installation of the <a href='http://bitbucket.org/james_taylor/bx-python/wiki/Home'>bx python</a> package or alternatively you may just download the <a href='http://bitbucket.org/james_taylor/bx-python/raw/ebf9a4b352d3/lib/bx/intervals/operations/quicksect.py'>quicksect.py</a> module and place it next to the script itself:</p>\n\n<pre><code>from random import randint, seed\n\n# if you can install bx python then uncomment the line below\n#\n# from bx.intervals.operations.quicksect import IntervalNode\n\n# otherwise just download the quickset module as shown above \n# and place it in next to your program\n#\nfrom quicksect import IntervalNode\n\n# the span of the generated intervals\nSPAN = 10\n\n# the size of the genome\nSIZE = 5*10**4\n\n# the number of intervals\nN = 10**4\n\ndef generate(x):\n    "Generates random interval over a size and span"\n    lo = randint(10000, SIZE)\n    hi = lo + randint(1, SPAN)\n    return (lo, hi)\n\ndef find(start, end, tree):\n    "Returns a list with the overlapping intervals"\n    out = []\n    tree.intersect( start, end, lambda x: out.append(x) )\n    return [ (x.start, x.end) for x in out ]\n\n# use this to force both examples to generate the same data\nseed(10)\n\n# generate 10 thousand random intervals\ndata = map(generate, xrange(N))\n\n# generate the intervals to query over\nquery = map(generate, xrange(10))\n\n# start the root at the first element\nstart, end = data[0]\ntree = IntervalNode( start, end )\n\n# build an interval tree from the rest of the data\nfor start, end in data[1:]:\n    tree = tree.insert( start, end )\n\nfor start, end in query:\n    overlap = find(start, end , tree)\n    print '(%s, %s) -&gt; %s' % (start, end, overlap)\n</code></pre>\n\n<p>Produces the output:</p>\n\n<pre><code>(41901, 41903) -&gt; [(41894, 41902)]\n(36981, 36987) -&gt; [(36981, 36984), (36973, 36982), (36978, 36987)]\n(36338, 36339) -&gt; [(36337, 36347)]\n(32741, 32748) -&gt; [(32738, 32742)]\n(49864, 49872) -&gt; [(49859, 49865)]\n(21475, 21477) -&gt; []\n(29425, 29428) -&gt; [(29418, 29426), (29419, 29426)]\n(29590, 29599) -&gt; [(29586, 29595), (29596, 29598)]\n(12804, 12811) -&gt; [(12806, 12811), (12799, 12806), (12809, 12819)]\n(30339, 30343) -&gt; [(30336, 30346), (30335, 30345), (30340, 30341)]\n</code></pre>\n		\N	<p>This code example generates 10,000 intervals then queries them for overlapping regions. <strong>Requires only the presence of Python.</strong></p>\n\n<p>The code below requires the either the installation of the <a rel="nofollow" href="http://bitbucket.org/james_taylor/bx-python/wiki/Home">bx python</a> package or alternatively you may just download the <a rel="nofollow" href="http://bitbucket.org/james_taylor/bx-python/raw/ebf9a4b352d3/lib/bx/intervals/operations/quicksect.py">quicksect.py</a> module and place it next to the script itself:</p>\n\n<pre><code>from random import randint, seed\n\n# if you can install bx python then uncomment the line below\n#\n# from bx.intervals.operations.quicksect import IntervalNode\n\n# otherwise just download the quickset module as shown above \n# and place it in next to your program\n#\nfrom quicksect import IntervalNode\n\n# the span of the generated intervals\nSPAN = 10\n\n# the size of the genome\nSIZE = 5*10**4\n\n# the number of intervals\nN = 10**4\n\ndef generate(x):\n    "Generates random interval over a size and span"\n    lo = randint(10000, SIZE)\n    hi = lo + randint(1, SPAN)\n    return (lo, hi)\n\ndef find(start, end, tree):\n    "Returns a list with the overlapping intervals"\n    out = []\n    tree.intersect( start, end, lambda x: out.append(x) )\n    return [ (x.start, x.end) for x in out ]\n\n# use this to force both examples to generate the same data\nseed(10)\n\n# generate 10 thousand random intervals\ndata = map(generate, xrange(N))\n\n# generate the intervals to query over\nquery = map(generate, xrange(10))\n\n# start the root at the first element\nstart, end = data[0]\ntree = IntervalNode( start, end )\n\n# build an interval tree from the rest of the data\nfor start, end in data[1:]:\n    tree = tree.insert( start, end )\n\nfor start, end in query:\n    overlap = find(start, end , tree)\n    print '(%s, %s) -&gt; %s' % (start, end, overlap)\n</code></pre>\n\n<p>Produces the output:</p>\n\n<pre><code>(41901, 41903) -&gt; [(41894, 41902)]\n(36981, 36987) -&gt; [(36981, 36984), (36973, 36982), (36978, 36987)]\n(36338, 36339) -&gt; [(36337, 36347)]\n(32741, 32748) -&gt; [(32738, 32742)]\n(49864, 49872) -&gt; [(49859, 49865)]\n(21475, 21477) -&gt; []\n(29425, 29428) -&gt; [(29418, 29426), (29419, 29426)]\n(29590, 29599) -&gt; [(29586, 29595), (29596, 29598)]\n(12804, 12811) -&gt; [(12806, 12811), (12799, 12806), (12809, 12819)]\n(30339, 30343) -&gt; [(30336, 30346), (30335, 30345), (30340, 30341)]\n</code></pre>\n
99	Fast Interval Intersection Methodologies	10	23	0	1	0	2	145	1	0	1	t	14	4	2010-03-01 21:01:20.047-05	2010-03-02 18:42:32.173-05	f	f	99	99	<p>Most genomic annotations are specified as intervals along the genome. </p>\n\n<ul>\n<li><a href='http://books.google.com/books?id=NLngYyWFl_YC&amp;lpg=PA311&amp;ots=BwTtEE-jJ9&amp;dq=cormen%20interval%20tree&amp;pg=PA311#v=onepage&amp;q=&amp;f=false'>Interval trees</a> have been known to provide an efficient datastructure that allows for very fast overlap querying. </li>\n<li><a href='http://bioinformatics.oxfordjournals.org/cgi/content/abstract/btl647v1'>Nested Containment Lists</a> have been proposed as an even faster alternative </li>\n</ul>\n\n<p>Provide code examples in your programming language that demonstrate the use of fast interval querying.</p>\n	interval,query,use,genomics	\N	<p>Most genomic annotations are specified as intervals along the genome. </p>\n\n<ul>\n<li><a rel="nofollow" href="http://books.google.com/books?id=NLngYyWFl_YC&amp;lpg=PA311&amp;ots=BwTtEE-jJ9&amp;dq=cormen%20interval%20tree&amp;pg=PA311#v=onepage&amp;q=&amp;f=false">Interval trees</a> have been known to provide an efficient datastructure that allows for very fast overlap querying. </li>\n<li><a rel="nofollow" href="http://bioinformatics.oxfordjournals.org/cgi/content/abstract/btl647v1">Nested Containment Lists</a> have been proposed as an even faster alternative </li>\n</ul>\n\n<p>Provide code examples in your programming language that demonstrate the use of fast interval querying.</p>\n
101	How to find motifs with Galaxy?	1	1	0	1	0	0	1	0	0	0	t	4	0	2014-05-09 10:39:20.047-04	2014-05-09 10:39:20.047-04	f	f	101	101	I have a few hundred yeast sequences (20-80bp long) and I want to find common motifs (conserved bases at certain indices) in them. I am using a Mac	galaxy,motif	\N	I have a few hundred yeast sequences (20-80bp long) and I want to find common motifs (conserved bases at certain indices) in them. I am using a Mac
\.


--
-- Name: posts_post_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('posts_post_id_seq', 101, true);


--
-- Data for Name: posts_post_tag_set; Type: TABLE DATA; Schema: public; Owner: -
--

COPY posts_post_tag_set (id, post_id, tag_id) FROM stdin;
1	1	1
2	2	3
3	2	2
4	2	4
5	4	5
6	4	6
7	5	8
8	5	7
9	6	9
10	10	10
11	13	11
12	13	13
13	13	12
14	20	15
15	20	14
16	21	15
17	21	14
18	22	19
19	22	18
20	22	17
21	22	16
22	24	20
23	24	21
24	24	22
25	24	23
26	28	24
27	28	25
28	28	26
29	28	6
30	31	11
31	31	27
32	31	4
33	33	30
34	33	28
35	33	29
36	34	32
37	34	31
38	34	29
39	41	33
40	41	29
41	41	34
42	46	39
43	46	38
44	46	37
45	46	29
46	46	35
47	46	36
48	48	13
49	48	36
50	48	40
51	51	13
52	51	41
53	53	11
54	56	13
55	56	42
56	56	43
57	58	28
58	58	29
59	69	46
60	69	44
61	69	45
62	76	47
63	76	26
64	76	50
65	76	48
66	76	49
67	77	19
68	77	2
69	77	51
70	79	54
71	79	28
72	79	53
73	79	52
74	88	55
75	88	57
76	88	56
77	88	28
78	90	13
79	90	59
80	90	58
81	92	60
82	92	61
83	92	13
84	92	59
85	99	61
86	99	62
87	99	63
88	99	64
89	101	4
90	101	6
\.


--
-- Name: posts_post_tag_set_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('posts_post_tag_set_id_seq', 90, true);


--
-- Data for Name: posts_postview; Type: TABLE DATA; Schema: public; Owner: -
--

COPY posts_postview (id, ip, post_id, date) FROM stdin;
1	127.0.0.1	34	2014-04-29 13:28:09.157-04
2	127.0.0.1	92	2014-04-29 13:28:09.779-04
3	127.0.0.1	34	2014-04-30 13:10:36.535-04
4	127.0.0.1	101	2014-05-09 10:39:20.173-04
5	127.0.0.1	99	2014-05-09 10:40:31.856-04
6	127.0.0.1	69	2014-07-11 10:15:13.59-04
7	127.0.0.1	99	2014-07-11 10:16:28.239-04
\.


--
-- Name: posts_postview_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('posts_postview_id_seq', 7, true);


--
-- Data for Name: posts_replytoken; Type: TABLE DATA; Schema: public; Owner: -
--

COPY posts_replytoken (id, date, user_id, post_id, token) FROM stdin;
1	2014-04-29 11:30:13.832-04	3	7	58d43201e860670862b2cbb8d6177dc8
2	2014-04-29 11:30:13.852-04	3	8	d76b18bacf7ab9403efa8a27b36b48d9
3	2014-04-29 11:30:13.871-04	3	9	76d0cb5f7851acb2275dec01c17753a4
4	2014-04-29 11:30:13.917-04	10	11	5a12c8be1838453c2fccce9028da087b
5	2014-04-29 11:30:13.974-04	12	14	553be3c645911a8adc25388cda883e91
6	2014-04-29 11:30:13.993-04	12	15	ec68a03d3eb79b24bfbe1efcf4171c76
7	2014-04-29 11:30:14.013-04	12	16	90483e0fbf373bc6061823a7cac61ea6
8	2014-04-29 11:30:14.032-04	2	17	d8056e9808ae7b32be0016b6204adf6d
9	2014-04-29 11:30:14.051-04	2	18	efdab3ad7f7a289a745bd3d71a50015b
10	2014-04-29 11:30:14.069-04	2	19	92b4f704fb00419c5b36787899130243
11	2014-04-29 11:30:14.17-04	16	23	5d1a771b4c1912ca2895f20a6c2063b6
12	2014-04-29 11:30:14.212-04	14	25	319df6b8e058bb0c1dd87be84a513654
13	2014-04-29 11:30:14.234-04	14	26	896bcfb68e68d2f34dbea65ae1c71035
14	2014-04-29 11:30:14.253-04	16	27	c47d61f4d27f0211b1c3022ee36b01b7
15	2014-04-29 11:30:14.306-04	20	29	936baec406eed9c26e4e0caf0f2e6b1e
16	2014-04-29 11:30:14.332-04	2	30	294deb383fb86bbd629379c3920d0725
17	2014-04-29 11:30:14.375-04	4	32	ca90355c744d7e3d806cc778944b4235
18	2014-04-29 11:30:14.437-04	23	35	8a6f4c1f812314c1e630b7d8f6be2811
19	2014-04-29 11:30:14.457-04	23	36	019a948987c739155a6e6ff721ca8afc
20	2014-04-29 11:30:14.482-04	23	37	1a68f57c15c32a4bdaa9d11a1a7dc90b
21	2014-04-29 11:30:14.5-04	23	38	adf6fba6bf008c5f9be636e2ddd4ae5d
22	2014-04-29 11:30:14.523-04	16	39	a5acd55d64d101085765a151dab13b2a
23	2014-04-29 11:30:14.543-04	3	40	39e8bf6d9bfd261a53eca3d2a145df7f
24	2014-04-29 11:30:14.586-04	2	42	bff8824e847f00173ff1bab7e8e5e976
25	2014-04-29 11:30:14.629-04	23	44	7e533d86b1a8fd788e8dba32835847b4
26	2014-04-29 11:30:14.648-04	23	45	38d2d47d4397b9b4cafe0e8ecedd7d72
27	2014-04-29 11:30:14.689-04	23	47	0a6a60cc5e59d77a34f7a66643613ab2
28	2014-04-29 11:30:14.729-04	23	49	7121feb4b1aa5c34a2b9112f10f252e2
29	2014-04-29 11:30:14.751-04	23	50	3bab174f136d0aa1abd9e442e9487d55
30	2014-04-29 11:30:14.791-04	14	52	13c887b3fcfce7aba7e6014ac5835ff0
31	2014-04-29 11:30:14.831-04	4	54	d1e57b7541bdee21c2092009661ee8e5
32	2014-04-29 11:30:14.85-04	27	55	d691fd0b75d5de98fad691ba3a27a653
33	2014-04-29 11:30:14.892-04	23	57	f99b528c7799843808ff36f19d36621b
34	2014-04-29 11:30:14.934-04	23	59	49a2df5601cb8ed59564f3d335d1bb34
35	2014-04-29 11:30:14.953-04	3	60	b9730576b45d6ded5ee4bc2f1dc8ea54
36	2014-04-29 11:30:14.972-04	23	61	500870618936ae72859fc2a1a6dc846d
37	2014-04-29 11:30:14.992-04	23	62	a632e3202f7837d9d580e166a096176a
67	2014-05-09 10:39:13.584-04	16	98	8f0d04ce
38	2014-04-29 11:30:15.035-04	23	63	8693c0fa74972667167e60b9c300617e
39	2014-04-29 11:30:15.054-04	23	64	02f793bbd89a552391f96f69114a888b
40	2014-04-29 11:30:15.073-04	23	65	c43a17899c7d4d089003db532b3a8e2a
41	2014-04-29 11:30:15.092-04	2	66	be3d2a90c8546168f90412ebf140eb02
42	2014-04-29 11:30:15.112-04	23	67	264aa9e0a9797e926aacd8673a2c3756
43	2014-04-29 11:30:15.134-04	23	68	6fceb91302ffb3465f81999a45d9c046
44	2014-04-29 11:30:15.179-04	23	70	3f63e536fc85d8452d49ecfa3cec5824
45	2014-04-29 11:30:15.201-04	30	71	1d9c15440b5f935f26ada22836c2fb29
46	2014-04-29 11:30:15.224-04	30	72	cd5f5e3b77def753f1941042da0ac681
47	2014-04-29 11:30:15.248-04	30	73	7712220c0a6a053b6d090bd1441dd012
48	2014-04-29 11:30:15.284-04	30	74	80b2434e10ab57083331f38bea8ace21
49	2014-04-29 11:30:15.306-04	2	75	cb32db62a6870b15e2681f1eb77b3808
50	2014-04-29 11:30:15.372-04	44	78	3dae8388fbf78002be9ca4d180a88cec
51	2014-04-29 11:30:15.411-04	23	80	89ff6f8e40efecce625afdbdd4f3bba0
52	2014-04-29 11:30:15.454-04	23	82	e85c46580ef0c618d3345c55741fa9a7
53	2014-04-29 11:30:15.473-04	23	83	876218bb0ff562fdb2d02735e0120495
54	2014-04-29 11:30:15.493-04	23	84	6b65b8c1c5ea781ebc8b943d42fecaeb
55	2014-04-29 11:30:15.514-04	23	85	56eeb0075d787a97358dcd3eded089ea
56	2014-04-29 11:30:15.534-04	23	86	d278e262bed502bb2ec850f973c1b08d
57	2014-04-29 11:30:15.557-04	30	87	e84f198025c3543d3d0646ce55a5511b
58	2014-04-29 11:30:15.606-04	23	89	f0003fbf2765b0dd49f00ae353cbfab8
59	2014-04-29 11:30:15.648-04	23	91	9b98ff409830dd448ed0011b1868c428
60	2014-04-29 11:30:15.69-04	2	93	447e758d06f52403889c39ce4f66902c
61	2014-04-29 11:30:15.709-04	10	94	57523b85c81c4c6bf2f97e03deac983f
62	2014-04-29 11:30:15.734-04	23	95	05404dcb08c27d01b14d4279408e88ed
63	2014-04-29 11:30:15.759-04	10	96	5e587d9f05dfc15226825a8de6abd311
64	2014-04-29 11:30:15.781-04	16	97	8364111d4df17d5cc3a1935c2ac18cb9
65	2014-04-29 11:30:15.805-04	16	98	5f1ae95e8a8d5253360ce9e2ebdf999c
66	2014-04-29 11:30:15.856-04	10	100	b486a14648bb925dc6e43e52ea2e9108
68	2014-05-09 10:39:13.639-04	10	100	1fd599a1
69	2014-05-09 10:39:20.151-04	2	101	9a7e846c
\.


--
-- Name: posts_replytoken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('posts_replytoken_id_seq', 69, true);


--
-- Data for Name: posts_subscription; Type: TABLE DATA; Schema: public; Owner: -
--

COPY posts_subscription (id, user_id, post_id, type, date) FROM stdin;
1	2	1	1	2014-04-29 11:02:13.939-04
2	2	2	1	2014-04-29 11:02:13.973-04
3	3	4	1	2014-04-29 11:02:14.052-04
4	2	5	1	2014-04-29 11:02:14.084-04
5	5	6	1	2014-04-29 11:02:14.118-04
6	5	4	0	2014-04-29 11:02:14.155-04
7	6	4	0	2014-04-29 11:02:14.184-04
8	7	4	0	2014-04-29 11:02:14.211-04
9	10	10	1	2014-04-29 11:02:14.234-04
10	2	10	0	2014-04-29 11:02:14.28-04
11	12	13	1	2014-04-29 11:02:14.33-04
12	2	13	0	2014-04-29 11:02:14.372-04
13	5	13	0	2014-04-29 11:02:14.4-04
14	13	13	0	2014-04-29 11:02:14.426-04
15	10	1	0	2014-04-29 11:02:14.456-04
16	14	1	0	2014-04-29 11:02:14.485-04
17	5	5	0	2014-04-29 11:02:14.523-04
18	15	20	1	2014-04-29 11:02:14.549-04
19	15	21	1	2014-04-29 11:02:14.582-04
20	16	22	1	2014-04-29 11:02:14.632-04
21	2	22	0	2014-04-29 11:02:14.676-04
22	14	24	1	2014-04-29 11:02:14.703-04
23	18	24	0	2014-04-29 11:02:14.746-04
24	2	24	0	2014-04-29 11:02:14.777-04
25	19	22	0	2014-04-29 11:02:14.808-04
26	20	28	1	2014-04-29 11:02:14.844-04
27	2	28	0	2014-04-29 11:02:14.891-04
28	20	2	0	2014-04-29 11:02:15.006-04
29	4	31	1	2014-04-29 11:02:15.029-04
30	2	31	0	2014-04-29 11:02:15.071-04
31	23	33	1	2014-04-29 11:02:15.096-04
32	23	34	1	2014-04-29 11:02:15.137-04
33	2	33	0	2014-04-29 11:02:15.179-04
34	2	34	0	2014-04-29 11:02:15.208-04
35	25	34	0	2014-04-29 11:02:15.268-04
36	23	22	0	2014-04-29 11:02:15.299-04
37	23	4	0	2014-04-29 11:02:15.328-04
38	23	41	1	2014-04-29 11:02:15.356-04
39	23	1	0	2014-04-29 11:02:15.393-04
40	2	41	0	2014-04-29 11:02:15.457-04
41	4	41	0	2014-04-29 11:02:15.483-04
42	23	46	1	2014-04-29 11:02:15.508-04
43	2	46	0	2014-04-29 11:02:15.563-04
44	23	48	1	2014-04-29 11:02:15.588-04
45	2	48	0	2014-04-29 11:02:15.627-04
46	26	48	0	2014-04-29 11:02:15.659-04
47	14	51	1	2014-04-29 11:02:15.701-04
48	2	51	0	2014-04-29 11:02:15.739-04
49	27	53	1	2014-04-29 11:02:15.772-04
50	27	31	0	2014-04-29 11:02:15.816-04
51	28	53	0	2014-04-29 11:02:15.847-04
52	23	56	1	2014-04-29 11:02:15.871-04
53	2	56	0	2014-04-29 11:02:15.911-04
54	23	58	1	2014-04-29 11:02:15.939-04
55	30	56	0	2014-04-29 11:02:15.977-04
56	31	4	0	2014-04-29 11:02:16.005-04
57	31	58	0	2014-04-29 11:02:16.034-04
58	2	58	0	2014-04-29 11:02:16.063-04
59	35	46	0	2014-04-29 11:02:16.121-04
60	35	34	0	2014-04-29 11:02:16.15-04
61	33	33	0	2014-04-29 11:02:16.178-04
62	33	1	0	2014-04-29 11:02:16.227-04
63	38	33	0	2014-04-29 11:02:16.267-04
64	38	58	0	2014-04-29 11:02:16.302-04
65	30	69	1	2014-04-29 11:02:16.328-04
66	40	58	0	2014-04-29 11:02:16.373-04
67	42	69	0	2014-04-29 11:02:16.407-04
68	23	69	0	2014-04-29 11:02:16.438-04
69	2	69	0	2014-04-29 11:02:16.475-04
70	26	1	0	2014-04-29 11:02:16.558-04
71	30	76	1	2014-04-29 11:02:16.589-04
72	44	77	1	2014-04-29 11:02:16.628-04
73	10	77	0	2014-04-29 11:02:16.672-04
74	23	79	1	2014-04-29 11:02:16.694-04
75	2	79	0	2014-04-29 11:02:16.736-04
76	47	79	0	2014-04-29 11:02:16.815-04
77	7	48	0	2014-04-29 11:02:16.842-04
78	53	79	0	2014-04-29 11:02:16.879-04
79	24	58	0	2014-04-29 11:02:16.995-04
80	7	58	0	2014-04-29 11:02:17.107-04
81	55	69	0	2014-04-29 11:02:17.193-04
82	23	88	1	2014-04-29 11:02:17.228-04
83	2	88	0	2014-04-29 11:02:17.296-04
84	10	90	1	2014-04-29 11:02:17.335-04
85	39	88	0	2014-04-29 11:02:17.403-04
86	10	92	1	2014-04-29 11:02:17.432-04
87	45	5	0	2014-04-29 11:02:17.47-04
88	23	90	0	2014-04-29 11:02:17.498-04
89	24	79	0	2014-04-29 11:02:17.536-04
90	24	90	0	2014-04-29 11:02:17.573-04
91	59	22	0	2014-04-29 11:02:17.602-04
92	55	22	0	2014-04-29 11:02:17.638-04
93	10	99	1	2014-04-29 11:02:17.666-04
94	2	99	0	2014-04-29 11:02:17.719-04
95	1	101	1	2014-05-09 10:39:20.059-04
96	2	101	1	2014-05-09 10:39:20.066-04
\.


--
-- Name: posts_subscription_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('posts_subscription_id_seq', 96, true);


--
-- Data for Name: posts_tag; Type: TABLE DATA; Schema: public; Owner: -
--

COPY posts_tag (id, name, count) FROM stdin;
1	guidelines	7
3	gff	7
5	yeast	7
7	microarray	7
8	clustering	7
9	test	7
10	nucleotides	7
12	deep	7
14	boy	14
15	george	14
16	geneid	7
17	accession	7
18	mapping	7
20	shrimp	7
21	sequencing	7
22	short	7
23	aligner	7
24	meme	7
25	sge	7
27	rna	7
30	os	7
31	programming	7
32	languages	7
33	gene	7
34	go	7
35	string	7
37	interacti	7
38	ppi	7
39	pin	7
36	protein	14
40	structure	7
41	blast	7
11	solid	21
42	ucsc	7
43	fasta	7
29	subjective	35
44	hdf	7
45	biohdf	7
46	storage	7
26	compilation	14
47	taverna	7
48	plugin	7
49	maven	7
50	workflow	7
2	bed	14
19	conversion	14
51	format	7
52	make	7
53	pipeline	7
54	organization	7
28	general	28
55	agile	7
56	good	7
57	team	7
58	biopython	7
13	sequence	42
59	python	14
60	pygr	7
61	use	14
62	interval	7
63	query	7
64	genomics	7
4	galaxy	18
6	motif	18
\.


--
-- Name: posts_tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('posts_tag_id_seq', 64, true);


--
-- Data for Name: posts_vote; Type: TABLE DATA; Schema: public; Owner: -
--

COPY posts_vote (id, author_id, post_id, type, date) FROM stdin;
1	2	7	0	2014-04-29 11:02:17.74-04
2	2	7	0	2014-04-29 11:02:17.74-04
3	2	4	0	2014-04-29 11:02:17.74-04
4	2	8	0	2014-04-29 11:02:17.74-04
5	10	11	0	2014-04-29 11:02:17.74-04
6	10	11	0	2014-04-29 11:02:17.74-04
7	10	11	3	2014-04-29 11:02:17.74-04
8	10	12	0	2014-04-29 11:02:17.74-04
9	2	10	0	2014-04-29 11:02:17.74-04
10	2	13	0	2014-04-29 11:02:17.74-04
11	2	15	0	2014-04-29 11:02:17.74-04
12	2	13	0	2014-04-29 11:02:17.74-04
13	2	16	0	2014-04-29 11:02:17.74-04
14	10	1	0	2014-04-29 11:02:17.74-04
15	2	18	0	2014-04-29 11:02:17.74-04
16	2	18	3	2014-04-29 11:02:17.74-04
17	5	10	0	2014-04-29 11:02:17.74-04
18	2	24	0	2014-04-29 11:02:17.74-04
19	2	25	0	2014-04-29 11:02:17.74-04
20	14	25	0	2014-04-29 11:02:17.74-04
21	14	26	0	2014-04-29 11:02:17.74-04
22	2	27	0	2014-04-29 11:02:17.74-04
23	2	28	0	2014-04-29 11:02:17.74-04
24	20	29	3	2014-04-29 11:02:17.74-04
25	2	30	0	2014-04-29 11:02:17.74-04
26	2	34	0	2014-04-29 11:02:17.74-04
27	2	33	0	2014-04-29 11:02:17.74-04
28	2	31	0	2014-04-29 11:02:17.74-04
29	2	39	0	2014-04-29 11:02:17.74-04
30	23	8	0	2014-04-29 11:02:17.74-04
31	23	7	0	2014-04-29 11:02:17.74-04
32	23	35	0	2014-04-29 11:02:17.741-04
33	23	36	0	2014-04-29 11:02:17.741-04
34	23	38	0	2014-04-29 11:02:17.741-04
35	23	1	0	2014-04-29 11:02:17.741-04
36	23	17	0	2014-04-29 11:02:17.741-04
37	23	3	0	2014-04-29 11:02:17.741-04
38	2	43	0	2014-04-29 11:02:17.741-04
39	2	40	0	2014-04-29 11:02:17.741-04
40	23	44	0	2014-04-29 11:02:17.741-04
41	23	45	0	2014-04-29 11:02:17.741-04
42	23	47	0	2014-04-29 11:02:17.741-04
43	23	47	3	2014-04-29 11:02:17.741-04
44	2	46	0	2014-04-29 11:02:17.741-04
45	2	41	0	2014-04-29 11:02:17.741-04
46	2	22	0	2014-04-29 11:02:17.741-04
47	23	45	3	2014-04-29 11:02:17.741-04
48	4	32	0	2014-04-29 11:02:17.741-04
49	4	32	3	2014-04-29 11:02:17.741-04
50	4	8	0	2014-04-29 11:02:17.741-04
51	2	48	0	2014-04-29 11:02:17.741-04
52	2	50	0	2014-04-29 11:02:17.741-04
53	14	52	3	2014-04-29 11:02:17.741-04
54	2	51	0	2014-04-29 11:02:17.741-04
55	23	50	0	2014-04-29 11:02:17.741-04
56	23	49	0	2014-04-29 11:02:17.741-04
57	23	50	3	2014-04-29 11:02:17.741-04
58	23	52	0	2014-04-29 11:02:17.741-04
59	23	54	0	2014-04-29 11:02:17.741-04
60	23	55	0	2014-04-29 11:02:17.741-04
61	23	53	0	2014-04-29 11:02:17.741-04
62	2	56	0	2014-04-29 11:02:17.741-04
63	23	57	0	2014-04-29 11:02:17.741-04
64	23	61	0	2014-04-29 11:02:17.741-04
65	2	59	0	2014-04-29 11:02:17.741-04
66	2	56	0	2014-04-29 11:02:17.741-04
67	2	64	0	2014-04-29 11:02:17.741-04
68	2	38	1	2014-04-29 11:02:17.741-04
69	2	63	0	2014-04-29 11:02:17.741-04
70	2	65	0	2014-04-29 11:02:17.741-04
71	2	66	0	2014-04-29 11:02:17.741-04
72	33	46	0	2014-04-29 11:02:17.741-04
73	33	60	0	2014-04-29 11:02:17.741-04
74	33	4	0	2014-04-29 11:02:17.741-04
75	31	62	0	2014-04-29 11:02:17.741-04
76	31	2	2	2014-04-29 11:02:17.741-04
77	33	34	0	2014-04-29 11:02:17.742-04
78	33	56	0	2014-04-29 11:02:17.742-04
79	23	62	0	2014-04-29 11:02:17.742-04
80	23	64	0	2014-04-29 11:02:17.742-04
81	23	59	3	2014-04-29 11:02:17.742-04
82	23	59	0	2014-04-29 11:02:17.742-04
83	23	67	0	2014-04-29 11:02:17.742-04
84	23	63	0	2014-04-29 11:02:17.742-04
85	23	63	3	2014-04-29 11:02:17.742-04
86	23	27	0	2014-04-29 11:02:17.742-04
87	23	65	0	2014-04-29 11:02:17.742-04
88	23	68	0	2014-04-29 11:02:17.742-04
89	38	58	0	2014-04-29 11:02:17.742-04
90	23	68	3	2014-04-29 11:02:17.742-04
91	30	68	0	2014-04-29 11:02:17.742-04
92	23	69	0	2014-04-29 11:02:17.742-04
93	23	70	0	2014-04-29 11:02:17.742-04
94	2	67	0	2014-04-29 11:02:17.742-04
95	2	70	0	2014-04-29 11:02:17.742-04
96	2	71	0	2014-04-29 11:02:17.742-04
97	23	71	0	2014-04-29 11:02:17.742-04
98	23	73	0	2014-04-29 11:02:17.742-04
99	2	69	0	2014-04-29 11:02:17.742-04
100	30	73	0	2014-04-29 11:02:17.742-04
\.


--
-- Name: posts_vote_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('posts_vote_id_seq', 100, true);


--
-- Data for Name: socialaccount_socialaccount; Type: TABLE DATA; Schema: public; Owner: -
--

COPY socialaccount_socialaccount (id, user_id, last_login, date_joined, provider, uid, extra_data) FROM stdin;
\.


--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('socialaccount_socialaccount_id_seq', 1, false);


--
-- Data for Name: socialaccount_socialapp; Type: TABLE DATA; Schema: public; Owner: -
--

COPY socialaccount_socialapp (id, provider, name, key, secret, client_id) FROM stdin;
1	persona	persona			
2	google	google		t9HkpSQk_kK0cmTTHsxoGbx1	547073349197-kfplpbmqsnnf1j605dus09elgmqu7hb6.apps.googleusercontent.com
3	github	github		c0c765fe24f106d6e5c24f2a21f15d9d0133141a	dcd67a119f800c42e4b6
\.


--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('socialaccount_socialapp_id_seq', 3, true);


--
-- Data for Name: socialaccount_socialapp_sites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY socialaccount_socialapp_sites (id, socialapp_id, site_id) FROM stdin;
1	1	1
2	2	1
3	3	1
\.


--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('socialaccount_socialapp_sites_id_seq', 3, true);


--
-- Data for Name: socialaccount_socialtoken; Type: TABLE DATA; Schema: public; Owner: -
--

COPY socialaccount_socialtoken (id, app_id, account_id, token, token_secret, expires_at) FROM stdin;
\.


--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('socialaccount_socialtoken_id_seq', 1, false);


--
-- Data for Name: south_migrationhistory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY south_migrationhistory (id, app_name, migration, applied) FROM stdin;
1	users	0001_initial	2015-01-22 10:27:29.600702-05
2	users	0002_auto__del_field_user_full_score__add_field_user_activity	2015-01-22 10:27:29.622368-05
3	users	0003_auto__add_tag__add_field_profile_twitter_id__add_field_profile_watch_t	2015-01-22 10:27:29.686479-05
4	users	0004_auto__add_field_profile_daily_digest__add_field_profile_weekly_digest	2015-01-22 10:27:29.713277-05
5	users	0005_add_weekly_digest	2015-01-22 10:27:29.725001-05
6	users	0006_auto__add_field_profile_opt_in	2015-01-22 10:27:29.739962-05
7	users	0007_auto__del_field_profile_weekly_digest__del_field_profile_daily_digest_	2015-01-22 10:27:29.75949-05
8	posts	0001_initial	2015-01-22 10:27:30.350725-05
9	posts	0002_auto__add_data	2015-01-22 10:27:30.414269-05
10	posts	0003_auto__add_foo	2015-01-22 10:27:30.443961-05
11	posts	0004_auto__del_data__del_foo__add_emailentry__add_emailsub	2015-01-22 10:27:30.473239-05
12	badges	0001_initial	2015-01-22 10:27:30.982985-05
13	badges	0002_auto__del_field_badge_secret__del_field_badge_description__add_field_b	2015-01-22 10:27:31.000128-05
14	badges	0003_auto__add_field_award_context	2015-01-22 10:27:31.013895-05
15	planet	0001_initial	2015-01-22 10:27:31.065707-05
16	planet	0002_auto__add_field_blog_list_order	2015-01-22 10:27:31.075778-05
17	socialaccount	0001_initial	2015-01-22 10:27:31.12225-05
18	socialaccount	0002_genericmodels	2015-01-22 10:27:31.211967-05
19	socialaccount	0003_auto__add_unique_socialaccount_uid_provider	2015-01-22 10:27:31.225982-05
20	socialaccount	0004_add_sites	2015-01-22 10:27:31.24638-05
21	socialaccount	0005_set_sites	2015-01-22 10:27:31.259241-05
22	socialaccount	0006_auto__del_field_socialapp_site	2015-01-22 10:27:31.27158-05
23	socialaccount	0007_auto__add_field_socialapp_client_id	2015-01-22 10:27:31.345256-05
24	socialaccount	0008_client_id	2015-01-22 10:27:31.358316-05
25	socialaccount	0009_auto__add_field_socialtoken_expires_at	2015-01-22 10:27:31.371312-05
26	socialaccount	0010_auto__chg_field_socialtoken_token	2015-01-22 10:27:31.407882-05
27	socialaccount	0011_auto__chg_field_socialtoken_token	2015-01-22 10:27:31.446392-05
28	socialaccount	0012_auto__chg_field_socialtoken_token_secret	2015-01-22 10:27:31.485354-05
29	djcelery	0001_initial	2015-01-22 10:27:31.601557-05
30	djcelery	0002_v25_changes	2015-01-22 10:27:31.637279-05
31	djcelery	0003_v26_changes	2015-01-22 10:27:31.656571-05
32	djcelery	0004_v30_changes	2015-01-22 10:27:31.668254-05
33	django	0001_initial	2015-01-22 10:27:31.726993-05
34	server	0001_initial	2015-01-22 10:27:31.796086-05
\.


--
-- Name: south_migrationhistory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('south_migrationhistory_id_seq', 34, true);


--
-- Data for Name: users_emaillist; Type: TABLE DATA; Schema: public; Owner: -
--

COPY users_emaillist (id, date, email, type, active) FROM stdin;
\.


--
-- Name: users_emaillist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('users_emaillist_id_seq', 1, false);


--
-- Data for Name: users_profile; Type: TABLE DATA; Schema: public; Owner: -
--

COPY users_profile (id, user_id, uuid, last_login, date_joined, location, website, scholar, my_tags, info, message_prefs, flag, twitter_id, watched_tags, opt_in, digest_prefs) FROM stdin;
1	1	9428b06c8c04f25b5abf95d8354b2571	2014-05-09 10:39:21.999-04	2014-04-29 11:02:11.528-04	State College, USA					3	0			f	2
2	2	7db961d01bd62e569f584bd0aeb035aa	2014-07-11 10:19:18.323-04	2009-09-30 15:30:39.57-04	University Park	http://www.personal.psu.edu/iua1/			<p>Current position: Research Associate Professor of Bioinformatics at Penn State</p>\n	3	0	zumm	galaxy, minia	f	2
3	3	2c95a46647f03e33aea79243ec353b26	2009-10-05 17:43:12.173-04	2009-09-30 18:09:06.6-04						3	0			f	2
4	4	1ea9fa61da4b44c4329942cdf51710e6	2011-11-04 16:45:04.227-04	2009-09-30 19:10:54.623-04					<p>Grad student at PSU</p>\n	3	0			f	2
5	5	8a92ca71e614f2669e5114cce384bc6a	2011-07-06 19:44:55.723-04	2009-09-30 20:48:08.723-04	502 Wartik Lab, Penn State Univ					3	0			f	2
6	6	87e4c8d6cfa89ae3bd8616cca02189c4	2009-09-30 21:32:29.033-04	2009-09-30 21:32:29.033-04						3	0			f	2
7	7	b6bc828bfce3913972cf286618113ce9	2011-07-07 05:32:47.793-04	2009-09-30 21:35:27.973-04	state college	http://twitter.com/suk211			<p>interested systems biology,protein folding ,genomics</p>\n	3	0			f	2
8	8	e038b231cc619eef4639e884015333ca	2010-10-14 01:59:00.327-04	2009-10-03 05:02:07.727-04	China,WH					3	0			f	2
9	9	8342495beebd4d7c2fb8d3e3f97bf64d	2011-11-04 02:28:53.817-04	2009-10-03 12:15:52.077-04	China	http://quwubin.sinaapp.com/			<p>Bioinformatics researcher, author of MFEprimer, MPprimer and CelRNAi.</p>\n	3	0			f	2
10	10	de65e553cc0085e0162ebc7cbc7204e7	2013-04-22 14:30:22.763-04	2009-10-05 17:44:30.853-04						3	0			f	2
11	11	c09a115704330b6c839291009efb0b64	2009-10-05 18:47:25.69-04	2009-10-05 18:47:25.69-04	University Park	http://www.phys.psu.edu/~ralbert/				3	0			f	2
12	12	b1f45396c03358d4c998383fb1510d81	2009-10-07 03:45:15.08-04	2009-10-06 20:58:10.083-04						3	0			f	2
13	13	a4700b3df7890aead3bc10749213524d	2009-10-07 15:04:30.217-04	2009-10-07 00:04:41.7-04						3	0			f	2
14	14	397f3990a96766bf70a13b7ac42daaf0	2011-10-29 00:18:27.637-04	2009-10-09 04:54:13.48-04	State College, PA				<p>A grad student in bioinformatics studying plant small RNAs.</p>\n	3	0			f	2
15	15	b12240f4a599d5f23445e323a142cd5b	2009-10-18 05:22:53.687-04	2009-10-18 05:22:53.687-04						3	0			f	2
16	16	fc355f3a153dc09cdf592308ee26fc0f	2010-02-20 22:13:56.363-05	2009-10-23 19:40:27.03-04						3	0			f	2
17	17	ff811eb67a6b661c2f26f8d6d5b03975	2011-10-24 23:24:37.19-04	2009-11-04 19:39:12.007-05						3	0			f	2
18	18	8920f2b251f1e0f4405777ca86bbf957	2009-12-01 17:51:54.427-05	2009-12-01 15:57:35.02-05						3	0			f	2
19	19	b8f90a1927779e2fc1ec2469859420c8	2009-12-08 22:45:54.22-05	2009-12-08 22:45:54.22-05						3	0			f	2
20	20	300f2a04cb6f5d8d27e732faad01f12c	2011-11-08 13:23:58.05-05	2009-12-23 02:10:22.66-05						3	0			f	2
21	21	2cdc27d640e61b16951f016af7b35aaa	2009-12-28 14:56:46.033-05	2009-12-28 14:56:46.033-05						3	0			f	2
22	22	75bd966bfb9d1bf7f254020f169a5863	2010-04-10 04:15:19.79-04	2009-12-31 14:26:29.283-05						3	0			f	2
23	23	412b84490c0ce653cfb8729cc2f9cef8	2011-11-08 14:37:21.753-05	2010-01-18 16:43:55.253-05	Barcelona, Spain	http://bioinfoblog.it			<p>PhD student at the Pompeu Fabra University in Barcelona. Interested in bioinformatics, R, python programming and agile techniques.</p>\n	3	0			f	2
24	24	c5b6e90e94c47609a7d1bec571083e1d	2011-11-08 00:26:49.263-05	2010-01-23 18:01:47.617-05	Athens, GA	http://etalog.blogspot.com/				3	0			f	2
25	25	6b1a47a5753751738f8c739824605036	2010-01-27 01:38:35.55-05	2010-01-27 00:42:13.98-05						3	0			f	2
26	26	ca27575af4b79d86d5df1b03ce0dc93f	2011-10-28 08:58:08.517-04	2010-02-12 22:29:24.91-05						3	0			f	2
27	27	f86e90b7decb0efc9c119c2cd718c362	2010-03-11 03:42:46.73-05	2010-02-19 08:25:13.603-05						3	0			f	2
28	28	7f8f978a6f0b2071fba8cc52ecb4c38f	2010-02-19 20:35:30.157-05	2010-02-19 14:33:45.333-05						3	0			f	2
29	29	d24e7138efa7444a7b0ee4fc99200979	2011-03-17 07:18:47.65-04	2010-02-22 04:24:18.933-05						3	0			f	2
30	30	15ee06265e393f65a8ec6404df6a9ba9	2011-11-08 15:35:24.15-05	2010-02-25 18:27:15.56-05	France	http://plindenbaum.blogspot.com			<p>Virology, Bioinformatics , Genetics</p>\n\n<p><a href="http://twitter.com/yokofakun">http://twitter.com/yokofakun</a></p>\n\n<p>Neil Saunders is an impostor because he doesn't exist.</p>\n\n<p>Please, don't vote for him :-)</p>\n	3	0			f	2
31	31	e872facb6b47883644f0965eb2192f95	2011-08-11 22:05:42.993-04	2010-02-25 18:42:49.15-05	Porto Alegre, RS, Brasil	http://www.marcosdecarvalho.com			<p>Doctoral student.</p>\n	3	0			f	2
32	32	48ba9d1464512088542c06b1a55a860b	2010-02-25 19:22:10.283-05	2010-02-25 19:22:10.283-05	Campinas, Brazil	http://www.lge.ibi.unicamp.br			<p>Phd candidate at State University of Campinas (UNICAMP)\nBs in Computer Science (UFS)</p>\n\n<p>Bioinformatician with experience in genomics, transcriptomics, gene finding and next-generation sequencing.</p>\n	3	0			f	2
33	33	2aa464fbd7c268351271132fa3b13a74	2010-02-26 01:09:01.27-05	2010-02-25 19:28:54.453-05						3	0			f	2
34	34	659247b1e4f22d03109bbdf33bacb608	2011-06-09 22:08:05.94-04	2010-02-25 19:31:12.473-05	Ipswich, MA	http://www.davispj.com				3	0			f	2
35	35	b9fb010aac2a4bc44c112cff91312af3	2011-11-02 00:06:55.93-04	2010-02-25 22:30:36.047-05	Boston, MA					3	0			f	2
36	36	ad3bfa7ffb49acbde3f9617eaab24dd0	2011-11-08 14:32:43.78-05	2010-02-25 22:33:47.56-05	Denver, Colorado	https://github.com/brentp			<p>I do bioinformatics at a hospital in denver.</p>\n\n<p>\n<a href="http://github.com/brentp/" rel="nofollow">some of my code</a>\n</p>\n\n<p>\n<a href="http://hackmap.blogspot.com/" rel="nofollow">and my blog</a>\n</p>\n\n<p>and \n<a href="http://twitter.com/#!/brent_p" rel="nofollow">twitter</a></p>\n	3	0			f	2
37	37	e268c14fe9193ec154cd76924f2a71c3	2010-06-21 17:27:38.803-04	2010-02-26 08:58:44.137-05	Budapest	http://biopunk.hu				3	0			f	2
38	38	e4a60f08057d7f587542f0b2826472e3	2011-11-08 11:47:47.327-05	2010-02-26 10:26:42.033-05	Newcastle	http://fuzzierlogic.com/			<p></p><p>Bioinformatician, support scientist, Python programmer. Full bio on <a href="http://blog.fuzzierlogic.com/about" rel="nofollow">my blog</a>. You can also follow me <a href="http://twitter.com/sjcockell" rel="nofollow">on Twitter</a>.</p>\n\n<p></p><p>I work with <a href="http://biostar.stackexchange.com/users/59/daniel-swan" rel="nofollow">Daniel</a> in the <a href="http://bsu.ncl.ac.uk/" rel="nofollow">Bioinformatics Support Unit</a> of Newcastle University.</p>\n	3	0			f	2
39	39	959a865854e2d90ebe04bb11440829de	2011-11-08 15:33:26.513-05	2010-02-26 14:01:06.773-05		http://konrad.foerstner.org				3	0			f	2
40	40	8ca824b97e40af61ed34dcf60ccdda16	2011-11-07 20:51:55.693-05	2010-02-26 14:06:05.413-05		http://www.biorelated.com				3	0			f	2
41	41	f49922dc6480ab18cdb0b034e0a837d5	2011-09-05 10:27:23.12-04	2010-02-26 14:37:34.387-05	Basel, Switzerland				<p>computational biology for the pharmaceutical industry, father, geek, climber, biker</p>\n	3	0			f	2
42	42	ccac10608aa8463c4a841e7bd9a92fb6	2010-02-26 15:26:41.17-05	2010-02-26 14:47:41.54-05						3	0			f	2
43	43	f541c1df4528a879a9637c9a1dee57b0	2010-02-26 15:47:27.6-05	2010-02-26 15:47:27.6-05						3	0			f	2
44	44	1a1dc99c3e2b299c0c81aa0606e1e8af	2011-11-07 15:16:10.883-05	2010-02-26 16:49:18.47-05						3	0			f	2
45	45	0a0e02f753dcf32806420c68471c5fd9	2010-03-09 23:07:11.9-05	2010-02-26 17:06:54.723-05						3	0			f	2
46	46	c59f65d8e8305712a786e6c6d1e66cc5	2011-05-21 02:41:18.377-04	2010-02-26 17:54:23.013-05						3	0			f	2
47	47	853ff6827bf2e1b575bae774a234ff4e	2011-11-08 09:54:56.163-05	2010-02-26 17:57:13.31-05	Munich	http://www.rostlab.org/~schaefer/			<p>Researcher in structural bioinformatics</p>\n	3	0			f	2
48	48	9a29dd1bf3d8aac62621c451e46a8d2a	2011-05-17 19:54:53.35-04	2010-02-26 18:38:01.027-05	Salt Lake City Utah					3	0			f	2
49	49	fafdcd838d9847a188e169b38ebb78b3	2010-02-26 19:20:47.79-05	2010-02-26 19:20:47.79-05						3	0			f	2
50	50	cb1e8828b7d32e74d6809383d7639ec2	2010-03-01 18:25:38.71-05	2010-02-26 19:38:07.187-05						3	0			f	2
51	51	22fd820c589e1cae58caa9de512421d6	2010-04-20 22:16:04.98-04	2010-02-26 19:51:02.197-05		http://pbeltrao.blogspot.com				3	0			f	2
52	52	58bdf64561f2558b9dbd9f5db93201a1	2011-06-27 09:20:27.173-04	2010-02-26 20:00:28.793-05	Johannesburg, South Africa					3	0			f	2
53	53	66b43395f7793dbd8cc0d72ac942d401	2011-11-07 20:33:32.65-05	2010-02-26 20:59:50.253-05	Akron, Ohio, United States	http://www.michaelbarton.me.uk			<p>Doing post doc in genomics.</p>\n	3	0			f	2
54	54	e63472d230a169eac4b20ab349bab9a7	2011-11-07 11:47:03.237-05	2010-02-27 20:19:21.037-05						3	0			f	2
55	55	95f482a1800be96d221414dc23d607e8	2011-11-08 14:25:04.193-05	2010-02-27 22:00:55.783-05	Bergen	http://esysbio.bccs.uib.no/			<p>Just wanted to get the autobiographer badge ;)</p>\n	3	0			f	2
56	56	1cb6356fb69fa99d9a66e723a201bc7e	2011-11-08 15:25:40.23-05	2010-02-28 23:41:45.45-05	Boston, MA	http://bcbio.wordpress.com				3	0			f	2
57	57	8914a3a1501821306d8b7417d3d82376	2010-03-01 14:31:45.8-05	2010-03-01 14:31:45.8-05	Buenos Aires, Argentina					3	0			f	2
58	58	eff9a70e718b56dee3553a33eb854b54	2011-11-08 15:16:50.12-05	2010-03-01 17:58:57.787-05	Ann Arbor, MI	http://davebridges.github.com				3	0			f	2
59	59	6bc3aa8ad96c74f1fa56408aaa5aade2	2011-11-08 12:49:49.013-05	2010-03-01 18:03:24.703-05	Oxford, UK	http://eridanus.net			<p>Senior NGS Computational Biologist at Oxford Gene Technology.</p><p></p>\n\n<p>You can find out more about OGT's products and services at <a href="http://www.ogt.co.uk" rel="nofollow">www.ogt.co.uk</a>\n</p><p>\nOGT offers a broad range of microarray and targeted sequencing services enabling high-quality, high-throughput genomic studies. The company also specialises in cytogenetic microarays and biomarker discovery and validation.\n</p><p>\nBlog: <a href="http://eridanus.net" rel="nofollow">eridanus.net</a></p><p>\nTwitter: <a href="http://twitter.com/d_swan" rel="nofollow">twitter.com/d_swan</a>\n</p><p>\nI contribute to BioStar on my own time and therefore comments and opinions are my own and not that of my employer.</p>\n	3	0			f	2
60	60	0a0b2e0fb8d91f6193c201225111475b	2011-04-23 14:38:38.71-04	2010-03-01 20:18:00.527-05	Austria					3	0			f	2
61	61	45f4a41937c7c75c513ec455d9c85be0	2011-08-15 21:18:52.72-04	2010-03-02 06:11:16.723-05	University of Illinois Urbana-Champaign	http://bioperl.org			<p>I'm very sleepy.</p>\n	3	0			f	2
62	62	f8fc1be51e6abdb8b0c2456d6df6f048	2011-11-08 12:44:29.277-05	2010-03-02 11:25:56.59-05	Barcelona, Spain	http://openwetware.org/wiki/User:Darek_Kedra				3	0			f	2
63	63	bb238598571d678088579c7563df1e98	2011-03-18 12:15:05.32-04	2010-03-03 01:34:39.337-05						3	0			f	2
64	64	9d62f6ddede1ab39b7ca09949c4003fc	2010-03-30 17:53:26.19-04	2010-03-03 18:17:23.793-05	Cambridge	http://manuelcorpas.com			<p>I am a lead developer of the DECIPHER database, a “DatabasE of Chromosomal Imbalance and Phenotype in Humans using Ensembl Resources”. The DECIPHER database is hosted at the Wellcome Trust Sanger Institute. Its main aim is to collect genotype and phenotype patient information from hospitals and research institutions around the world to help diagnose and catalogue developmental diseases. I was awarded a PhD in Computer Science by the University of Manchester for an algorithm I developed to enhance the classification of protein families using sequence and structural signatures.</p>\n	3	0			f	2
65	65	d465f52b3f36e823cfc5707da7c4bec7	2010-03-24 10:41:17.853-04	2010-03-03 22:18:31.757-05		http://www.abhishek-tiwari.com				3	0			f	2
66	66	83f87d8f18e250d84cd68fcc5af296ad	2011-11-08 11:47:18.24-05	2010-03-04 08:55:19.36-05	Sydney, Australia	http://nsaunders.wordpress.com			<p>I'm a statistical bioinformatician with CSIRO Mathematics, Information and Statistics (CMIS), based in Sydney, Australia.</p>\n	3	0			f	2
67	67	20de3ac83169e18dbbb13115520a8f0a	2011-11-08 12:34:53.17-05	2010-03-04 10:00:00.847-05	Wroclaw, Poland	http://friendfeed.com/byzia				3	0			f	2
68	68	6081840f76c59f8ae7ec4cdbde9e6b67	2011-11-07 21:04:57.533-05	2010-03-04 10:23:54.51-05	Antwerp, Belgium	http://jeroen.vangoey.be			<p>Just Another Genome Hacker, \n<br>\n<br>\nBioinformatics software developer at <a href="http://www.applied-maths.com/" rel="nofollow">Applied Maths</a>\n<br>\n<br>\nAlso known as BioGeek on the web. (Twitter: <a href="http://twitter.com/BioGeek" rel="nofollow">@BioGeek</a>)</p>\n	3	0			f	2
69	69	e96cc54bdc8be8a9ccac7e3a84f97716	2011-11-07 22:49:17.89-05	2010-03-04 10:49:54.847-05	Davis, CA	http://bioinformatics.ucdavis.edu				3	0			f	2
70	70	875b9a284146ee3209a6859330cf55cd	2011-11-08 11:50:21.707-05	2010-03-04 13:26:30.24-05		http://friendfeed.com/walshtp			<p>Bioinformatics programmer and sysadmin. Increasingly grizzled old Perl hacker. Machine for turning tea into grumpiness.\n</p>\n\n<p>\nAny views expressed here are mine alone and not necessarily representative of my employer.\n</p>\n	3	0			f	2
71	71	c262f57e4ffc3cf04195b45ae7ffc8ae	2011-11-08 14:30:22.413-05	2010-03-04 16:17:25.543-05	Uppsala	http://egonw.github.com			<p>Post-doc working on Open Data, Open Source, and Open Standards in cheminformatics, chemometrics and bioinformatics. Projects I work on include the CDK, Bioclipse, the Blue Obelisk Data Repository, and much more…</p>\n	3	0			f	2
72	72	6877dd5dd762e060565fac406bd27f07	2011-11-08 06:17:03.4-05	2010-03-04 16:17:55.313-05		http://mndoci.com			<p>Principal Product Manager for Amazon EC2.  Blogger, podcaster, scientist, technologist, musician and all round geek.  Find me at</p>\n\n<p>\n\n<a href="http://mndoci.com" rel="nofollow">bbgm</a> - the blog<br>\n<a href="http://mndoci.github.com" rel="nofollow">mndoci.github.com</a> - the portal<br>\n<a href="http://c2cbio.com" rel="nofollow">Coast to Coast Bio</a> - the podcast\n</p>\n	3	0			f	2
73	73	2c124c5550fe95c67d17a45d1d7a7c56	2011-11-08 15:01:40.577-05	2010-03-04 16:31:15.363-05	Philadelphia, PA	http://jermdemo.blogspot.com			<p>Bioinformatics software developer working at a pediatric hospital.</p>\n	3	0			f	2
74	74	70f7b9a66ae472b5ed1b17f40d989eb7	2011-11-07 21:03:19.973-05	2010-03-04 16:35:18.017-05						3	0			f	2
75	75	cbd6bf00c3591e093928a98af1116ece	2011-11-08 11:22:19.363-05	2010-03-04 17:33:40.567-05	Trieste	http://onertipaday.blogspot.com/				3	0			f	2
76	76	06778e6e4d6ab6a67c9c9b53a6379cb0	2011-09-26 16:55:47.58-04	2010-03-04 17:42:20.013-05						3	0			f	2
77	77	8014b9d7bd420ac00764f9e71522d5ca	2010-05-13 22:55:19.54-04	2010-03-04 17:53:55.957-05	Boston	http://eleanorhowe.com				3	0			f	2
78	78	c4fb8a744f8c1f98df65f6035481d954	2010-07-21 01:56:49.75-04	2010-03-04 19:05:38.647-05	Davis, CA	http://bioinformatics.ucdavis.edu				3	0			f	2
79	79	972a228cf87d1880992a4e49747934b3	2011-11-01 23:47:03.033-04	2010-03-04 19:08:31.377-05	Nijmegen, the Netherlands					3	0			f	2
80	80	0f28745fc2ff36f03b334997b2beb343	2011-11-08 15:07:57.847-05	2010-03-04 19:30:00.85-05	Vienna					3	0			f	2
81	81	0e14b6caad8e33ffd5e198fb79d6106f	2010-03-22 20:28:10.323-04	2010-03-04 20:06:35.72-05						3	0			f	2
82	82	f6f43ac9a7c1011fe020bf3a8b3f3e79	2011-06-16 20:05:52.5-04	2010-03-04 20:56:05.877-05	MA					3	0			f	2
83	83	f726efb22afbb4736b604618bbaa50d1	2011-11-08 15:36:17.927-05	2010-03-04 21:11:58.703-05						3	0			f	2
84	84	f8068b82cd9e489230bfd103213fb0ac	2010-03-12 16:52:48.487-05	2010-03-04 21:36:50.333-05						3	0			f	2
85	85	f5b85830da966bcf4f0f1c0151bbd38d	2010-03-04 21:49:12.787-05	2010-03-04 21:49:12.787-05						3	0			f	2
86	86	bda0d772b394dd85d0742cc87ad6df5a	2011-11-08 15:18:14.087-05	2010-03-05 00:27:54.383-05	San Diego, CA	http://sulab.org			<p>I am an Associate Professor at the Scripps Research Institute.  My lab is equally focused on biomedical discovery and bioinformatics tool development.</p>\n	3	0			f	2
87	87	a2e3b308bd3866d629083189b9a88929	2011-11-08 14:35:50.253-05	2010-03-05 03:42:56.367-05	Bangalore	http://twitter.com/kshameer			<p>Post-doc (Translational Bioinformatics) at Mayo Clinic, working on projects in computational genomics, network analysis and biomedical informatics. </p>\n\n<p>PhD in Computational Biology (National Centre for Biological Sciences (NCBS - TIFR), Bangalore - India) </p>\n	3	0			f	2
88	88	494f41a8f4ae2a1654d067a05d0e11fe	2011-09-06 14:37:42.953-04	2010-03-05 16:59:48.507-05						3	0			f	2
89	89	6987baa9e233a80bea470fa56df7f1f1	2011-11-07 23:26:39.04-05	2010-03-06 02:42:33.603-05	Bethesda, MD	http://stackoverflow.com/users/163080			<p>Bioinformatics research of brain tumor, mostly with MATLAB. </p>\n	3	0			f	2
90	90	748035f1fd58d4cc501af44d8eda11d9	2011-10-14 04:50:24.157-04	2010-03-06 06:12:19.247-05						3	0			f	2
91	91	65590dcbf0a8db1225f8e957594cd9eb	2011-11-07 23:17:24.01-05	2010-03-06 15:53:00.37-05	Stockholm	http://followthedata.wordpress.com			<p>twitter.com/mikaelhuss</p>\n	3	0			f	2
92	92	5b081e155365f6672e117f84556fb4a9	2011-11-01 21:42:19.24-04	2010-03-06 16:35:50.63-05	philadelphia	http://hostpathogen.blogspot.com/			<p>genomics &amp; computational biology student @ Upenn</p>\n	3	0			f	2
93	93	23394d913db5af989f0f3486b48e9081	2010-03-06 17:01:05.29-05	2010-03-06 17:01:05.29-05						3	0			f	2
94	94	4ccceae86eb24fc2c5b37320c7d32fe0	2010-06-13 11:58:45.87-04	2010-03-06 18:26:09.143-05		http://rosettadesigngroup.com/blog/				3	0			f	2
95	95	0b2b43d8271a1da6584bfc4803b5c7f4	2011-10-06 20:30:25.4-04	2010-03-06 18:49:08.633-05	DC Metro Area	http://in.tegr.in			<p>Proven and highly competent engineer, biotechnology manager, and entrepreneur with over 8 years experience in providing intuitive project management, professional leadership, and deep technical understanding on a wide variety of biotechnology and web based projects.</p>\n	3	0			f	2
96	96	d3e67a927b2ad89ca1385868756421f2	2010-04-14 20:10:50.287-04	2010-03-06 19:07:27.297-05						3	0			f	2
97	97	9769659781d9111ddc2deaa67fcf4027	2010-04-27 23:33:36.557-04	2010-03-06 19:14:15.883-05		http://noble.gs.washington.edu/~mmh1/				3	0			f	2
98	98	1299ef07318c56f99580ad79edfeb8fe	2010-03-13 17:41:08.86-05	2010-03-06 19:20:20.613-05						3	0			f	2
99	99	2826f262603fe76fe05c1d461c1667ec	2011-11-08 11:10:20.983-05	2010-03-06 19:20:28.96-05	Cambridge, UK	http://sites.google.com/site/avilella			<p>I am at the Vertebrate Genomics team at EMBL-EBI in Cambridge, UK.</p>\n	3	0			f	2
100	100	c7d6b57e3851503cf47bafe0d32f82ea	2010-03-06 20:03:07.767-05	2010-03-06 20:03:07.767-05						3	0			f	2
101	101	890350a827fe46c378b6f8ecc7d08288	2014-05-09 10:39:23.925-04	2014-05-09 10:39:23.887-04						3	0			f	2
\.


--
-- Name: users_profile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('users_profile_id_seq', 101, true);


--
-- Data for Name: users_profile_tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY users_profile_tags (id, profile_id, tag_id) FROM stdin;
1	2	1
2	2	2
\.


--
-- Name: users_profile_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('users_profile_tags_id_seq', 2, true);


--
-- Data for Name: users_tag; Type: TABLE DATA; Schema: public; Owner: -
--

COPY users_tag (id, name) FROM stdin;
1	galaxy
2	minia
\.


--
-- Name: users_tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('users_tag_id_seq', 2, true);


--
-- Data for Name: users_user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY users_user (id, password, last_login, email, name, is_active, is_admin, is_staff, type, status, new_messages, badges, score, flair, site_id, activity) FROM stdin;
1	pbkdf2_sha256$12000$v2BdZDmy8Jfc$yZWegbNUk0PzcZ63NzgXiNg5ihS9q044HUyhQvsf2KY=	2014-05-09 10:39:21.988-04	0@foo.bar	Biostar Community	t	t	t	2	0	0	0	0		\N	0
2	pbkdf2_sha256$12000$9qW2F403MdNC$uy0UGLln94XsxdeCW7p2t6KZjQJr9c++/3GNcmSux70=	2014-07-11 10:19:18.313-04	1@foo.bar	István Albert	t	t	t	2	0	0	0	31		\N	0
3	pbkdf2_sha256$12000$xqGT7BZNn52L$DF76wdfth9Ilt6EFSFzS6wQBCXIX5Kj1MTIgDACpVAQ=	2014-04-29 11:02:12.501-04	2@foo.bar	Fabio	t	f	f	0	0	0	0	3		\N	0
4	pbkdf2_sha256$12000$Z1gu7bXpsT18$H0PVT9g9wHv1rXF33iI9t1RXLnOfMTuKhrQF87WGT+Q=	2014-04-29 11:02:12.511-04	3@foo.bar	Jason	t	f	f	0	0	0	0	4		\N	0
5	pbkdf2_sha256$12000$SwQWheoe4DWR$HvnwzSF9zAbW5aJU6dtrWzNS8J/lFe2zLCpYnWqijeo=	2014-04-29 11:02:12.523-04	4@foo.bar	Zhenhai Zhang	t	f	f	0	0	0	0	5		\N	0
6	pbkdf2_sha256$12000$IwnuXfYFCYNv$CXiYg6rld/tNvdeV8NqSf0ItJ97GQ49TRqg0VCi/y+s=	2014-04-29 11:02:12.533-04	5@foo.bar	Tom Koerber	t	f	f	0	0	0	0	3		\N	0
7	pbkdf2_sha256$12000$xaF0RyplEZi4$Whthh+miHAbYU7U2INe2es99IZYVxq7C+jhtPAbLZfQ=	2014-04-29 11:02:12.544-04	6@foo.bar	Suk211	t	f	f	0	0	0	0	6		\N	0
8	pbkdf2_sha256$12000$SxrhjeItCyQ1$yjqCdyEXdvO51kFixpYqW7TbS7QElOP7nLncTlQdnp4=	2014-04-29 11:02:12.557-04	7@foo.bar	Lemon	t	f	f	0	0	0	0	0		\N	0
9	pbkdf2_sha256$12000$Vu6vHv0Y8ESx$OVkoCTV63vFwqmtPsCM51/iotQuhTpyXFiZ00/U5ib8=	2014-04-29 11:02:12.567-04	8@foo.bar	Wubin Qu	t	f	f	0	0	0	0	0		\N	0
10	pbkdf2_sha256$12000$TYnrt8Pwmqgr$S9uwfgPmu6vu+LlQhaqcOUx0Vj4xP6M2BZuTyEjFwFI=	2014-04-29 11:02:12.593-04	9@foo.bar	Question Bot	t	f	f	0	0	0	0	9		\N	0
11	pbkdf2_sha256$12000$DP8rjojyp3ym$brpmrCliVz8cxtK3Q4htFEvp0HiZ5oVCxJNNiTDycQI=	2014-04-29 11:02:12.604-04	10@foo.bar	Reka Albert	t	f	f	0	0	0	0	0		\N	0
12	pbkdf2_sha256$12000$7LJjneJylACC$jEfYvVuRJkRfxShN4AAg1P1hj5iMVbTZ4dUkqANKQJw=	2014-04-29 11:02:12.614-04	11@foo.bar	Yang Yang	t	f	f	0	0	0	0	2		\N	0
13	pbkdf2_sha256$12000$d3mQ7EHUwv8k$INmswQ2vy3R28ssBIinn57i1+pget6ySCtyl6wBJIhQ=	2014-04-29 11:02:12.624-04	12@foo.bar	Gue Su Chang	t	f	f	0	0	0	0	1		\N	0
14	pbkdf2_sha256$12000$UFdLVdfM370I$xRLXWq+VifVfvm1k1WVVstwAsFVGQg9NJ231TrZHHlQ=	2014-04-29 11:02:12.636-04	13@foo.bar	Zhaorong	t	f	f	0	0	0	0	3		\N	0
15	pbkdf2_sha256$12000$UGNyzHAtnIIJ$VEihUmGm7q5/t/SJvGH9mQPdJixOSoHfljXmkLPbpME=	2014-04-29 11:02:12.647-04	14@foo.bar	Nickey	t	f	f	0	0	0	0	0		\N	0
16	pbkdf2_sha256$12000$aAZZkAtIP7Jj$0LSKb3p9fj5E7nA9w4LNfZydc/hxVueV9gu7iP5supg=	2014-04-29 11:02:12.657-04	15@foo.bar	Renee	t	f	f	0	0	0	0	4		\N	0
17	pbkdf2_sha256$12000$3CYqycQ4Q5WR$eUqkXV/SL8aNDpEdQWo3dhP1mVVK6do/l4+I/yCSBVs=	2014-04-29 11:02:12.667-04	16@foo.bar	Yu	t	f	f	0	0	0	0	0		\N	0
18	pbkdf2_sha256$12000$WO7H69aEV4Jf$fnZc5IEgOeJeN2H1YB7FIbXvvUc97uJM6P3Yw1vtH58=	2014-04-29 11:02:12.678-04	17@foo.bar	Gue Su	t	f	f	0	0	0	0	2		\N	0
19	pbkdf2_sha256$12000$PacGBxydNG0r$JVZGO6FB/BP0NG7OOEpL5O9SmdYsVLDvaD8q89f9y/0=	2014-04-29 11:02:12.688-04	18@foo.bar	Mohammed Islaih	t	f	f	0	0	0	0	2		\N	0
20	pbkdf2_sha256$12000$XZn3ks7DOKGZ$GDtouW5TBZHUXEKGD16ZhZp4GFbLm2X30iyfOprsluk=	2014-04-29 11:02:12.699-04	19@foo.bar	Alex Reynolds	t	f	f	0	0	0	0	3		\N	0
21	pbkdf2_sha256$12000$RV0TJKXavHsA$4SMx6RZDGt+IRFM8cfO4iCF0V2Zey6CFs6ZQz5dTZ+8=	2014-04-29 11:02:12.709-04	20@foo.bar	User 4824	t	f	f	0	0	0	0	0		\N	0
22	pbkdf2_sha256$12000$TGHwkQ27LkJY$SLTaMKnA7rVy1PlmzwSvcKYgxQdnqAegWLgTBc+3Yb8=	2014-04-29 11:02:12.72-04	21@foo.bar	User 8226	t	f	f	0	0	0	0	0		\N	0
23	pbkdf2_sha256$12000$jSlUQQpIg4zj$1cdW2BEvDSoQO7VdIixeeh6jseW+FZ4+nts2bL3f+so=	2014-04-29 11:02:12.73-04	22@foo.bar	Giovanni M Dall'Olio	t	f	f	1	0	0	0	42		\N	0
24	pbkdf2_sha256$12000$BcCBGGTRvXC8$3dY0tHjT+vLEQXDwx8zZkVRqLCBJiON1libTle8Z6kg=	2014-04-29 11:02:12.741-04	23@foo.bar	Etal	t	f	f	0	0	0	0	7		\N	0
25	pbkdf2_sha256$12000$sU81PW5xrTAc$Cu1cFi8pC7c7JfvKlBG2NR27NZTxVAWGFnQuHcsdhkE=	2014-04-29 11:02:12.751-04	24@foo.bar	Fabio	t	f	f	0	0	0	0	3		\N	0
26	pbkdf2_sha256$12000$qDuHhjKVFp2x$o+1KCGLxR1RxvsQLYdD5EOegHqJBJ2IGEFfuEwXWGTU=	2014-04-29 11:02:12.762-04	25@foo.bar	Nicojo	t	f	f	0	0	0	0	4		\N	0
27	pbkdf2_sha256$12000$rpHuwl7MGZwL$gjhNqj0Gm8HbYfne58W7JRjL1po8ozsmJIiWlF5EduE=	2014-04-29 11:02:12.772-04	26@foo.bar	Allen Yu	t	f	f	0	0	0	0	2		\N	0
28	pbkdf2_sha256$12000$oefum8WgLYIN$1unCCIKuvSLoqZkxQ6em9I/NJHraQ8yLUmi5lhM/vEs=	2014-04-29 11:02:12.783-04	27@foo.bar	Curious George	t	f	f	0	0	0	0	1		\N	0
29	pbkdf2_sha256$12000$8midSx7wjeGU$IfZR7wT3MSkPHgacZLi5MWwN81JQv4B6J1p0JndWAn8=	2014-04-29 11:02:12.794-04	28@foo.bar	User 5034	t	f	f	0	0	0	0	0		\N	0
30	pbkdf2_sha256$12000$dSeZRnZnMkzj$wv9nFF850xquM59gEVATa/KkwCtK58BRqlGkSxaefuU=	2014-04-29 11:02:12.805-04	29@foo.bar	Pierre Lindenbaum	t	f	f	2	0	0	0	14		\N	0
31	pbkdf2_sha256$12000$rr6pEmRIEIfw$100XyJOPNkv6JQq0s8xtKK8b7SfLwtksX79qIstbvoU=	2014-04-29 11:02:12.818-04	30@foo.bar	Marcos De Carvalho	t	f	f	0	0	0	0	2		\N	0
32	pbkdf2_sha256$12000$ucdVBO0w9Q7x$Y/mNxoczSRUjJh4+hoUXAGwWJ2i0SMQ6JHkcI4TWwmg=	2014-04-29 11:02:12.83-04	31@foo.bar	Gustavo Costa	t	f	f	0	0	0	0	0		\N	0
33	pbkdf2_sha256$12000$gTEz50VxJxaZ$sj9mydOzXDyzOiepgCiwPhCykRX/bP5i4yUutRnrzUY=	2014-04-29 11:02:12.843-04	32@foo.bar	User 6996	t	f	f	0	0	0	0	4		\N	0
34	pbkdf2_sha256$12000$cM7kWfGaJeVr$za66sGNevXz7UloqJa/2xypORg0Fm77IOja8jR4xQ/A=	2014-04-29 11:02:12.854-04	33@foo.bar	Paul J. Davis	t	f	f	0	0	0	0	0		\N	0
35	pbkdf2_sha256$12000$rVA0q56nigPV$fsadUORb/D6dv07j4+SIl6X0Wc7yzQUI0E055kOC0Xk=	2014-04-29 11:02:12.865-04	34@foo.bar	David Nusinow	t	f	f	0	0	0	0	5		\N	0
36	pbkdf2_sha256$12000$4HL5CgiPM0Ia$UcCiPS0N5ms3GTZcEMG6POoveHPTVvsK4TYDMlUh2UM=	2014-04-29 11:02:12.875-04	35@foo.bar	Brentp	t	f	f	1	0	0	0	0		\N	0
37	pbkdf2_sha256$12000$UiIfoDJ8bguC$FPwE36HFeY8gkRIK7hzWfXq9BEP36r27jO1b8BI171g=	2014-04-29 11:02:12.889-04	36@foo.bar	Razor	t	f	f	0	0	0	0	0		\N	0
38	pbkdf2_sha256$12000$XYu644JYsxBc$heTzCxR2nE/JPyMYDGy3fJspZGNjlPI0UOjcfLj+ikQ=	2014-04-29 11:02:12.9-04	37@foo.bar	Simon Cockell	t	f	f	1	0	0	0	5		\N	0
39	pbkdf2_sha256$12000$0e4xhDyZn6UG$8i4EfdOsZhoYVRSN5ivW7VkANmJ8TU+qkCtnURQsyAE=	2014-04-29 11:02:12.913-04	38@foo.bar	Konrad	t	f	f	0	0	0	0	2		\N	0
40	pbkdf2_sha256$12000$UwqlVm0drwGy$ym7Fmfkf2gjJePr3LdGwF0EDlwYGNkboHUcdwI5ZXYU=	2014-04-29 11:02:12.924-04	39@foo.bar	Biorelated	t	f	f	0	0	0	0	2		\N	0
41	pbkdf2_sha256$12000$tS2yyrECUCWR$KkpIVlCmMJsgrXy840Y4NLznKjt+znVNyH6LRtnQd1U=	2014-04-29 11:02:12.934-04	40@foo.bar	Yann Abraham	t	f	f	0	0	0	0	0		\N	0
42	pbkdf2_sha256$12000$UR24VGeEwAYn$rJgvCgqhgKWU7avwI8oqxDrXkSBR3f+dmW61snodUT4=	2014-04-29 11:02:12.948-04	41@foo.bar	Fernando Muñiz	t	f	f	0	0	0	0	6		\N	0
43	pbkdf2_sha256$12000$TAnq0LpvHxen$fBlD33enZF59h6Ow1kh5DZ5T5EvAEGGm44PWvQWtXJY=	2014-04-29 11:02:12.959-04	42@foo.bar	User 1402	t	f	f	0	0	0	0	0		\N	0
44	pbkdf2_sha256$12000$QSevRLvHj4fs$/EyGRPMnRfQgKJpqvQdG3FrlVNmDN/xyQVs2IqB0V4Q=	2014-04-29 11:02:12.969-04	43@foo.bar	Andrew	t	f	f	0	0	0	0	1		\N	0
45	pbkdf2_sha256$12000$xgfjPCTBuZh4$vwYrG3WezuinPOLeYW7gnTOkxpkXRQTFz0cwzCCvCi8=	2014-04-29 11:02:12.98-04	44@foo.bar	Alex	t	f	f	0	0	0	0	1		\N	0
46	pbkdf2_sha256$12000$8dLFyZZD7biT$YLgRWfpWkKC9cYoaWWJMbUI5vBCacdIvGsCJDJ4BF7g=	2014-04-29 11:02:12.99-04	45@foo.bar	Owen	t	f	f	0	0	0	0	0		\N	0
47	pbkdf2_sha256$12000$oMoTXWGRFHP1$hMcQDKHlOrbUu7zFhv6qFxFdKctwFiVxxBm0kt6wsjw=	2014-04-29 11:02:13.001-04	46@foo.bar	Chris	t	f	f	0	0	0	0	3		\N	0
48	pbkdf2_sha256$12000$9v2mWmQ7WHfC$6gm9/LF+awSRyswDAww4ZscmbMuS9BMN1uQIZgwvYfM=	2014-04-29 11:02:13.013-04	47@foo.bar	Kelly O.	t	f	f	0	0	0	0	0		\N	0
49	pbkdf2_sha256$12000$Kpd2XLAgDrsw$7tf44RV/4+HTOl+93LnTtfXkliIwIEsIXXhX6c6TGkU=	2014-04-29 11:02:13.023-04	48@foo.bar	User 3704	t	f	f	0	0	0	0	0		\N	0
50	pbkdf2_sha256$12000$cfxefsjduUzM$3E/1A3nxt/kKCMFMut+QbKd4V9l1LQs65IQrfRUA+LE=	2014-04-29 11:02:13.034-04	49@foo.bar	Greg	t	f	f	0	0	0	0	0		\N	0
51	pbkdf2_sha256$12000$SvRMm9waJ3qO$hCkfgGmYn/VIVwvNMc3BnUnMdDFnVa9g76n/u+DEtGA=	2014-04-29 11:02:13.046-04	50@foo.bar	Pedrobeltrao	t	f	f	0	0	0	0	0		\N	0
52	pbkdf2_sha256$12000$aOGcLeQEfIPn$sQdkkKJWC72P1zoBmddxLQDxl+3iqUYgHYhXHc0/nCQ=	2014-04-29 11:02:13.06-04	51@foo.bar	Liam Thompson	t	f	f	0	0	0	0	0		\N	0
53	pbkdf2_sha256$12000$FBhI1GpNgZrO$5cu8QS477St6WFya4dIkVurUxHqG2zRSd6PmlHP1Skg=	2014-04-29 11:02:13.072-04	52@foo.bar	Michael Barton	t	f	f	0	0	0	0	3		\N	0
54	pbkdf2_sha256$12000$cHejL2WNI43X$XgstVRHdIe1waNfCkzfanSyMSUm30Gg+Ms+vG1/Pn70=	2014-04-29 11:02:13.085-04	53@foo.bar	Schrodinger'S Cat	t	f	f	0	0	0	0	0		\N	0
55	pbkdf2_sha256$12000$sZbNI0zC2u60$08s9CquCBfOMyn1w+kc+R4PjxOokxh0E+70xgBo7x3Q=	2014-04-29 11:02:13.096-04	54@foo.bar	Michael Dondrup	t	f	f	1	0	0	0	5		\N	0
56	pbkdf2_sha256$12000$UvODgEajtzmh$TdOr4eJywyT+W4gx5dCze+t4Vll+6/VGEJVvglYD1p0=	2014-04-29 11:02:13.109-04	55@foo.bar	Brad Chapman	t	f	f	1	0	0	0	0		\N	0
57	pbkdf2_sha256$12000$ZgG779ob86Sl$wl94Aq/66lmyn6YMQgP9AC7HsdjY7pcM9TtPIvT58yQ=	2014-04-29 11:02:13.121-04	56@foo.bar	Paulati	t	f	f	0	0	0	0	0		\N	0
58	pbkdf2_sha256$12000$ov8ArYAwjJlr$gFUKnAYbkeDj1EvlljR/BN+Zn5kDv+jDHCjJfKSGMCo=	2014-04-29 11:02:13.134-04	57@foo.bar	Dave Bridges	t	f	f	0	0	0	0	0		\N	0
59	pbkdf2_sha256$12000$tFSFE4jMaOJ8$+PMRrl7qwOac8w1K7q+nJIdHg93uwTBYaMAa9corEJQ=	2014-04-29 11:02:13.144-04	58@foo.bar	Daniel Swan	t	f	f	1	0	0	0	2		\N	0
60	pbkdf2_sha256$12000$IXzi1Xn9Czas$1NrrU+G+MTc17HHHbiWfCM+q3C+O+Z4CDzdQnIPQ7os=	2014-04-29 11:02:13.16-04	59@foo.bar	Lukfor	t	f	f	0	0	0	0	0		\N	0
61	pbkdf2_sha256$12000$3m6Wp5oeGCz6$rCsr8gIYXKR1TYd32eL+w4tqMair81M8LBimwEqrSs0=	2014-04-29 11:02:13.171-04	60@foo.bar	Chris Fields	t	f	f	0	0	0	0	0		\N	0
62	pbkdf2_sha256$12000$x6BrtZZDJNDF$NE75vuPcXt5No5fbfRVCE2WEO1TrmNTpL7ESAODtMow=	2014-04-29 11:02:13.184-04	61@foo.bar	Darked89	t	f	f	1	0	0	0	0		\N	0
63	pbkdf2_sha256$12000$sH5jvrYb2vyn$PZ2A17ssUR0fvm+mq0ThBgB4Ih9EMaXmRSwzCNvynkE=	2014-04-29 11:02:13.195-04	62@foo.bar	Lmartinho	t	f	f	0	0	0	0	0		\N	0
64	pbkdf2_sha256$12000$4UaQ3C3diXy5$SwjuVgnbHwBzmiPFQfSCpct1a7YQIMYXaOuPqaJEwD4=	2014-04-29 11:02:13.206-04	63@foo.bar	Manuel Corpas	t	f	f	0	0	0	0	0		\N	0
65	pbkdf2_sha256$12000$qAFmBJPZgTSh$xgnqaXKc7bPecKLtMUPa/Ea4kXRmiUIaIcB58uuG72c=	2014-04-29 11:02:13.22-04	64@foo.bar	Abhishek Tiwari	t	f	f	0	0	0	0	0		\N	0
66	pbkdf2_sha256$12000$3uS5mmrfxsYn$uPZoPv/tgqDF6OCrKeUwxiwfDAQlpRchJwYtvZyiYWA=	2014-04-29 11:02:13.245-04	65@foo.bar	Neilfws	t	f	f	2	0	0	0	0		\N	0
67	pbkdf2_sha256$12000$EVvOhIOv8eQP$1ygCXtMXg7OzNdvvgKPoF4+jEGAeosXzxRDjNf1E2UE=	2014-04-29 11:02:13.267-04	66@foo.bar	Piotr Byzia	t	f	f	0	0	0	0	0		\N	0
68	pbkdf2_sha256$12000$KD1LVVbEXmTR$FTjcxzC/7zXXG6NLWc1Uh2lN0HWL1SFVIFAue6REWJc=	2014-04-29 11:02:13.281-04	67@foo.bar	Jeroen Van Goey	t	f	f	0	0	0	0	0		\N	0
69	pbkdf2_sha256$12000$QqzZpb87JWKo$AJUgGmiNCwHEBjZxllvCsIU/ZqlZNSkZz733vv5nr9s=	2014-04-29 11:02:13.296-04	68@foo.bar	Vince	t	f	f	0	0	0	0	0		\N	0
70	pbkdf2_sha256$12000$6AKEk1eW77tA$ncxfHiq7OJMq9S6ewqtYmt5K6tm6Agt0yLtW53Iawro=	2014-04-29 11:02:13.306-04	69@foo.bar	Tom Walsh	t	f	f	0	0	0	0	0		\N	0
71	pbkdf2_sha256$12000$xIbUkiEIEySs$k6+6hPRRD4NEM9xJ0hig0PIf6koGHRtg7QO0DVpQCRw=	2014-04-29 11:02:13.333-04	70@foo.bar	Egon Willighagen	t	f	f	1	0	0	0	0		\N	0
72	pbkdf2_sha256$12000$ofoMoq3WABGc$cjeS/IWd0EnaEPNejlepL4DqHm3ad0QzRISAffTXEps=	2014-04-29 11:02:13.349-04	71@foo.bar	Mndoci	t	f	f	0	0	0	0	0		\N	0
73	pbkdf2_sha256$12000$5vXXOzn7tPKn$1UQvXBDX6kmkfoypsARwqPYNrPPUB49c6pfpHT+MmKU=	2014-04-29 11:02:13.365-04	72@foo.bar	Jeremy Leipzig	t	f	f	1	0	0	0	0		\N	0
74	pbkdf2_sha256$12000$MGJpwYIMsQOi$I9JWhUxQRmBgcCMP2DdmKKsJtEkEKyQ/3vhsFwyemHQ=	2014-04-29 11:02:13.38-04	73@foo.bar	Mmarchin	t	f	f	0	0	0	0	0		\N	0
75	pbkdf2_sha256$12000$92BQz3pwTcOO$d411VgY6cCq7qlfNeJwpsVYZ/JT1kWlASIPkhmDIZa8=	2014-04-29 11:02:13.391-04	74@foo.bar	Paolo	t	f	f	0	0	0	0	0		\N	0
76	pbkdf2_sha256$12000$gasAz3kX8aXj$ev2WyN9ZaByNLTIOKZEceYNv6i5IaGoUHAcXZHdIjJU=	2014-04-29 11:02:13.404-04	75@foo.bar	Andrew	t	f	f	0	0	0	0	0		\N	0
77	pbkdf2_sha256$12000$DUN1fMdrF2SR$5ODQ4g1j7p7UzPEe/6W/CKpUGKTQzRYhfcfIAOMmq34=	2014-04-29 11:02:13.415-04	76@foo.bar	Eleanor Howe	t	f	f	0	0	0	0	0		\N	0
78	pbkdf2_sha256$12000$FIXFvfZQTS83$kBWJNjwh8cVMkuvqAtG0oo61pknQBCaGMYLQRw1SfP4=	2014-04-29 11:02:13.434-04	77@foo.bar	Jboveda	t	f	f	0	0	0	0	0		\N	0
79	pbkdf2_sha256$12000$WveuTv2dX7iJ$YoRcZ18ysiR//FFmii4emIPwyIHwznlZYTtvUt4ngZM=	2014-04-29 11:02:13.446-04	78@foo.bar	Tim	t	f	f	0	0	0	0	0		\N	0
80	pbkdf2_sha256$12000$NBngO2uzk6y7$wSXv00L+6yWPOzCQ/knWe44Xox+suvhecOWnhiHSWE4=	2014-04-29 11:02:13.458-04	79@foo.bar	Daniel Jurczak	t	f	f	0	0	0	0	0		\N	0
81	pbkdf2_sha256$12000$O8oYZpiqY314$Y6irPwDq8N1/GIgL2lOgLo5tnOUNSVEr7pokJ/clBjM=	2014-04-29 11:02:13.468-04	80@foo.bar	User 1073	t	f	f	0	0	0	0	0		\N	0
82	pbkdf2_sha256$12000$anjIFGaJSxcl$YLL2Xw+QHLh98mN48ENGLVJUMiyNGj01FAjNnutiing=	2014-04-29 11:02:13.482-04	81@foo.bar	Geoffjentry	t	f	f	0	0	0	0	0		\N	0
83	pbkdf2_sha256$12000$2Hwvgl2XRACg$pcBjf8kPDB/ShYNp47laLenjOwTgayb025LOdKWGffE=	2014-04-29 11:02:13.495-04	82@foo.bar	User 3505	t	f	f	0	0	0	0	0		\N	0
84	pbkdf2_sha256$12000$0gD5k5pLyFMU$VBeYrroiSSoL9+w4n/XGdYMi3PLwTQqyfgrKzT6CLV8=	2014-04-29 11:02:13.506-04	83@foo.bar	Anshu	t	f	f	0	0	0	0	0		\N	0
85	pbkdf2_sha256$12000$F49036a6RZu5$WBS83LIKcm535yw2noIhyGKQBqv/ndxk1M9lk8Q2GXk=	2014-04-29 11:02:13.517-04	84@foo.bar	Bryan Maloney	t	f	f	0	0	0	0	0		\N	0
86	pbkdf2_sha256$12000$xLzfu0zOdYgl$g/avnMo0wkDs7FKwnSvCMW5Nn0NopGKmN9FPA8rmo+s=	2014-04-29 11:02:13.53-04	85@foo.bar	Andrew Su	t	f	f	1	0	0	0	0		\N	0
87	pbkdf2_sha256$12000$f7DHaswt7bGg$dXRcjhjmUCyeZlESq0Hi4Orl+L62CYdZa3Zcnfq5MIM=	2014-04-29 11:02:13.542-04	86@foo.bar	Khader Shameer	t	f	f	1	0	0	0	0		\N	0
88	pbkdf2_sha256$12000$erfcUO9QwlNF$JRt/ogMgZPkFqf2POlVqqtTFNCzG1PcJ8MBfv+VABKo=	2014-04-29 11:02:13.554-04	87@foo.bar	Pierre	t	f	f	0	0	0	0	0		\N	0
89	pbkdf2_sha256$12000$cewFu6xQ6Ae1$z95BGoh2E+Yh3Tl3JDWa2+0Tn34XYdvOLvga4ckhJF4=	2014-04-29 11:02:13.575-04	88@foo.bar	Yuri	t	f	f	0	0	0	0	0		\N	0
90	pbkdf2_sha256$12000$7oJ63SMrqkmL$2QilTjsJg7+R8oFbsjFA3TkzLbt6TdvrU4VYe3Dbei0=	2014-04-29 11:02:13.588-04	89@foo.bar	Allpowerde	t	f	f	0	0	0	0	0		\N	0
91	pbkdf2_sha256$12000$QjVJyGehvQXY$NCGKqDQirpXrxN67pAng7cw5yMmrpB2BJ2C7NN2Nuao=	2014-04-29 11:02:13.613-04	90@foo.bar	Mikael Huss	t	f	f	0	0	0	0	0		\N	0
92	pbkdf2_sha256$12000$qkRsBi11opyj$Kb3rMqW1yIuA9X6+LxeJtFS5+cdurftyTBGT3jfHvDA=	2014-04-29 11:02:13.632-04	91@foo.bar	Perry	t	f	f	0	0	0	0	0		\N	0
93	pbkdf2_sha256$12000$vTS5D5OcYAny$oztMskBK5ZezMRW9JLWvhuZ1zsLbnuDVtrbi0Tt2WWw=	2014-04-29 11:02:13.649-04	92@foo.bar	User 5106	t	f	f	0	0	0	0	0		\N	0
94	pbkdf2_sha256$12000$rzaCSA5TUvNf$9+5WN/Egbq8Y8IB4Weoc+yVEKGarBg0PntbJEAT4AXM=	2014-04-29 11:02:13.662-04	93@foo.bar	Nir London	t	f	f	0	0	0	0	0		\N	0
95	pbkdf2_sha256$12000$cqZGG8CKNJQj$qb8AEKQGWLd6p6maQ7zQ8+0QpCEBToYPwsPYJiYid64=	2014-04-29 11:02:13.683-04	94@foo.bar	Bioinfo	t	f	f	0	0	0	0	0		\N	0
96	pbkdf2_sha256$12000$V4ZiZxoOxTfu$0d2e6vFap5TYkCvpXuLcMINZ4SFXNns2ojxsLPYpXhc=	2014-04-29 11:02:13.695-04	95@foo.bar	Jc	t	f	f	0	0	0	0	0		\N	0
97	pbkdf2_sha256$12000$dNsbB7ejmsyG$E0QUnPMyuHjx48eZjoDiOg2JO+vrdX6TpP3DBWBD+FQ=	2014-04-29 11:02:13.712-04	96@foo.bar	Michael Hoffman	t	f	f	0	0	0	0	0		\N	0
98	pbkdf2_sha256$12000$2RaQnkNvUKyH$puGanmv6F/QUs592SbpkRx8yvyQdhXG6PgV3pwGmzkM=	2014-04-29 11:02:13.732-04	97@foo.bar	Nancy Parmalee	t	f	f	0	0	0	0	0		\N	0
99	pbkdf2_sha256$12000$2FTVddwp9Hty$ILbwZtEYc50AVQBkQACUYk3d8h3nxmVWl0ufjUQhFQs=	2014-04-29 11:02:13.743-04	98@foo.bar	Avilella	t	f	f	0	0	0	0	0		\N	0
100	pbkdf2_sha256$12000$MSN9hQi1fryA$Nhp6n8kOq0HQD40WO5pCWWJyi8IpDdimWgv+ErlLHr0=	2014-04-29 11:02:13.768-04	99@foo.bar	Ryan	t	f	f	0	0	0	0	0		\N	0
101	pbkdf2_sha256$12000$2E3GGcg1ofYT$QeUtTdcst73E0+5l6vtr+ueP1qmL11ca0aKEyJRg6Zc=	2014-05-09 10:39:23.915-04	100@foo.bar	john	t	f	f	0	0	0	0	0		\N	0
\.


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('users_user_id_seq', 101, true);


--
-- Name: account_emailaddress_email_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY account_emailaddress
    ADD CONSTRAINT account_emailaddress_email_key UNIQUE (email);


--
-- Name: account_emailaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY account_emailaddress
    ADD CONSTRAINT account_emailaddress_pkey PRIMARY KEY (id);


--
-- Name: account_emailconfirmation_key_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY account_emailconfirmation
    ADD CONSTRAINT account_emailconfirmation_key_key UNIQUE (key);


--
-- Name: account_emailconfirmation_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY account_emailconfirmation
    ADD CONSTRAINT account_emailconfirmation_pkey PRIMARY KEY (id);


--
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions_group_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_key UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission_content_type_id_codename_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_key UNIQUE (content_type_id, codename);


--
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: badges_award_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY badges_award
    ADD CONSTRAINT badges_award_pkey PRIMARY KEY (id);


--
-- Name: badges_badge_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY badges_badge
    ADD CONSTRAINT badges_badge_pkey PRIMARY KEY (id);


--
-- Name: celery_taskmeta_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY celery_taskmeta
    ADD CONSTRAINT celery_taskmeta_pkey PRIMARY KEY (id);


--
-- Name: celery_taskmeta_task_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY celery_taskmeta
    ADD CONSTRAINT celery_taskmeta_task_id_key UNIQUE (task_id);


--
-- Name: celery_tasksetmeta_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY celery_tasksetmeta
    ADD CONSTRAINT celery_tasksetmeta_pkey PRIMARY KEY (id);


--
-- Name: celery_tasksetmeta_taskset_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY celery_tasksetmeta
    ADD CONSTRAINT celery_tasksetmeta_taskset_id_key UNIQUE (taskset_id);


--
-- Name: django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type_app_label_model_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_key UNIQUE (app_label, model);


--
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_flatpage_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY django_flatpage
    ADD CONSTRAINT django_flatpage_pkey PRIMARY KEY (id);


--
-- Name: django_flatpage_sites_flatpage_id_site_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY django_flatpage_sites
    ADD CONSTRAINT django_flatpage_sites_flatpage_id_site_id_key UNIQUE (flatpage_id, site_id);


--
-- Name: django_flatpage_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY django_flatpage_sites
    ADD CONSTRAINT django_flatpage_sites_pkey PRIMARY KEY (id);


--
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: djcelery_crontabschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY djcelery_crontabschedule
    ADD CONSTRAINT djcelery_crontabschedule_pkey PRIMARY KEY (id);


--
-- Name: djcelery_intervalschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY djcelery_intervalschedule
    ADD CONSTRAINT djcelery_intervalschedule_pkey PRIMARY KEY (id);


--
-- Name: djcelery_periodictask_name_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY djcelery_periodictask
    ADD CONSTRAINT djcelery_periodictask_name_key UNIQUE (name);


--
-- Name: djcelery_periodictask_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY djcelery_periodictask
    ADD CONSTRAINT djcelery_periodictask_pkey PRIMARY KEY (id);


--
-- Name: djcelery_periodictasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY djcelery_periodictasks
    ADD CONSTRAINT djcelery_periodictasks_pkey PRIMARY KEY (ident);


--
-- Name: djcelery_taskstate_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY djcelery_taskstate
    ADD CONSTRAINT djcelery_taskstate_pkey PRIMARY KEY (id);


--
-- Name: djcelery_taskstate_task_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY djcelery_taskstate
    ADD CONSTRAINT djcelery_taskstate_task_id_key UNIQUE (task_id);


--
-- Name: djcelery_workerstate_hostname_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY djcelery_workerstate
    ADD CONSTRAINT djcelery_workerstate_hostname_key UNIQUE (hostname);


--
-- Name: djcelery_workerstate_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY djcelery_workerstate
    ADD CONSTRAINT djcelery_workerstate_pkey PRIMARY KEY (id);


--
-- Name: djkombu_message_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY djkombu_message
    ADD CONSTRAINT djkombu_message_pkey PRIMARY KEY (id);


--
-- Name: djkombu_queue_name_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY djkombu_queue
    ADD CONSTRAINT djkombu_queue_name_key UNIQUE (name);


--
-- Name: djkombu_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY djkombu_queue
    ADD CONSTRAINT djkombu_queue_pkey PRIMARY KEY (id);


--
-- Name: messages_message_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY messages_message
    ADD CONSTRAINT messages_message_pkey PRIMARY KEY (id);


--
-- Name: messages_messagebody_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY messages_messagebody
    ADD CONSTRAINT messages_messagebody_pkey PRIMARY KEY (id);


--
-- Name: planet_blog_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY planet_blog
    ADD CONSTRAINT planet_blog_pkey PRIMARY KEY (id);


--
-- Name: planet_blogpost_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY planet_blogpost
    ADD CONSTRAINT planet_blogpost_pkey PRIMARY KEY (id);


--
-- Name: posts_emailentry_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY posts_emailentry
    ADD CONSTRAINT posts_emailentry_pkey PRIMARY KEY (id);


--
-- Name: posts_emailsub_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY posts_emailsub
    ADD CONSTRAINT posts_emailsub_pkey PRIMARY KEY (id);


--
-- Name: posts_post_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY posts_post
    ADD CONSTRAINT posts_post_pkey PRIMARY KEY (id);


--
-- Name: posts_post_tag_set_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY posts_post_tag_set
    ADD CONSTRAINT posts_post_tag_set_pkey PRIMARY KEY (id);


--
-- Name: posts_post_tag_set_post_id_3a89bc0be4aa7531_uniq; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY posts_post_tag_set
    ADD CONSTRAINT posts_post_tag_set_post_id_3a89bc0be4aa7531_uniq UNIQUE (post_id, tag_id);


--
-- Name: posts_postview_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY posts_postview
    ADD CONSTRAINT posts_postview_pkey PRIMARY KEY (id);


--
-- Name: posts_replytoken_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY posts_replytoken
    ADD CONSTRAINT posts_replytoken_pkey PRIMARY KEY (id);


--
-- Name: posts_subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY posts_subscription
    ADD CONSTRAINT posts_subscription_pkey PRIMARY KEY (id);


--
-- Name: posts_subscription_user_id_769daec75342239c_uniq; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY posts_subscription
    ADD CONSTRAINT posts_subscription_user_id_769daec75342239c_uniq UNIQUE (user_id, post_id);


--
-- Name: posts_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY posts_tag
    ADD CONSTRAINT posts_tag_pkey PRIMARY KEY (id);


--
-- Name: posts_vote_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY posts_vote
    ADD CONSTRAINT posts_vote_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialaccount_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialaccount_uid_5ac8b4eb459472be_uniq; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_uid_5ac8b4eb459472be_uniq UNIQUE (uid, provider);


--
-- Name: socialaccount_socialapp_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY socialaccount_socialapp
    ADD CONSTRAINT socialaccount_socialapp_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialapp_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_socialapp_sites_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialapp_sites_socialapp_id_711547c3e6a002b_uniq; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_socialapp_sites_socialapp_id_711547c3e6a002b_uniq UNIQUE (socialapp_id, site_id);


--
-- Name: socialaccount_socialtoken_app_id_697928748c2e1968_uniq; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_socialtoken_app_id_697928748c2e1968_uniq UNIQUE (app_id, account_id);


--
-- Name: socialaccount_socialtoken_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_socialtoken_pkey PRIMARY KEY (id);


--
-- Name: south_migrationhistory_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY south_migrationhistory
    ADD CONSTRAINT south_migrationhistory_pkey PRIMARY KEY (id);


--
-- Name: users_emaillist_email_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY users_emaillist
    ADD CONSTRAINT users_emaillist_email_key UNIQUE (email);


--
-- Name: users_emaillist_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY users_emaillist
    ADD CONSTRAINT users_emaillist_pkey PRIMARY KEY (id);


--
-- Name: users_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY users_profile
    ADD CONSTRAINT users_profile_pkey PRIMARY KEY (id);


--
-- Name: users_profile_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY users_profile_tags
    ADD CONSTRAINT users_profile_tags_pkey PRIMARY KEY (id);


--
-- Name: users_profile_tags_profile_id_5d76009bea85b5fd_uniq; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY users_profile_tags
    ADD CONSTRAINT users_profile_tags_profile_id_5d76009bea85b5fd_uniq UNIQUE (profile_id, tag_id);


--
-- Name: users_profile_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY users_profile
    ADD CONSTRAINT users_profile_user_id_key UNIQUE (user_id);


--
-- Name: users_profile_uuid_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY users_profile
    ADD CONSTRAINT users_profile_uuid_key UNIQUE (uuid);


--
-- Name: users_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY users_tag
    ADD CONSTRAINT users_tag_pkey PRIMARY KEY (id);


--
-- Name: users_user_email_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY users_user
    ADD CONSTRAINT users_user_email_key UNIQUE (email);


--
-- Name: users_user_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY users_user
    ADD CONSTRAINT users_user_pkey PRIMARY KEY (id);


--
-- Name: account_emailaddress_email_like; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX account_emailaddress_email_like ON account_emailaddress USING btree (email varchar_pattern_ops);


--
-- Name: account_emailaddress_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX account_emailaddress_user_id ON account_emailaddress USING btree (user_id);


--
-- Name: account_emailconfirmation_email_address_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX account_emailconfirmation_email_address_id ON account_emailconfirmation USING btree (email_address_id);


--
-- Name: account_emailconfirmation_key_like; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX account_emailconfirmation_key_like ON account_emailconfirmation USING btree (key varchar_pattern_ops);


--
-- Name: auth_group_name_like; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX auth_group_name_like ON auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX auth_group_permissions_group_id ON auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX auth_group_permissions_permission_id ON auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX auth_permission_content_type_id ON auth_permission USING btree (content_type_id);


--
-- Name: badges_award_badge_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX badges_award_badge_id ON badges_award USING btree (badge_id);


--
-- Name: badges_award_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX badges_award_user_id ON badges_award USING btree (user_id);


--
-- Name: celery_taskmeta_hidden; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX celery_taskmeta_hidden ON celery_taskmeta USING btree (hidden);


--
-- Name: celery_taskmeta_task_id_like; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX celery_taskmeta_task_id_like ON celery_taskmeta USING btree (task_id varchar_pattern_ops);


--
-- Name: celery_tasksetmeta_hidden; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX celery_tasksetmeta_hidden ON celery_tasksetmeta USING btree (hidden);


--
-- Name: celery_tasksetmeta_taskset_id_like; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX celery_tasksetmeta_taskset_id_like ON celery_tasksetmeta USING btree (taskset_id varchar_pattern_ops);


--
-- Name: django_admin_log_content_type_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX django_admin_log_content_type_id ON django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX django_admin_log_user_id ON django_admin_log USING btree (user_id);


--
-- Name: django_flatpage_sites_flatpage_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX django_flatpage_sites_flatpage_id ON django_flatpage_sites USING btree (flatpage_id);


--
-- Name: django_flatpage_sites_site_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX django_flatpage_sites_site_id ON django_flatpage_sites USING btree (site_id);


--
-- Name: django_flatpage_url; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX django_flatpage_url ON django_flatpage USING btree (url);


--
-- Name: django_flatpage_url_like; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX django_flatpage_url_like ON django_flatpage USING btree (url varchar_pattern_ops);


--
-- Name: django_session_expire_date; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX django_session_expire_date ON django_session USING btree (expire_date);


--
-- Name: django_session_session_key_like; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX django_session_session_key_like ON django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: djcelery_periodictask_crontab_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX djcelery_periodictask_crontab_id ON djcelery_periodictask USING btree (crontab_id);


--
-- Name: djcelery_periodictask_interval_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX djcelery_periodictask_interval_id ON djcelery_periodictask USING btree (interval_id);


--
-- Name: djcelery_periodictask_name_like; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX djcelery_periodictask_name_like ON djcelery_periodictask USING btree (name varchar_pattern_ops);


--
-- Name: djcelery_taskstate_hidden; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX djcelery_taskstate_hidden ON djcelery_taskstate USING btree (hidden);


--
-- Name: djcelery_taskstate_name; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX djcelery_taskstate_name ON djcelery_taskstate USING btree (name);


--
-- Name: djcelery_taskstate_name_like; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX djcelery_taskstate_name_like ON djcelery_taskstate USING btree (name varchar_pattern_ops);


--
-- Name: djcelery_taskstate_state; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX djcelery_taskstate_state ON djcelery_taskstate USING btree (state);


--
-- Name: djcelery_taskstate_state_like; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX djcelery_taskstate_state_like ON djcelery_taskstate USING btree (state varchar_pattern_ops);


--
-- Name: djcelery_taskstate_task_id_like; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX djcelery_taskstate_task_id_like ON djcelery_taskstate USING btree (task_id varchar_pattern_ops);


--
-- Name: djcelery_taskstate_tstamp; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX djcelery_taskstate_tstamp ON djcelery_taskstate USING btree (tstamp);


--
-- Name: djcelery_taskstate_worker_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX djcelery_taskstate_worker_id ON djcelery_taskstate USING btree (worker_id);


--
-- Name: djcelery_workerstate_hostname_like; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX djcelery_workerstate_hostname_like ON djcelery_workerstate USING btree (hostname varchar_pattern_ops);


--
-- Name: djcelery_workerstate_last_heartbeat; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX djcelery_workerstate_last_heartbeat ON djcelery_workerstate USING btree (last_heartbeat);


--
-- Name: djkombu_message_queue_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX djkombu_message_queue_id ON djkombu_message USING btree (queue_id);


--
-- Name: djkombu_message_sent_at; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX djkombu_message_sent_at ON djkombu_message USING btree (sent_at);


--
-- Name: djkombu_message_visible; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX djkombu_message_visible ON djkombu_message USING btree (visible);


--
-- Name: djkombu_queue_name_like; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX djkombu_queue_name_like ON djkombu_queue USING btree (name varchar_pattern_ops);


--
-- Name: messages_message_body_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX messages_message_body_id ON messages_message USING btree (body_id);


--
-- Name: messages_message_sent_at; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX messages_message_sent_at ON messages_message USING btree (sent_at);


--
-- Name: messages_message_type; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX messages_message_type ON messages_message USING btree (type);


--
-- Name: messages_message_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX messages_message_user_id ON messages_message USING btree (user_id);


--
-- Name: messages_messagebody_author_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX messages_messagebody_author_id ON messages_messagebody USING btree (author_id);


--
-- Name: messages_messagebody_parent_msg_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX messages_messagebody_parent_msg_id ON messages_messagebody USING btree (parent_msg_id);


--
-- Name: planet_blogpost_blog_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX planet_blogpost_blog_id ON planet_blogpost USING btree (blog_id);


--
-- Name: planet_blogpost_creation_date; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX planet_blogpost_creation_date ON planet_blogpost USING btree (creation_date);


--
-- Name: planet_blogpost_insert_date; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX planet_blogpost_insert_date ON planet_blogpost USING btree (insert_date);


--
-- Name: posts_emailentry_post_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX posts_emailentry_post_id ON posts_emailentry USING btree (post_id);


--
-- Name: posts_post_author_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX posts_post_author_id ON posts_post USING btree (author_id);


--
-- Name: posts_post_creation_date; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX posts_post_creation_date ON posts_post USING btree (creation_date);


--
-- Name: posts_post_lastedit_date; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX posts_post_lastedit_date ON posts_post USING btree (lastedit_date);


--
-- Name: posts_post_lastedit_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX posts_post_lastedit_user_id ON posts_post USING btree (lastedit_user_id);


--
-- Name: posts_post_parent_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX posts_post_parent_id ON posts_post USING btree (parent_id);


--
-- Name: posts_post_root_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX posts_post_root_id ON posts_post USING btree (root_id);


--
-- Name: posts_post_site_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX posts_post_site_id ON posts_post USING btree (site_id);


--
-- Name: posts_post_sticky; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX posts_post_sticky ON posts_post USING btree (sticky);


--
-- Name: posts_post_tag_set_post_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX posts_post_tag_set_post_id ON posts_post_tag_set USING btree (post_id);


--
-- Name: posts_post_tag_set_tag_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX posts_post_tag_set_tag_id ON posts_post_tag_set USING btree (tag_id);


--
-- Name: posts_post_thread_score; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX posts_post_thread_score ON posts_post USING btree (thread_score);


--
-- Name: posts_post_type; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX posts_post_type ON posts_post USING btree (type);


--
-- Name: posts_post_vote_count; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX posts_post_vote_count ON posts_post USING btree (vote_count);


--
-- Name: posts_postview_post_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX posts_postview_post_id ON posts_postview USING btree (post_id);


--
-- Name: posts_replytoken_post_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX posts_replytoken_post_id ON posts_replytoken USING btree (post_id);


--
-- Name: posts_replytoken_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX posts_replytoken_user_id ON posts_replytoken USING btree (user_id);


--
-- Name: posts_subscription_date; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX posts_subscription_date ON posts_subscription USING btree (date);


--
-- Name: posts_subscription_post_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX posts_subscription_post_id ON posts_subscription USING btree (post_id);


--
-- Name: posts_subscription_type; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX posts_subscription_type ON posts_subscription USING btree (type);


--
-- Name: posts_subscription_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX posts_subscription_user_id ON posts_subscription USING btree (user_id);


--
-- Name: posts_tag_name; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX posts_tag_name ON posts_tag USING btree (name);


--
-- Name: posts_tag_name_like; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX posts_tag_name_like ON posts_tag USING btree (name text_pattern_ops);


--
-- Name: posts_vote_author_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX posts_vote_author_id ON posts_vote USING btree (author_id);


--
-- Name: posts_vote_date; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX posts_vote_date ON posts_vote USING btree (date);


--
-- Name: posts_vote_post_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX posts_vote_post_id ON posts_vote USING btree (post_id);


--
-- Name: posts_vote_type; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX posts_vote_type ON posts_vote USING btree (type);


--
-- Name: socialaccount_socialaccount_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX socialaccount_socialaccount_user_id ON socialaccount_socialaccount USING btree (user_id);


--
-- Name: socialaccount_socialapp_sites_site_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX socialaccount_socialapp_sites_site_id ON socialaccount_socialapp_sites USING btree (site_id);


--
-- Name: socialaccount_socialapp_sites_socialapp_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX socialaccount_socialapp_sites_socialapp_id ON socialaccount_socialapp_sites USING btree (socialapp_id);


--
-- Name: socialaccount_socialtoken_account_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX socialaccount_socialtoken_account_id ON socialaccount_socialtoken USING btree (account_id);


--
-- Name: socialaccount_socialtoken_app_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX socialaccount_socialtoken_app_id ON socialaccount_socialtoken USING btree (app_id);


--
-- Name: users_emaillist_email_like; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX users_emaillist_email_like ON users_emaillist USING btree (email varchar_pattern_ops);


--
-- Name: users_profile_tags_profile_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX users_profile_tags_profile_id ON users_profile_tags USING btree (profile_id);


--
-- Name: users_profile_tags_tag_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX users_profile_tags_tag_id ON users_profile_tags USING btree (tag_id);


--
-- Name: users_profile_uuid_like; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX users_profile_uuid_like ON users_profile USING btree (uuid varchar_pattern_ops);


--
-- Name: users_tag_name; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX users_tag_name ON users_tag USING btree (name);


--
-- Name: users_tag_name_like; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX users_tag_name_like ON users_tag USING btree (name text_pattern_ops);


--
-- Name: users_user_email_like; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX users_user_email_like ON users_user USING btree (email varchar_pattern_ops);


--
-- Name: users_user_site_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX users_user_site_id ON users_user USING btree (site_id);


--
-- Name: account_emailconfirmation_email_address_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY account_emailconfirmation
    ADD CONSTRAINT account_emailconfirmation_email_address_id_fkey FOREIGN KEY (email_address_id) REFERENCES account_emailaddress(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_id_refs_id_1337a128; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY socialaccount_socialtoken
    ADD CONSTRAINT account_id_refs_id_1337a128 FOREIGN KEY (account_id) REFERENCES socialaccount_socialaccount(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: app_id_refs_id_edac8a54; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY socialaccount_socialtoken
    ADD CONSTRAINT app_id_refs_id_edac8a54 FOREIGN KEY (app_id) REFERENCES socialaccount_socialapp(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: author_id_refs_id_7ea6acc7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY posts_vote
    ADD CONSTRAINT author_id_refs_id_7ea6acc7 FOREIGN KEY (author_id) REFERENCES users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: author_id_refs_id_7f5b5a84; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY posts_post
    ADD CONSTRAINT author_id_refs_id_7f5b5a84 FOREIGN KEY (author_id) REFERENCES users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: badge_id_refs_id_23d6b191; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY badges_award
    ADD CONSTRAINT badge_id_refs_id_23d6b191 FOREIGN KEY (badge_id) REFERENCES badges_badge(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_id_refs_id_c3f7e9f0; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY planet_blogpost
    ADD CONSTRAINT blog_id_refs_id_c3f7e9f0 FOREIGN KEY (blog_id) REFERENCES planet_blog(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: content_type_id_refs_id_d043b34a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT content_type_id_refs_id_d043b34a FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: crontab_id_refs_id_286da0d1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY djcelery_periodictask
    ADD CONSTRAINT crontab_id_refs_id_286da0d1 FOREIGN KEY (crontab_id) REFERENCES djcelery_crontabschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_content_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_fkey FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_flatpage_sites_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY django_flatpage_sites
    ADD CONSTRAINT django_flatpage_sites_site_id_fkey FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: flatpage_id_refs_id_83cd0023; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY django_flatpage_sites
    ADD CONSTRAINT flatpage_id_refs_id_83cd0023 FOREIGN KEY (flatpage_id) REFERENCES django_flatpage(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: group_id_refs_id_f4b32aac; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT group_id_refs_id_f4b32aac FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: interval_id_refs_id_1829f358; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY djcelery_periodictask
    ADD CONSTRAINT interval_id_refs_id_1829f358 FOREIGN KEY (interval_id) REFERENCES djcelery_intervalschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: lastedit_user_id_refs_id_7f5b5a84; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY posts_post
    ADD CONSTRAINT lastedit_user_id_refs_id_7f5b5a84 FOREIGN KEY (lastedit_user_id) REFERENCES users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: messages_message_body_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY messages_message
    ADD CONSTRAINT messages_message_body_id_fkey FOREIGN KEY (body_id) REFERENCES messages_messagebody(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: messages_messagebody_parent_msg_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY messages_messagebody
    ADD CONSTRAINT messages_messagebody_parent_msg_id_fkey FOREIGN KEY (parent_msg_id) REFERENCES messages_messagebody(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: parent_id_refs_id_0ee8f888; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY posts_post
    ADD CONSTRAINT parent_id_refs_id_0ee8f888 FOREIGN KEY (parent_id) REFERENCES posts_post(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: post_id_refs_id_4c823465; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY posts_postview
    ADD CONSTRAINT post_id_refs_id_4c823465 FOREIGN KEY (post_id) REFERENCES posts_post(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: post_id_refs_id_5ee6ce9a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY posts_subscription
    ADD CONSTRAINT post_id_refs_id_5ee6ce9a FOREIGN KEY (post_id) REFERENCES posts_post(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: post_id_refs_id_7cb1d6db; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY posts_replytoken
    ADD CONSTRAINT post_id_refs_id_7cb1d6db FOREIGN KEY (post_id) REFERENCES posts_post(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: post_id_refs_id_834fdde6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY posts_emailentry
    ADD CONSTRAINT post_id_refs_id_834fdde6 FOREIGN KEY (post_id) REFERENCES posts_post(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: post_id_refs_id_8526afc7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY posts_post_tag_set
    ADD CONSTRAINT post_id_refs_id_8526afc7 FOREIGN KEY (post_id) REFERENCES posts_post(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: post_id_refs_id_bf522fd1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY posts_vote
    ADD CONSTRAINT post_id_refs_id_bf522fd1 FOREIGN KEY (post_id) REFERENCES posts_post(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: profile_id_refs_id_39458a3f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY users_profile_tags
    ADD CONSTRAINT profile_id_refs_id_39458a3f FOREIGN KEY (profile_id) REFERENCES users_profile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: queue_id_refs_id_88980102; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY djkombu_message
    ADD CONSTRAINT queue_id_refs_id_88980102 FOREIGN KEY (queue_id) REFERENCES djkombu_queue(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: root_id_refs_id_0ee8f888; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY posts_post
    ADD CONSTRAINT root_id_refs_id_0ee8f888 FOREIGN KEY (root_id) REFERENCES posts_post(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: site_id_refs_id_05d6147e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY socialaccount_socialapp_sites
    ADD CONSTRAINT site_id_refs_id_05d6147e FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: site_id_refs_id_6452c01b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY posts_post
    ADD CONSTRAINT site_id_refs_id_6452c01b FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: site_id_refs_id_d831b197; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY users_user
    ADD CONSTRAINT site_id_refs_id_d831b197 FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialapp_id_refs_id_e7a43014; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY socialaccount_socialapp_sites
    ADD CONSTRAINT socialapp_id_refs_id_e7a43014 FOREIGN KEY (socialapp_id) REFERENCES socialaccount_socialapp(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tag_id_refs_id_adb4de0e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY posts_post_tag_set
    ADD CONSTRAINT tag_id_refs_id_adb4de0e FOREIGN KEY (tag_id) REFERENCES posts_tag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tag_id_refs_id_eeeab012; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY users_profile_tags
    ADD CONSTRAINT tag_id_refs_id_eeeab012 FOREIGN KEY (tag_id) REFERENCES users_tag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_45b8f898; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY badges_award
    ADD CONSTRAINT user_id_refs_id_45b8f898 FOREIGN KEY (user_id) REFERENCES users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_6dbe081e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY socialaccount_socialaccount
    ADD CONSTRAINT user_id_refs_id_6dbe081e FOREIGN KEY (user_id) REFERENCES users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_7ea5d502; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY posts_replytoken
    ADD CONSTRAINT user_id_refs_id_7ea5d502 FOREIGN KEY (user_id) REFERENCES users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_e4c4f856; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY users_profile
    ADD CONSTRAINT user_id_refs_id_e4c4f856 FOREIGN KEY (user_id) REFERENCES users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_ebe5814a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY posts_subscription
    ADD CONSTRAINT user_id_refs_id_ebe5814a FOREIGN KEY (user_id) REFERENCES users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: worker_id_refs_id_6fd8ce95; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY djcelery_taskstate
    ADD CONSTRAINT worker_id_refs_id_6fd8ce95 FOREIGN KEY (worker_id) REFERENCES djcelery_workerstate(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

